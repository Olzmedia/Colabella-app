# Colabella Pet Club — App WebView

App Android nativa mínima que muestra `https://colabellapetclub.com` a pantalla completa.

## Qué hace

- Carga el sitio en un WebView con JavaScript, cookies y `localStorage` activados.
- **Navegación interna**: todo lo de `colabellapetclub.com` (y subdominios) se queda dentro de la app.
- **Enlaces externos**: `tel:`, `mailto:`, WhatsApp, mapas, pasarelas de pago y cualquier otro dominio se abren en la app correspondiente del móvil.
- **Botón atrás** del sistema: navega al historial del WebView antes de cerrar la app.
- **Deslizar para recargar** (pull to refresh).
- **Pantalla de error** con botón de reintentar cuando no hay conexión.
- **Subida de archivos** desde formularios del sitio (`<input type="file">`).
- **Descargas** mediante el gestor de descargas de Android, conservando la sesión (cookies).
- Solo HTTPS: el tráfico sin cifrar está bloqueado.
- User-Agent con el sufijo `ColabellaApp/1.0`, por si quieres ocultar el menú o la cabecera del sitio cuando se ve desde la app.

## Compilar el APK

### Opción A — GitHub Actions (sin instalar nada)

1. Sube esta carpeta a un repositorio de GitHub.
2. Ve a la pestaña **Actions** → workflow *Build APK* → **Run workflow**.
3. Al terminar, descarga el artefacto `colabella-petclub-debug`. Dentro está el `app-debug.apk`, instalable directamente en el móvil (hay que permitir "orígenes desconocidos").

### Opción B — Android Studio

1. `File → Open` y selecciona la carpeta del proyecto. Android Studio descarga el SDK y genera el `gradlew` por sí solo.
2. `Build → Build Bundle(s) / APK(s) → Build APK(s)`.

### Opción C — línea de comandos

Con JDK 17, Gradle 8.7 y el SDK de Android instalados (variable `ANDROID_HOME`):

```bash
gradle assembleDebug
# APK en: app/build/outputs/apk/debug/app-debug.apk
```

## Personalizar

| Qué | Dónde |
|---|---|
| Dominio y URL de inicio | `MainActivity.java` → constante `HOST` |
| Nombre de la app y textos | `res/values/strings.xml` |
| Colores de marca y barra de estado | `res/values/colors.xml` |
| Icono | `res/mipmap-*/ic_launcher.png` y `res/drawable/ic_launcher_foreground.xml` |
| ID de paquete y versión | `app/build.gradle` (`applicationId`, `versionCode`, `versionName`) |

El icono actual es una huella genérica de marcador de posición; sustitúyelo por el logo real usando `Image Asset Studio` de Android Studio.

## Para publicar en Google Play

El APK de debug sirve para instalar y probar, pero no para la Play Store. Hace falta:

1. Generar un keystore de firma (`keytool -genkey -v -keystore colabella.jks -alias colabella -keyalg RSA -keysize 2048 -validity 10000`).
2. Añadir el bloque `signingConfigs` en `app/build.gradle` y compilar `bundleRelease` (formato AAB, obligatorio en Play).
3. Tener en cuenta que Google rechaza aplicaciones que son solo un contenedor del sitio web sin funcionalidad añadida (política de *Mínima funcionalidad*). Notificaciones push, acceso offline a algo o funciones de cámara/ubicación suelen ser lo que marca la diferencia. Para distribución interna (descarga desde tu web o enlace directo) esto no aplica.

## Requisitos del sitio

El WebView es Chromium, así que el sitio se ve igual que en Chrome móvil. Conviene revisar que:

- Sea responsive y no dependa de hover.
- No abra ventanas con `target="_blank"` para flujos críticos (se irían al navegador; si lo necesitas, avísame y añado soporte con `setSupportMultipleWindows`).
- Si usa pasarela de pago externa (Stripe, Redsys, PayPal), el retorno vuelve al dominio y por tanto a la app.
