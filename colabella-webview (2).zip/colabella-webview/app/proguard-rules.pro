# Mantener los métodos expuestos al WebView por si en el futuro se añade un JavascriptInterface
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
