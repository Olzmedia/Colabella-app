package com.colabellapetclub.app;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    public static final String EXTRA_ABRIR_MASCOTAS = "abrir_mascotas";

    private static final String TAG_WEB = "web";
    private static final String TAG_PETS = "pets";

    private WebFragment webFragment;
    private PetsFragment petsFragment;
    private Fragment actual;

    private BottomNavigationView nav;
    private ActivityResultLauncher<String> permisoNotificaciones;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Notifications.crearCanales(this);

        permisoNotificaciones = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(), concedido -> { });

        nav = findViewById(R.id.bottom_nav);

        if (savedInstanceState != null) {
            webFragment = (WebFragment) getSupportFragmentManager().findFragmentByTag(TAG_WEB);
            petsFragment = (PetsFragment) getSupportFragmentManager().findFragmentByTag(TAG_PETS);
        }
        if (webFragment == null) {
            webFragment = new WebFragment();
        }
        if (petsFragment == null) {
            petsFragment = new PetsFragment();
        }

        nav.setOnItemSelectedListener(item -> {
            if (item.getItemId() == R.id.nav_inicio) {
                mostrar(webFragment, TAG_WEB);
                return true;
            }
            if (item.getItemId() == R.id.nav_mascotas) {
                mostrar(petsFragment, TAG_PETS);
                return true;
            }
            return false;
        });

        if (savedInstanceState == null) {
            mostrar(webFragment, TAG_WEB);
        } else {
            actual = getSupportFragmentManager().findFragmentById(R.id.contenedor);
        }

        manejarIntent(getIntent());
        pedirPermisoNotificaciones();

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (actual == webFragment && webFragment.puedeRetroceder()) {
                    webFragment.retroceder();
                    return;
                }
                if (actual != webFragment) {
                    nav.setSelectedItemId(R.id.nav_inicio);
                    return;
                }
                setEnabled(false);
                getOnBackPressedDispatcher().onBackPressed();
            }
        });
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        manejarIntent(intent);
    }

    /** Atiende los accesos directos del icono y los enlaces de las notificaciones. */
    private void manejarIntent(@Nullable Intent intent) {
        if (intent == null) {
            return;
        }
        if (intent.getBooleanExtra(EXTRA_ABRIR_MASCOTAS, false)) {
            nav.setSelectedItemId(R.id.nav_mascotas);
            return;
        }
        Uri data = intent.getData();
        if (data != null && data.getScheme() != null && data.getScheme().startsWith("http")) {
            nav.setSelectedItemId(R.id.nav_inicio);
            webFragment.cargar(data.toString());
        }
    }

    private void mostrar(Fragment fragment, String tag) {
        if (fragment == actual) {
            return;
        }
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.contenedor, fragment, tag)
                .commit();
        actual = fragment;
    }

    private void pedirPermisoNotificaciones() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
            return;
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            permisoNotificaciones.launch(Manifest.permission.POST_NOTIFICATIONS);
        }
    }
}
