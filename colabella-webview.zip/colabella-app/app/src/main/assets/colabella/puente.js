/*
 * Puente entre colabellapetclub.com y la app cuando la app usa su motor propio
 * (GeckoView). Hace lo mismo que SincronizacionWeb.script() en la WebView:
 *
 *   1. Lee window.COLABELLA_APP_MENU, si la pagina lo imprime.
 *   2. admin-ajax clubd_whoami  -> si hay sesion y la llave (nonce) de la API.
 *   3. /wp-json/cdmenu/v1/menu  -> el menu segun el rol.
 *   4. /wp-json/club/v1/mascotas -> las mascotas del socio.
 *
 * Solo corre en la pagina principal del sitio (all_frames: false), nunca en un
 * iframe de terceros, asi que no hace falta el token de la WebView.
 */
(function () {
  'use strict';

  var puerto = null;
  var ultima = 0;

  function enviar(tipo, json) {
    try {
      if (puerto) {
        puerto.postMessage({ tipo: tipo, json: json });
      }
    } catch (e) { /* la app ya no escucha */ }
  }

  /*
   * Peticion con la sesion de la pagina. content.fetch hace la peticion "como la
   * pagina" (mismas cookies y origen); fetch a secas, como la extension.
   * Devuelve el texto de la respuesta, o null si no fue 2xx.
   */
  function pedir(url, cabeceras) {
    var opciones = { credentials: 'include', cache: 'no-store', headers: cabeceras || {} };
    try {
      if (typeof content !== 'undefined' && content && typeof content.fetch === 'function') {
        return content.fetch(url, cloneInto(opciones, window))
          .then(function (r) { return r.ok ? r.text() : null; });
      }
    } catch (e) { /* sigue con fetch normal */ }
    return fetch(url, opciones).then(function (r) { return r.ok ? r.text() : null; });
  }

  function leerJson(texto) {
    if (typeof texto !== 'string' || !texto) {
      return undefined;
    }
    try {
      return JSON.parse(texto);
    } catch (e) {
      return undefined;
    }
  }

  function leerMenuDeLaPagina() {
    try {
      var pagina = window.wrappedJSObject;
      if (pagina && pagina.COLABELLA_APP_MENU) {
        var s = pagina.JSON.stringify(pagina.COLABELLA_APP_MENU);
        if (typeof s === 'string' && s && s !== 'null') {
          enviar('menu', String(s));
        }
      }
    } catch (e) { /* la pagina no publica menu */ }
  }

  function sincronizar(forzar) {
    var ahora = Date.now();
    // Evita repetir la consulta si la misma pagina avisa dos veces
    if (!forzar && ahora - ultima < 4000) {
      return;
    }
    ultima = ahora;

    pedir('/wp-admin/admin-ajax.php?action=clubd_whoami&_=' + ahora).then(function (t) {
      var w = leerJson(t);
      if (w === undefined) {
        return; // sin respuesta valida: se conserva lo que habia en el telefono
      }
      var h = {};
      if (w && w.rest_nonce) {
        h['X-WP-Nonce'] = String(w.rest_nonce);
      }

      pedir('/wp-json/cdmenu/v1/menu?_=' + Date.now(), h).then(function (m) {
        if (leerJson(m)) {
          enviar('menu', m);
        }
      }).catch(function () {});

      if (!w || w.logged_in != 1) {
        enviar('mascotas', 'null');
        return;
      }
      pedir('/wp-json/club/v1/mascotas?_=' + Date.now(), h).then(function (l) {
        if (Array.isArray(leerJson(l))) {
          enviar('mascotas', l);
        }
      }).catch(function () {});
    }).catch(function () {});
  }

  try {
    puerto = browser.runtime.connectNative('browser');
    puerto.onMessage.addListener(function (m) {
      if (m && m.accion === 'sincronizar') {
        leerMenuDeLaPagina();
        sincronizar(true);
      }
    });
    puerto.onDisconnect.addListener(function () { puerto = null; });
  } catch (e) {
    puerto = null;
  }

  leerMenuDeLaPagina();
  sincronizar(false);
})();
