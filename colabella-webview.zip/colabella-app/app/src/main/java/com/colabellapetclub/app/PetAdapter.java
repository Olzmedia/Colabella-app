package com.colabellapetclub.app;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class PetAdapter extends RecyclerView.Adapter<PetAdapter.Holder> {

    public interface Listener {
        void onEditar(Pet pet);
        void onEliminar(Pet pet);
    }

    private final List<Pet> datos = new ArrayList<>();
    private final Listener listener;

    public PetAdapter(Listener listener) {
        this.listener = listener;
    }

    public void actualizar(List<Pet> nuevos) {
        datos.clear();
        datos.addAll(nuevos);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_pet, parent, false);
        return new Holder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull Holder h, int position) {
        Pet p = datos.get(position);
        h.nombre.setText(p.nombre);
        FichaMascota.pintarFoto(h.foto, p.fotoUrl, p.tipo, 12, 18, 0);

        StringBuilder sub = new StringBuilder();
        if (!p.especie.isEmpty()) {
            sub.append(p.especie);
        }
        if (!p.raza.isEmpty()) {
            if (sub.length() > 0) {
                sub.append(" · ");
            }
            sub.append(p.raza);
        }
        h.detalle.setText(sub.toString());
        h.detalle.setVisibility(sub.length() > 0 ? View.VISIBLE : View.GONE);

        if (p.proximaVacuna > 0) {
            String fecha = DateFormat.getDateInstance(DateFormat.MEDIUM)
                    .format(new Date(p.proximaVacuna));
            long dias = FichaMascota.diasDesdeHoy(p.proximaVacuna);
            String texto;
            if (dias < 0) {
                texto = h.itemView.getContext().getString(R.string.vacuna_vencida, fecha);
            } else if (dias == 0) {
                texto = h.itemView.getContext().getString(R.string.vacuna_hoy);
            } else {
                texto = h.itemView.getContext()
                        .getString(R.string.vacuna_proxima, fecha, String.valueOf(dias));
            }
            h.vacuna.setText(texto);
            h.vacuna.setVisibility(View.VISIBLE);
        } else {
            h.vacuna.setVisibility(View.GONE);
        }

        h.notas.setText(p.notas);
        h.notas.setVisibility(p.notas.isEmpty() ? View.GONE : View.VISIBLE);

        // Las fichas de la cuenta se borran desde la web, no desde aqui
        h.origen.setVisibility(p.deLaWeb ? View.VISIBLE : View.GONE);
        h.borrar.setVisibility(p.deLaWeb ? View.GONE : View.VISIBLE);

        h.itemView.setOnClickListener(v -> listener.onEditar(p));
        h.borrar.setOnClickListener(v -> listener.onEliminar(p));
    }

    @Override
    public int getItemCount() {
        return datos.size();
    }

    static class Holder extends RecyclerView.ViewHolder {
        final ImageView foto;
        final TextView nombre;
        final TextView detalle;
        final TextView vacuna;
        final TextView notas;
        final TextView origen;
        final ImageButton borrar;

        Holder(@NonNull View v) {
            super(v);
            foto = v.findViewById(R.id.pet_foto);
            nombre = v.findViewById(R.id.pet_nombre);
            detalle = v.findViewById(R.id.pet_detalle);
            vacuna = v.findViewById(R.id.pet_vacuna);
            notas = v.findViewById(R.id.pet_notas);
            origen = v.findViewById(R.id.pet_origen);
            borrar = v.findViewById(R.id.pet_borrar);
        }
    }
}
