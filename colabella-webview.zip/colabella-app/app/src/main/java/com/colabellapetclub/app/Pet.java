package com.colabellapetclub.app;

import org.json.JSONException;
import org.json.JSONObject;

/** Una mascota guardada localmente en el dispositivo. */
public class Pet {

    public String id;
    public String nombre;
    public String especie;
    public String raza;
    /** Fecha de la proxima vacuna en milisegundos, o 0 si no hay ninguna programada. */
    public long proximaVacuna;
    public String notas;
    /**
     * true si la ficha viene de la cuenta del socio en colabellapetclub.com.
     * Esas fichas se sobrescriben en cada sincronizacion y se editan en la web.
     */
    public boolean deLaWeb;
    /** Solo fichas de la web: direccion https de la foto (puede estar vacia). */
    public String fotoUrl = "";
    /** Solo fichas de la web: el emoji del tipo (la web guarda "🐶", "🐱"...). */
    public String tipo = "";
    /** Solo fichas de la web: la ficha tal cual la manda /club/v1/mascotas. */
    public String datosWeb = "{}";
    /** Solo fichas de la web: [{"nombre","fecha","proxima"}, ...] tal como las guarda la web. */
    public String vacunas = "[]";

    public Pet() {
        this.id = String.valueOf(System.currentTimeMillis());
        this.especie = "";
        this.raza = "";
        this.notas = "";
    }

    public JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("id", id);
        o.put("nombre", nombre);
        o.put("especie", especie);
        o.put("raza", raza);
        o.put("proximaVacuna", proximaVacuna);
        o.put("notas", notas);
        o.put("web", deLaWeb);
        o.put("foto", fotoUrl);
        o.put("tipo", tipo);
        o.put("datosWeb", datosWeb);
        o.put("vacunas", vacunas);
        return o;
    }

    public static Pet fromJson(JSONObject o) {
        Pet p = new Pet();
        p.id = o.optString("id", String.valueOf(System.currentTimeMillis()));
        p.nombre = o.optString("nombre", "");
        p.especie = o.optString("especie", "");
        p.raza = o.optString("raza", "");
        p.proximaVacuna = o.optLong("proximaVacuna", 0);
        p.notas = o.optString("notas", "");
        p.deLaWeb = o.optBoolean("web", false);
        p.fotoUrl = o.optString("foto", "");
        p.tipo = o.optString("tipo", "");
        p.datosWeb = o.optString("datosWeb", "{}");
        p.vacunas = o.optString("vacunas", "[]");
        return p;
    }
}
