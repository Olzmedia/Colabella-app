package com.colabellapetclub.app;

import android.app.Dialog;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.DrawableRes;
import androidx.annotation.FontRes;
import androidx.core.content.res.ResourcesCompat;
import androidx.core.widget.ImageViewCompat;
import androidx.core.widget.NestedScrollView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.CenterCrop;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.chip.ChipGroup;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * La ficha de una mascota de la cuenta, igual que en colabellapetclub.com/mi-perfil/.
 *
 * Datos y reglas copiados de colabella-mi-perfil.php (window.cdVerMascota y sus
 * ayudantes): mismos textos, mismo orden, mismos avisos. El aspecto sigue el panel
 * de la mascota de la web: cabecera con degradado (.pp-hero), foto en cuadro con
 * borde blanco (.pp-av), pastillas (.pp-chips), cifras (.pp-stats), aviso
 * (.fa-aviso) y bloques blancos con sombra y su color (.fa-bloque.salud,
 * .vacunas, .ident, .vet). Tipografias Poppins y Jost e iconos Tabler, como la web.
 *
 * Si la web cambia esas reglas o ese estilo, hay que cambiarlos aqui tambien.
 * Documentos y Comida dependen de otras partes de la web: se abren alli.
 */
final class FichaMascota {

    interface Acciones {
        void abrirWeb();
        void llamar(String telefono);
    }

    // Paleta de la web (--teal-d, --navy, --ink, --coral...)
    private static final int TEAL_D = Color.parseColor("#0F4A5F");
    private static final int TEAL = Color.parseColor("#1287A3");
    private static final int INK = Color.parseColor("#132A32");
    private static final int MUTED = Color.parseColor("#6B8088");
    private static final int CORAL = Color.parseColor("#FF6431");
    private static final int CORAL_TXT = Color.parseColor("#C2410C");
    private static final int CORAL_BG = Color.parseColor("#FFF1EB");
    private static final int LINEA = Color.parseColor("#DCE7EA");
    private static final int FONDO = Color.parseColor("#EEF5F7");
    private static final int CYAN_SOFT = Color.parseColor("#E3F4F7");

    // Color de cada bloque (--bc en la web)
    private static final int BC_SALUD = Color.parseColor("#E2643F");
    private static final int BC_VACUNAS = Color.parseColor("#0E9EA8");
    private static final int BC_IDENT = Color.parseColor("#2F6FD0");
    private static final int BC_VET = Color.parseColor("#7A5BC7");

    /** CAMPOS_FICHA de la web: lo que cuenta para "ficha completa". */
    private static final String[] CAMPOS_FICHA = {
            "raza", "edad", "sexo", "peso", "color", "esterilizado", "microchip",
            "alergias", "medicamentos", "veterinario", "vet_telefono", "notas"
    };

    private static final String[] MESES = {
            "ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sep", "oct", "nov", "dic"
    };

    private final Context ctx;
    private final Pet pet;
    private final JSONObject d;
    private final Acciones acciones;
    private Dialog dialogo;

    private FichaMascota(Context ctx, Pet pet, Acciones acciones) {
        this.ctx = ctx;
        this.pet = pet;
        this.acciones = acciones;
        JSONObject o;
        try {
            o = new JSONObject(pet.datosWeb == null ? "{}" : pet.datosWeb);
        } catch (Exception e) {
            o = new JSONObject();
        }
        this.d = o;
    }

    /** Abre la ficha como hoja que sube desde abajo, a pantalla completa. */
    static void mostrar(Context ctx, Pet pet, Acciones acciones) {
        new FichaMascota(ctx, pet, acciones).abrir();
    }

    private void abrir() {
        BottomSheetDialog hoja = new BottomSheetDialog(ctx);
        dialogo = hoja;
        View contenido = construir();
        hoja.setContentView(contenido);
        BottomSheetBehavior<?> b = hoja.getBehavior();
        b.setSkipCollapsed(true);
        b.setState(BottomSheetBehavior.STATE_EXPANDED);
        hoja.setOnShowListener(x -> {
            // El marco de la hoja trae fondo propio: se quita para que se vean
            // las esquinas redondeadas de la cabecera
            // (después de la primera medida, que es cuando la hoja pone el suyo).
            contenido.post(() -> {
                if (contenido.getParent() instanceof View) {
                    ((View) contenido.getParent()).setBackgroundColor(Color.TRANSPARENT);
                }
            });
        });
        hoja.show();
    }

    // =====================================================================
    // Vista
    // =====================================================================

    private View construir() {
        LinearLayout raiz = vertical();
        GradientDrawable fondoHoja = new GradientDrawable();
        fondoHoja.setColor(FONDO);
        float r = dp(24);
        fondoHoja.setCornerRadii(new float[]{r, r, r, r, 0, 0, 0, 0});
        raiz.setBackground(fondoHoja);
        raiz.setClipToOutline(true);

        raiz.addView(cabecera());

        NestedScrollView scroll = new NestedScrollView(ctx);
        LinearLayout cuerpo = vertical();
        cuerpo.setPadding(dp(14), dp(14), dp(14), dp(24));
        scroll.addView(cuerpo);
        raiz.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        cuerpo.addView(aviso());
        cuerpo.addView(bloqueSalud());
        cuerpo.addView(bloqueVacunas());
        cuerpo.addView(bloqueIdentificacion());
        cuerpo.addView(bloqueVeterinario());
        cuerpo.addView(botones());
        return raiz;
    }

    /** .pp-hero: degradado, foto en cuadro con borde blanco, nombre, pastillas y cifras. */
    private View cabecera() {
        LinearLayout hero = vertical();
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{TEAL_D, Color.parseColor("#0B3A4A"), Color.parseColor("#082F3C")});
        float r = dp(24);
        g.setCornerRadii(new float[]{r, r, r, r, 0, 0, 0, 0});
        hero.setBackground(g);

        // Asa para arrastrar y boton de cerrar
        FrameLayout barra = new FrameLayout(ctx);
        View asa = new View(ctx);
        GradientDrawable ga = new GradientDrawable();
        ga.setColor(Color.argb(90, 255, 255, 255));
        ga.setCornerRadius(dp(3));
        asa.setBackground(ga);
        FrameLayout.LayoutParams la = new FrameLayout.LayoutParams(dp(40), dp(5), Gravity.CENTER);
        barra.addView(asa, la);
        TextView cerrar = texto("✕", 18, Color.WHITE, R.font.poppins_medium);
        cerrar.setPadding(dp(14), dp(6), dp(16), dp(6));
        cerrar.setContentDescription(ctx.getString(R.string.cerrar));
        cerrar.setOnClickListener(v -> { if (dialogo != null) dialogo.dismiss(); });
        barra.addView(cerrar, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.END | Gravity.CENTER_VERTICAL));
        hero.addView(barra, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(40)));

        // .pp-top: foto + nombre y pastillas
        LinearLayout top = new LinearLayout(ctx);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(18), 0, dp(18), dp(18));

        ImageView foto = new ImageView(ctx);
        GradientDrawable marco = new GradientDrawable();
        marco.setColor(Color.WHITE);
        marco.setCornerRadius(dp(22));
        foto.setBackground(marco);
        foto.setElevation(dp(8));
        foto.setScaleType(ImageView.ScaleType.CENTER_CROP);
        top.addView(foto, new LinearLayout.LayoutParams(dp(88), dp(88)));
        pintarFoto(foto, pet.fotoUrl, pet.tipo, 18, 22, 3);

        LinearLayout txt = vertical();
        txt.setPadding(dp(16), 0, 0, 0);
        TextView nombre = texto(pet.nombre, 28, Color.WHITE, R.font.jost_extrabold);
        nombre.setMaxLines(2);
        nombre.setEllipsize(TextUtils.TruncateAt.END);
        txt.addView(nombre);

        ChipGroup chips = new ChipGroup(ctx);
        chips.setChipSpacingHorizontal(dp(6));
        chips.setChipSpacingVertical(dp(6));
        List<String> partes = new ArrayList<>();
        for (String s : new String[]{s("raza"), s("sexo"), edad()}) {
            if (!s.isEmpty()) partes.add(s);
        }
        if (partes.isEmpty()) partes.add("Todavía sin datos");
        for (String s : partes) {
            TextView p = texto(s, 12, Color.WHITE, R.font.poppins_bold);
            p.setPadding(dp(12), dp(4), dp(12), dp(4));
            p.setBackground(pastilla(Color.argb(36, 255, 255, 255), Color.argb(77, 255, 255, 255), 1));
            chips.addView(p);
        }
        LinearLayout.LayoutParams lc = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lc.topMargin = dp(6);
        txt.addView(chips, lc);
        top.addView(txt, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        hero.addView(top);

        hero.addView(cifras());
        return hero;
    }

    /** .pp-stats: franja oscura con Peso, Próxima dosis y Ficha completa. */
    private View cifras() {
        LinearLayout fila = new LinearLayout(ctx);
        fila.setOrientation(LinearLayout.HORIZONTAL);
        fila.setBackgroundColor(Color.argb(89, 8, 47, 60));

        Prox prox = proximaVacuna();
        String txtProx = prox == null ? "—"
                : prox.dias < 0 ? "Vencida" : prox.dias == 0 ? "Hoy" : "En " + prox.dias + " d";
        String subProx = "Próxima dosis" + (prox != null && !prox.nombre.isEmpty() ? " · " + prox.nombre : "");

        fila.addView(cifra(s("peso").isEmpty() ? "—" : s("peso"), "Peso", false, false));
        fila.addView(cifra(txtProx, subProx, prox != null && prox.dias <= 30, true));
        fila.addView(cifra(fichaHechos() + "/" + CAMPOS_FICHA.length, "Ficha completa", false, true));

        LinearLayout envoltura = vertical();
        View linea = new View(ctx);
        linea.setBackgroundColor(Color.argb(36, 255, 255, 255));
        envoltura.addView(linea, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1));
        envoltura.addView(fila);
        return envoltura;
    }

    private View cifra(String valor, String etiqueta, boolean urge, boolean separador) {
        LinearLayout c = vertical();
        c.setPadding(dp(16), dp(12), dp(10), dp(14));
        TextView v = texto(valor, 21, urge ? Color.parseColor("#FFB59A") : Color.WHITE, R.font.jost_extrabold);
        v.setSingleLine(true);
        v.setEllipsize(TextUtils.TruncateAt.END);
        TextView e = texto(etiqueta, 12, Color.parseColor("#CDEBF2"), R.font.poppins_regular);
        e.setSingleLine(true);
        e.setEllipsize(TextUtils.TruncateAt.END);
        c.addView(v);
        c.addView(e);
        c.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        return c;
    }

    /** avisoFicha() de la web: lo urgente antes que lo pendiente, y eso antes que la enhorabuena. */
    private View aviso() {
        int hechos = fichaHechos();
        int faltan = CAMPOS_FICHA.length - hechos;
        Prox prox = proximaVacuna();
        int venc = vencidas();

        String icono, clave, titulo;
        int fondo, color;
        if (venc > 0) {
            icono = "⚠️"; clave = "Atención";
            titulo = venc + " " + (venc == 1 ? "dosis vencida" : "dosis vencidas");
            fondo = Color.parseColor("#FFF0E9"); color = Color.parseColor("#8A3A1B");
        } else if (hechos <= 2) {
            icono = "✨"; clave = "Empecemos";
            titulo = "Cuéntanos 3 cosas de " + (pet.nombre.isEmpty() ? "tu mascota" : pet.nombre);
            fondo = Color.parseColor("#FFF4EE"); color = Color.parseColor("#A73A16");
        } else if (prox != null && prox.dias <= 30) {
            icono = "💉"; clave = "Próxima dosis";
            titulo = prox.nombre + " en " + prox.dias + " " + (prox.dias == 1 ? "día" : "días");
            fondo = CYAN_SOFT; color = TEAL_D;
        } else if (faltan > 0) {
            icono = "📋"; clave = "Casi está";
            titulo = "Te falta" + (faltan == 1 ? "" : "n") + " " + faltan + " dato" + (faltan == 1 ? "" : "s");
            fondo = Color.parseColor("#FFF8E9"); color = Color.parseColor("#7A5B0C");
        } else {
            icono = "✓"; clave = "Todo al día";
            titulo = "La ficha está completa";
            fondo = Color.parseColor("#E9F9F0"); color = Color.parseColor("#15794A");
        }

        MaterialCardView card = tarjeta(fondo, 16);
        LinearLayout a = new LinearLayout(ctx);
        a.setOrientation(LinearLayout.HORIZONTAL);
        a.setGravity(Gravity.CENTER_VERTICAL);
        a.setPadding(dp(16), dp(13), dp(16), dp(13));
        TextView ic = texto(icono, 22, color, R.font.poppins_bold);
        ic.setPadding(0, 0, dp(14), 0);
        a.addView(ic);
        LinearLayout t = vertical();
        t.addView(texto(titulo, 15, color, R.font.poppins_bold));
        t.addView(texto(clave, 12, color, R.font.poppins_medium));
        a.addView(t);
        card.addView(a);
        return card;
    }

    private View bloqueSalud() {
        LinearLayout b = new LinearLayout(ctx);
        MaterialCardView card = bloque(R.drawable.tb_stethoscope, BC_SALUD, "Salud", b);
        boolean hayAlergia = !s("alergias").isEmpty() && !s("alergias").toLowerCase(Locale.ROOT).startsWith("ningun");
        boolean hayMedic = !s("medicamentos").isEmpty() && !s("medicamentos").toLowerCase(Locale.ROOT).startsWith("ningun");
        List<View> filas = new ArrayList<>();
        if (hayAlergia) filas.add(fila(R.drawable.tb_alert_triangle, "Alergias", s("alergias"), true));
        if (hayMedic) filas.add(fila(R.drawable.tb_pill, "Medicamentos", s("medicamentos"), false));
        if (!s("esterilizado").isEmpty()) filas.add(fila(R.drawable.tb_heart_plus, "Esterilizado", s("esterilizado"), false));
        if (filas.isEmpty()) {
            b.addView(vacio("Sin alergias ni medicamentos anotados.\nAnótalos y estarán a mano el día que hagan falta."));
        } else {
            agregarConLineas(b, filas);
        }
        return card;
    }

    /** "Vacunas y desparasitación": ordenadas por la dosis más cercana, cada una con su estado. */
    private View bloqueVacunas() {
        LinearLayout b = new LinearLayout(ctx);
        MaterialCardView card = bloque(R.drawable.tb_vaccine, BC_VACUNAS, "Vacunas y desparasitación", b);
        List<JSONObject> vac = vacunas();
        if (vac.isEmpty()) {
            b.addView(vacio("Todavía no hay vacunas anotadas.\nCon la fecha de la próxima dosis te avisamos por correo cinco días antes."));
            return card;
        }
        Collections.sort(vac, (x, y) -> {
            Integer dx = diasHasta(x.optString("proxima")), dy = diasHasta(y.optString("proxima"));
            if (dx == null) return 1;
            if (dy == null) return -1;
            return Integer.compare(dx, dy);
        });
        List<View> filas = new ArrayList<>();
        for (JSONObject v : vac) {
            filas.add(filaDosis(v));
        }
        agregarConLineas(b, filas);
        return card;
    }

    private View filaDosis(JSONObject v) {
        Integer dd = diasHasta(v.optString("proxima"));
        String et;
        boolean pen = false, nada = false;
        if (dd == null) { et = "Sin próxima"; nada = true; }
        else if (dd < 0) { et = "Vencida"; pen = true; }
        else if (dd == 0) { et = "Hoy"; pen = true; }
        else if (dd <= 30) { et = "En " + dd + " " + (dd == 1 ? "día" : "días"); pen = true; }
        else { et = "Al día"; }

        LinearLayout f = new LinearLayout(ctx);
        f.setOrientation(LinearLayout.HORIZONTAL);
        f.setGravity(Gravity.CENTER_VERTICAL);
        f.setPadding(0, dp(11), 0, dp(11));

        boolean desp = esDesparasitacion(v.optString("nombre"));
        f.addView(iconoEnCuadro(desp ? R.drawable.tb_bug : R.drawable.tb_vaccine,
                pen ? CORAL : BC_VACUNAS, pen ? CORAL_BG : Color.parseColor("#E2F6F7"), 40, 20));

        LinearLayout tx = vertical();
        tx.setPadding(dp(12), 0, dp(8), 0);
        String nombre = v.optString("nombre");
        tx.addView(texto(nombre.isEmpty() ? "Dosis" : nombre, 15, INK, R.font.poppins_semibold));
        String fecha = v.optString("fecha");
        String proxima = v.optString("proxima");
        String sub = (fecha.isEmpty() ? "Sin fecha de aplicación" : "Puesta el " + fechaCorta(fecha))
                + (proxima.isEmpty() ? "" : " · Próxima: " + fechaCorta(proxima));
        tx.addView(texto(sub, 12, MUTED, R.font.poppins_regular));
        f.addView(tx, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        int etFondo = nada ? Color.parseColor("#EEF3F5") : pen ? Color.parseColor("#FFE8DE") : Color.parseColor("#E3F6EE");
        int etColor = nada ? MUTED : pen ? CORAL_TXT : Color.parseColor("#15794A");
        TextView etq = texto(et, 12, etColor, R.font.poppins_semibold);
        etq.setPadding(dp(10), dp(5), dp(10), dp(5));
        etq.setBackground(pastilla(etFondo, etFondo, 0));
        f.addView(etq);
        return f;
    }

    private View bloqueIdentificacion() {
        LinearLayout b = new LinearLayout(ctx);
        MaterialCardView card = bloque(R.drawable.tb_id_badge_2, BC_IDENT, "Identificación", b);
        List<View> filas = new ArrayList<>();
        filas.add(fila(R.drawable.tb_cpu, "Microchip",
                s("microchip").isEmpty() ? "No tiene / sin registrar" : s("microchip"), false));
        if (!s("color").isEmpty()) filas.add(fila(R.drawable.tb_palette, "Color", s("color"), false));
        if (!s("notas").isEmpty()) filas.add(fila(R.drawable.tb_notes, "Notas", s("notas"), false));
        agregarConLineas(b, filas);
        return card;
    }

    private View bloqueVeterinario() {
        LinearLayout b = new LinearLayout(ctx);
        MaterialCardView card = bloque(R.drawable.tb_building_hospital, BC_VET, "Su veterinario", b);
        String vet = s("veterinario"), tel = s("vet_telefono");
        if (vet.isEmpty() && tel.isEmpty()) {
            b.addView(vacio("Sin veterinario anotado.\nTenerlo aquí evita buscar el número en una urgencia."));
            return card;
        }
        List<View> filas = new ArrayList<>();
        if (!vet.isEmpty()) filas.add(fila(R.drawable.tb_building_hospital, "Clínica", vet, false));
        if (!tel.isEmpty()) filas.add(fila(R.drawable.tb_phone, "Teléfono", tel, false));
        agregarConLineas(b, filas);
        if (!tel.isEmpty()) {
            LinearLayout boton = botonPildora(R.drawable.tb_phone,
                    "Llamar a " + (vet.isEmpty() ? "la clínica" : vet), BC_VET, Color.TRANSPARENT, BC_VET);
            boton.setOnClickListener(v -> acciones.llamar(tel.replaceAll("[^0-9+]", "")));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(48));
            lp.topMargin = dp(10);
            lp.bottomMargin = dp(4);
            b.addView(boton, lp);
        }
        return card;
    }

    /** Editar en la web (principal) y Documentos y comida (secundario). */
    private View botones() {
        LinearLayout c = vertical();
        c.setPadding(0, dp(18), 0, 0);

        LinearLayout editar = botonPildora(R.drawable.tb_clipboard_list, "Editar en la web",
                Color.WHITE, TEAL_D, TEAL_D);
        editar.setOnClickListener(v -> { cerrar(); acciones.abrirWeb(); });
        c.addView(editar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50)));

        LinearLayout otros = botonPildora(R.drawable.tb_folder_heart, "Documentos y comida en la web",
                TEAL, Color.TRANSPARENT, Color.TRANSPARENT);
        otros.setOnClickListener(v -> { cerrar(); acciones.abrirWeb(); });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46));
        lp.topMargin = dp(6);
        c.addView(otros, lp);
        return c;
    }

    private void cerrar() {
        if (dialogo != null) dialogo.dismiss();
    }

    // =====================================================================
    // Piezas de la vista (estilo de la web)
    // =====================================================================

    /** Tarjeta blanca de esquinas 20 y sombra suave (.fa-bloque). */
    private MaterialCardView tarjeta(int fondo, int radio) {
        MaterialCardView c = new MaterialCardView(ctx);
        c.setCardBackgroundColor(fondo);
        c.setRadius(dp(radio));
        c.setCardElevation(dp(3));
        c.setStrokeWidth(0);
        c.setUseCompatPadding(false);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(14);
        c.setLayoutParams(lp);
        return c;
    }

    /** Bloque con cabecera: icono en su color + título (cabBloque de la web). */
    private MaterialCardView bloque(@DrawableRes int icono, int color, String titulo, LinearLayout contenido) {
        MaterialCardView card = tarjeta(Color.WHITE, 20);
        LinearLayout b = vertical();
        b.setPadding(dp(16), dp(14), dp(16), dp(8));

        LinearLayout cab = new LinearLayout(ctx);
        cab.setOrientation(LinearLayout.HORIZONTAL);
        cab.setGravity(Gravity.CENTER_VERTICAL);
        cab.addView(iconoEnCuadro(icono, color, conAlfa(color, 31), 38, 20));
        TextView t = texto(titulo, 18, INK, R.font.jost_bold);
        t.setPadding(dp(12), 0, 0, 0);
        cab.addView(t);
        b.addView(cab);

        contenido.setOrientation(LinearLayout.VERTICAL);
        contenido.setPadding(0, dp(6), 0, 0);
        b.addView(contenido);
        card.addView(b);
        return card;
    }

    /** filaDato(): icono y etiqueta a la izquierda, valor en negrita a la derecha. */
    private View fila(@DrawableRes int icono, String etiqueta, String valor, boolean mal) {
        LinearLayout f = new LinearLayout(ctx);
        f.setOrientation(LinearLayout.HORIZONTAL);
        f.setGravity(Gravity.CENTER_VERTICAL);
        f.setPadding(0, dp(10), 0, dp(10));

        ImageView ic = icono(icono, MUTED, 17);
        f.addView(ic);
        TextView e = texto(etiqueta, 14, MUTED, R.font.poppins_regular);
        e.setPadding(dp(8), 0, dp(8), 0);
        f.addView(e, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.9f));

        TextView v = texto(valor, 14, mal ? CORAL_TXT : INK, R.font.poppins_semibold);
        v.setGravity(Gravity.END);
        v.setTextIsSelectable(true); // para copiar el chip o el teléfono
        LinearLayout.LayoutParams lv = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.1f);
        if (mal) {
            v.setPadding(dp(9), dp(3), dp(9), dp(3));
            GradientDrawable g = new GradientDrawable();
            g.setColor(CORAL_BG);
            g.setCornerRadius(dp(8));
            v.setBackground(g);
            lv = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        }
        f.addView(v, lv);
        return f;
    }

    private void agregarConLineas(LinearLayout destino, List<View> filas) {
        for (int i = 0; i < filas.size(); i++) {
            if (i > 0) {
                View l = new View(ctx);
                l.setBackgroundColor(LINEA);
                destino.addView(l, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Math.max(1, dp(1))));
            }
            destino.addView(filas.get(i));
        }
    }

    private View vacio(String txt) {
        TextView t = texto(txt, 13, MUTED, R.font.poppins_regular);
        t.setLineSpacing(0, 1.15f);
        t.setPadding(0, dp(4), 0, dp(8));
        return t;
    }

    private View iconoEnCuadro(@DrawableRes int icono, int color, int fondo, int tamDp, int iconoDp) {
        FrameLayout f = new FrameLayout(ctx);
        GradientDrawable g = new GradientDrawable();
        g.setColor(fondo);
        g.setCornerRadius(dp(12));
        f.setBackground(g);
        f.addView(icono(icono, color, iconoDp), new FrameLayout.LayoutParams(dp(iconoDp), dp(iconoDp), Gravity.CENTER));
        f.setLayoutParams(new LinearLayout.LayoutParams(dp(tamDp), dp(tamDp)));
        return f;
    }

    private ImageView icono(@DrawableRes int icono, int color, int tamDp) {
        ImageView i = new ImageView(ctx);
        i.setImageResource(icono);
        ImageViewCompat.setImageTintList(i, ColorStateList.valueOf(color));
        i.setLayoutParams(new LinearLayout.LayoutParams(dp(tamDp), dp(tamDp)));
        return i;
    }

    private LinearLayout botonPildora(@DrawableRes int icono, String txt, int color, int fondo, int borde) {
        LinearLayout b = new LinearLayout(ctx);
        b.setOrientation(LinearLayout.HORIZONTAL);
        b.setGravity(Gravity.CENTER);
        b.setBackground(pastilla(fondo, borde, borde == Color.TRANSPARENT ? 0 : 2));
        b.setClickable(true);
        b.setFocusable(true);
        b.addView(icono(icono, color, 19));
        TextView t = texto(txt, 15, color, R.font.poppins_semibold);
        t.setPadding(dp(8), 0, 0, 0);
        b.addView(t);
        return b;
    }

    private LinearLayout vertical() {
        LinearLayout l = new LinearLayout(ctx);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private TextView texto(String txt, int sp, int color, @FontRes int fuente) {
        TextView t = new TextView(ctx);
        t.setText(txt);
        t.setTextSize(sp);
        t.setTextColor(color);
        Typeface tf = ResourcesCompat.getFont(ctx, fuente);
        if (tf != null) t.setTypeface(tf);
        t.setIncludeFontPadding(false);
        return t;
    }

    private GradientDrawable pastilla(int fondo, int borde, int bordeDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fondo);
        g.setCornerRadius(dp(999));
        if (bordeDp > 0) {
            float den = ctx.getResources().getDisplayMetrics().density;
            g.setStroke(Math.max(1, Math.round(bordeDp * den * 0.75f)), borde);
        }
        return g;
    }

    private static int conAlfa(int color, int alfa) {
        return Color.argb(alfa, Color.red(color), Color.green(color), Color.blue(color));
    }

    private int dp(int v) {
        return Math.round(v * ctx.getResources().getDisplayMetrics().density);
    }

    // =====================================================================
    // Reglas de la web (colabella-mi-perfil.php)
    // =====================================================================

    private String s(String clave) {
        if (d.isNull(clave)) return "";
        return d.optString(clave, "").trim();
    }

    /** edadDe(): la edad sale de la fecha de nacimiento, así no se queda vieja. */
    private String edad() {
        Matcher m = Pattern.compile("^(\\d{4})-(\\d{2})-(\\d{2})$").matcher(s("nacimiento"));
        if (!m.find()) return s("edad");
        Calendar n = Calendar.getInstance();
        n.clear();
        n.set(Integer.parseInt(m.group(1)), Integer.parseInt(m.group(2)) - 1, Integer.parseInt(m.group(3)));
        Calendar h = Calendar.getInstance();
        int meses = (h.get(Calendar.YEAR) - n.get(Calendar.YEAR)) * 12
                + (h.get(Calendar.MONTH) - n.get(Calendar.MONTH))
                - (h.get(Calendar.DAY_OF_MONTH) < n.get(Calendar.DAY_OF_MONTH) ? 1 : 0);
        if (meses < 0) return "";
        if (meses >= 12) {
            int a = meses / 12;
            return a + " " + (a == 1 ? "año" : "años");
        }
        if (meses >= 1) return meses + " " + (meses == 1 ? "mes" : "meses");
        return "Menos de 1 mes";
    }

    private int fichaHechos() {
        int n = 0;
        for (String c : CAMPOS_FICHA) {
            if (!s(c).isEmpty()) n++;
        }
        return n;
    }

    private List<JSONObject> vacunas() {
        List<JSONObject> l = new ArrayList<>();
        JSONArray a = d.optJSONArray("vacunas");
        if (a == null) return l;
        for (int i = 0; i < a.length(); i++) {
            JSONObject v = a.optJSONObject(i);
            if (v != null) l.add(v);
        }
        return l;
    }

    private static final class Prox {
        final String nombre;
        final int dias;

        Prox(String nombre, int dias) {
            this.nombre = nombre;
            this.dias = dias;
        }
    }

    /** proximaVacuna(): la dosis que cae antes, aunque ya haya pasado. */
    private Prox proximaVacuna() {
        Prox mejor = null;
        for (JSONObject v : vacunas()) {
            Integer dd = diasHasta(v.optString("proxima"));
            if (dd == null) continue;
            if (mejor == null || dd < mejor.dias) {
                String n = v.optString("nombre");
                mejor = new Prox(n.isEmpty() ? "Vacuna" : n, dd);
            }
        }
        return mejor;
    }

    /** cuentaDosis(...).vencidas de vacunas + desparasitaciones. */
    private int vencidas() {
        int v = 0;
        for (JSONObject x : vacunas()) {
            Integer dd = diasHasta(x.optString("proxima"));
            if (dd != null && dd < 0) v++;
        }
        return v;
    }

    /** diasHasta(): días enteros desde hoy hasta la fecha; null si no hay fecha. */
    static Integer diasHasta(String txt) {
        long f = SincronizacionWeb.fecha(txt);
        if (f <= 0) return null;
        return diasDesdeHoy(f);
    }

    /** Días de calendario entre hoy y esa fecha (mañana = 1 aunque falten pocas horas). */
    static int diasDesdeHoy(long millis) {
        Calendar hoy = Calendar.getInstance();
        hoy.set(Calendar.HOUR_OF_DAY, 0);
        hoy.set(Calendar.MINUTE, 0);
        hoy.set(Calendar.SECOND, 0);
        hoy.set(Calendar.MILLISECOND, 0);
        Calendar d = Calendar.getInstance();
        d.setTimeInMillis(millis);
        d.set(Calendar.HOUR_OF_DAY, 0);
        d.set(Calendar.MINUTE, 0);
        d.set(Calendar.SECOND, 0);
        d.set(Calendar.MILLISECOND, 0);
        return Math.round((d.getTimeInMillis() - hoy.getTimeInMillis()) / 86400000f);
    }

    /** fechaCorta(): "2025-09-12" -> "12 sep 2025". */
    static String fechaCorta(String iso) {
        Matcher m = Pattern.compile("^(\\d{4})-(\\d{2})-(\\d{2})").matcher(iso == null ? "" : iso);
        if (!m.find()) return iso == null ? "" : iso;
        return Integer.parseInt(m.group(3)) + " " + MESES[Integer.parseInt(m.group(2)) - 1] + " " + m.group(1);
    }

    static boolean esDesparasitacion(String n) {
        return n != null && Pattern.compile("desparasit|antipulg|garrapat|pulga|lombri",
                Pattern.CASE_INSENSITIVE).matcher(n).find();
    }

    // =====================================================================
    // Foto o emoji, igual que el medallón de la web (.pp-av)
    // =====================================================================

    /** true si "tipo" es un emoji ("🐶") y no una palabra suelta ("perro"). */
    static boolean esEmoji(String tipo) {
        return tipo != null && !tipo.isEmpty() && !Pattern.compile("[a-z0-9]", Pattern.CASE_INSENSITIVE).matcher(tipo).find();
    }

    /**
     * Con foto: la foto en un cuadro de esquinas redondeadas. Sin foto: el emoji
     * del tipo, o la huella si el tipo es una palabra o está vacío (como la web).
     *
     * @param paddingDp margen del emoji dentro del cuadro
     * @param radioDp   esquinas del cuadro (el fondo de la vista debe tener las mismas)
     * @param bordeDp   borde blanco alrededor de la foto (0 = sin borde)
     */
    static void pintarFoto(ImageView vista, String url, String tipo, int paddingDp, int radioDp, int bordeDp) {
        Context c = vista.getContext();
        float den = c.getResources().getDisplayMetrics().density;
        Drawable sinFoto = emoji(c, esEmoji(tipo) ? tipo : "🐾");
        if (url != null && !url.isEmpty()) {
            int borde = Math.round(bordeDp * den);
            vista.setPadding(borde, borde, borde, borde);
            int radio = Math.max(1, Math.round((radioDp - bordeDp) * den));
            Glide.with(vista)
                    .load(url)
                    .transform(new CenterCrop(), new RoundedCorners(radio))
                    .error(sinFoto)
                    .into(vista);
            return;
        }
        Glide.with(vista).clear(vista);
        int pad = Math.round(paddingDp * den);
        vista.setPadding(pad, pad, pad, pad);
        vista.setImageDrawable(sinFoto);
    }

    /** Emojis ya dibujados: la lista no los vuelve a pintar cada vez que se desplaza. */
    private static final android.util.LruCache<String, Bitmap> EMOJIS = new android.util.LruCache<>(12);

    /** Dibuja un emoji como imagen, para poder ponerlo en un ImageView. */
    static Drawable emoji(Context c, String txt) {
        int tam = Math.round(64 * c.getResources().getDisplayMetrics().density);
        String clave = txt + "@" + tam;
        Bitmap bmp = EMOJIS.get(clave);
        if (bmp == null) {
            bmp = Bitmap.createBitmap(tam, tam, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bmp);
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setTextSize(tam * 0.78f);
            p.setTextAlign(Paint.Align.CENTER);
            Paint.FontMetrics fm = p.getFontMetrics();
            float y = tam / 2f - (fm.ascent + fm.descent) / 2f;
            canvas.drawText(txt, tam / 2f, y, p);
            EMOJIS.put(clave, bmp);
        }
        return new BitmapDrawable(c.getResources(), bmp);
    }
}
