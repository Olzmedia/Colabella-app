package com.colabellapetclub.app;

import android.Manifest;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.URLUtil;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.fragment.app.Fragment;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.progressindicator.LinearProgressIndicator;

import org.json.JSONObject;
import org.mozilla.geckoview.AllowOrDeny;
import org.mozilla.geckoview.GeckoResult;
import org.mozilla.geckoview.GeckoRuntime;
import org.mozilla.geckoview.GeckoRuntimeSettings;
import org.mozilla.geckoview.GeckoSession;
import org.mozilla.geckoview.GeckoSession.PermissionDelegate.ContentPermission;
import org.mozilla.geckoview.GeckoSession.PermissionDelegate.MediaSource;
import org.mozilla.geckoview.GeckoSession.PromptDelegate.PromptResponse;
import org.mozilla.geckoview.GeckoSessionSettings;
import org.mozilla.geckoview.GeckoView;
import org.mozilla.geckoview.WebExtension;
import org.mozilla.geckoview.WebRequestError;
import org.mozilla.geckoview.WebResponse;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Pestaña web con motor propio: GeckoView (el motor de Firefox) va dentro de la app,
 * asi que la web se ve igual en todos los telefonos con Android 8 o superior, sin
 * depender de la "Android System WebView" que tenga instalada cada uno.
 *
 * Hace lo mismo que WebFragment (que queda para Android 7):
 * - Navegacion interna; telefono, WhatsApp, mapas, pagos y Google/Apple salen fuera.
 * - Subida de fotos con "Tomar foto / Galeria", camara en vivo de la pagina.
 * - Menus desplegables, fechas, alert/confirm y compartir de la web (en GeckoView
 *   los dibuja la app; sin esto un <select> o un confirm() no harian nada).
 * - Descargas.
 * - Menu y mascotas de la cuenta: via la extension interna assets/colabella/
 *   (GeckoView no tiene addJavascriptInterface).
 * - Pantalla de reintento si no hay red, el certificado falla o la carga se cuelga.
 */
public class GeckoFragment extends Fragment implements Navegador {

    private static final String RUTA_SOCIAL_CANJE = "wp-json/club/v1/social/canjear?ticket=";
    private static final String ID_EXTENSION = "app@colabellapetclub.com";
    private static final String URL_EXTENSION = "resource://android/assets/colabella/";
    /** Nombre del canal entre la extension y la app (browser.runtime.connectNative). */
    private static final String APP_NATIVA = "browser";
    private static final long LIMITE_CARGA_MS = 30_000;

    // ---- Motor: uno solo por proceso, como exige GeckoView ----
    private static GeckoRuntime runtime;
    private static GeckoResult<WebExtension> extension;
    /** Caidas seguidas del motor; a la tercera se pasa a la WebView del sistema. */
    private static int caidas = 0;

    private FrameLayout contenedor;
    private GeckoView geckoView;
    private GeckoSession session;
    private View offlineView;
    private LinearProgressIndicator progreso;

    private WebFragment.MenuListener menuListener;
    private WebExtension.Port puerto;
    private boolean puedeAtras = false;
    private boolean loadError = false;
    private boolean canjeEnCurso = false;
    private String urlPendiente = null;
    private String urlActual = null;
    private int falloTitulo = R.string.offline_title;
    private int falloMensaje = R.string.offline_message;

    private final Handler principal = new Handler(Looper.getMainLooper());
    private final Runnable cargaVencida = () -> {
        if (!isAdded() || session == null) {
            return;
        }
        marcarFallo(R.string.fallo_lento_titulo, R.string.fallo_lento_mensaje);
        session.stop();
        mostrarOffline();
    };

    // ---- Subida de archivos ----
    private GeckoSession.PromptDelegate.FilePrompt promptArchivo;
    private GeckoResult<PromptResponse> resultadoArchivo;
    private Uri fotoCamaraUri;
    private ActivityResultLauncher<Intent> selectorArchivos;
    private ActivityResultLauncher<String> permisoCamaraSubida;
    private boolean subidaConCamaraPendiente = false;

    // ---- Permisos de Android que pide el motor (camara en vivo) ----
    private ActivityResultLauncher<String[]> permisosMotor;
    private GeckoSession.PermissionDelegate.Callback callbackPermisos;

    // =====================================================================
    // Ciclo de vida
    // =====================================================================

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        selectorArchivos = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    Uri[] elegidos = null;
                    if (result.getResultCode() == android.app.Activity.RESULT_OK) {
                        elegidos = leerResultado(result.getData());
                    }
                    responderArchivo(elegidos);
                });

        permisoCamaraSubida = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(),
                concedido -> {
                    if (!concedido) {
                        avisoCamaraNegada();
                    }
                    if (subidaConCamaraPendiente) {
                        subidaConCamaraPendiente = false;
                        abrirSelector(concedido);
                    }
                });

        permisosMotor = registerForActivityResult(
                new ActivityResultContracts.RequestMultiplePermissions(),
                resultado -> {
                    GeckoSession.PermissionDelegate.Callback cb = callbackPermisos;
                    callbackPermisos = null;
                    if (cb == null) {
                        return;
                    }
                    boolean todos = !resultado.isEmpty();
                    for (Boolean ok : resultado.values()) {
                        if (ok == null || !ok) {
                            todos = false;
                        }
                    }
                    if (todos) {
                        cb.grant();
                    } else {
                        cb.reject();
                        avisoCamaraNegada();
                    }
                });
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_gecko, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        contenedor = view.findViewById(R.id.gecko_contenedor);
        geckoView = view.findViewById(R.id.gecko);
        offlineView = view.findViewById(R.id.offline_view);
        progreso = view.findViewById(R.id.progreso);

        view.findViewById(R.id.btn_retry).setOnClickListener(v -> {
            offlineView.setVisibility(View.GONE);
            contenedor.setVisibility(View.VISIBLE);
            loadError = false;
            if (session == null) {
                abrirSesion(WebFragment.START_URL);
            } else {
                session.loadUri(urlActual != null && WebFragment.esDelSitio(Uri.parse(urlActual))
                        ? urlActual : WebFragment.START_URL);
            }
        });

        String inicial = urlPendiente != null ? urlPendiente : WebFragment.START_URL;
        urlPendiente = null;
        abrirSesion(inicial);
    }

    @Override
    public void onResume() {
        super.onResume();
        if (session != null) {
            session.setActive(true);
        }
    }

    @Override
    public void onPause() {
        if (session != null) {
            session.setActive(false);
        }
        super.onPause();
    }

    @Override
    public void onDestroyView() {
        principal.removeCallbacks(cargaVencida);
        cerrarSesion();
        geckoView = null;
        contenedor = null;
        offlineView = null;
        progreso = null;
        super.onDestroyView();
    }

    // =====================================================================
    // Motor y sesion
    // =====================================================================

    private static synchronized GeckoRuntime motor(Context ctx) {
        if (runtime == null) {
            boolean depurable = (ctx.getApplicationInfo().flags
                    & android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE) != 0;
            GeckoRuntimeSettings ajustes = new GeckoRuntimeSettings.Builder()
                    // Solo en el APK de prueba: about:debugging desde Firefox de escritorio
                    .remoteDebuggingEnabled(depurable)
                    .consoleOutput(depurable)
                    .aboutConfigEnabled(false)
                    .build();
            runtime = GeckoRuntime.create(ctx.getApplicationContext(), ajustes);
        }
        return runtime;
    }

    private static synchronized GeckoResult<WebExtension> extensionInterna(GeckoRuntime rt) {
        if (extension == null) {
            extension = rt.getWebExtensionController().ensureBuiltIn(URL_EXTENSION, ID_EXTENSION);
        }
        return extension;
    }

    private void abrirSesion(String url) {
        if (!isAdded() || geckoView == null) {
            urlPendiente = url;
            return;
        }
        GeckoRuntime rt = motor(requireContext());
        GeckoSessionSettings ajustes = new GeckoSessionSettings.Builder()
                // ColabellaApp: la web sabe que esta dentro de la app.
                // ColabellaSocial/1: la web muestra "Continuar con Google / Apple".
                .userAgentOverride(GeckoSession.getDefaultUserAgent()
                        + " ColabellaApp/1.0 ColabellaSocial/1")
                .useTrackingProtection(false)
                .build();
        final GeckoSession s = new GeckoSession(ajustes);
        s.setNavigationDelegate(navegacion);
        s.setProgressDelegate(progresoCarga);
        s.setContentDelegate(contenido);
        s.setPromptDelegate(dialogos);
        s.setPermissionDelegate(permisos);
        s.open(rt);
        geckoView.setSession(s);
        session = s;
        puedeAtras = false;

        // La extension (menu y mascotas) se conecta antes de cargar la primera pagina.
        // Si fallara, la web se carga igual: solo se pierde la sincronizacion.
        extensionInterna(rt).accept(ext -> {
            if (session == s && ext != null) {
                s.getWebExtensionController().setMessageDelegate(ext, mensajes, APP_NATIVA);
            }
            if (session == s) {
                s.loadUri(url);
            }
        }, error -> {
            if (session == s) {
                s.loadUri(url);
            }
        });
    }

    private void cerrarSesion() {
        puerto = null;
        if (geckoView != null) {
            geckoView.releaseSession();
        }
        if (session != null) {
            GeckoSession s = session;
            session = null;
            if (s.isOpen()) {
                s.close();
            }
        }
    }

    /** El proceso del motor se cerro. Se rehace la sesion; si se repite, se cambia de motor. */
    private void manejarCaida() {
        principal.removeCallbacks(cargaVencida);
        caidas++;
        if (!isAdded()) {
            return;
        }
        cerrarSesion();
        if (caidas >= 3) {
            Motor.desactivarGecko(requireContext());
            caidas = 0;
            requireActivity().recreate();
            return;
        }
        abrirSesion(urlActual != null && WebFragment.esDelSitio(Uri.parse(urlActual))
                ? urlActual : WebFragment.START_URL);
    }

    // =====================================================================
    // Navegacion
    // =====================================================================

    private final GeckoSession.NavigationDelegate navegacion = new GeckoSession.NavigationDelegate() {
        @Override
        public void onLocationChange(@NonNull GeckoSession s, @Nullable String url,
                                     @NonNull List<ContentPermission> perms,
                                     @NonNull Boolean hasUserGesture) {
            urlActual = url;
        }

        @Override
        public void onCanGoBack(@NonNull GeckoSession s, boolean canGoBack) {
            puedeAtras = canGoBack;
        }

        @Nullable
        @Override
        public GeckoResult<AllowOrDeny> onLoadRequest(@NonNull GeckoSession s,
                                                      @NonNull LoadRequest request) {
            Uri uri = Uri.parse(request.uri);
            String esquema = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase(Locale.ROOT);

            // Google y Apple nunca se cargan dentro: van a una pestaña de Chrome
            if (WebFragment.esInicioSocial(uri)) {
                if (isAdded()) {
                    Enlaces.abrirInicioSocial(requireContext(), uri);
                }
                return GeckoResult.fromValue(AllowOrDeny.DENY);
            }
            if (WebFragment.esDelSitio(uri)) {
                // target="_blank" o window.open del propio sitio: en la misma pestaña
                if (request.target == TARGET_WINDOW_NEW) {
                    s.loadUri(request.uri);
                    return GeckoResult.fromValue(AllowOrDeny.DENY);
                }
                return GeckoResult.fromValue(AllowOrDeny.ALLOW);
            }
            // Paginas internas del motor y contenido generado por la propia web
            if (esquema.equals("about") || esquema.equals("data") || esquema.equals("blob")
                    || esquema.equals("javascript") || esquema.equals("resource")
                    || esquema.equals("moz-extension") || esquema.isEmpty()) {
                return GeckoResult.fromValue(AllowOrDeny.ALLOW);
            }
            // Todo lo demas (otros sitios, tel:, whatsapp:, intent:...) se abre fuera
            if (isAdded()) {
                Enlaces.abrirFuera(requireContext(), uri);
            }
            return GeckoResult.fromValue(AllowOrDeny.DENY);
        }

        @Nullable
        @Override
        public GeckoResult<String> onLoadError(@NonNull GeckoSession s, @Nullable String uri,
                                               @NonNull WebRequestError error) {
            if (error.category == WebRequestError.ERROR_CATEGORY_SECURITY) {
                marcarFallo(R.string.fallo_ssl_titulo, R.string.fallo_ssl_mensaje);
            } else {
                marcarFallo(R.string.offline_title, R.string.offline_message);
            }
            mostrarOffline();
            return null;
        }
    };

    private final GeckoSession.ProgressDelegate progresoCarga = new GeckoSession.ProgressDelegate() {
        @Override
        public void onPageStart(@NonNull GeckoSession s, @NonNull String url) {
            if (url.startsWith("about:")) {
                return;
            }
            mostrarProgreso(5);
            if (!loadError) {
                falloTitulo = R.string.offline_title;
                falloMensaje = R.string.offline_message;
            }
            principal.removeCallbacks(cargaVencida);
            principal.postDelayed(cargaVencida, LIMITE_CARGA_MS);
        }

        @Override
        public void onPageStop(@NonNull GeckoSession s, boolean success) {
            principal.removeCallbacks(cargaVencida);
            ocultarProgreso();
            canjeEnCurso = false;
            if (loadError) {
                mostrarOffline();
                return;
            }
            if (success) {
                caidas = 0;
            }
        }

        @Override
        public void onProgressChange(@NonNull GeckoSession s, int nuevo) {
            if (nuevo >= 100) {
                ocultarProgreso();
            } else {
                mostrarProgreso(nuevo);
            }
        }
    };

    private final GeckoSession.ContentDelegate contenido = new GeckoSession.ContentDelegate() {
        @Override
        public void onCrash(@NonNull GeckoSession s) {
            manejarCaida();
        }

        @Override
        public void onKill(@NonNull GeckoSession s) {
            manejarCaida();
        }

        @Override
        public void onExternalResponse(@NonNull GeckoSession s, @NonNull WebResponse response) {
            descargar(response);
        }
    };

    // =====================================================================
    // Menu y mascotas: mensajes de la extension interna (assets/colabella/)
    // =====================================================================

    private final WebExtension.PortDelegate delegadoPuerto = new WebExtension.PortDelegate() {
        @Override
        public void onPortMessage(@NonNull Object message, @NonNull WebExtension.Port port) {
            if (port == puerto) {
                recibir(message);
            }
        }

        @Override
        public void onDisconnect(@NonNull WebExtension.Port port) {
            if (port == puerto) {
                puerto = null;
            }
        }
    };

    private final WebExtension.MessageDelegate mensajes = new WebExtension.MessageDelegate() {
        @Override
        public void onConnect(@NonNull WebExtension.Port port) {
            // Solo la pagina principal del propio sitio; nunca un iframe de terceros
            if (!port.sender.isTopLevel() || !WebFragment.esDelSitio(Uri.parse(port.sender.url))) {
                port.disconnect();
                return;
            }
            puerto = port;
            port.setDelegate(delegadoPuerto);
        }

        @Nullable
        @Override
        public GeckoResult<Object> onMessage(@NonNull String nativeApp, @NonNull Object message,
                                             @NonNull WebExtension.MessageSender sender) {
            if (sender.isTopLevel() && WebFragment.esDelSitio(Uri.parse(sender.url))) {
                recibir(message);
            }
            return null;
        }
    };

    private void recibir(Object message) {
        if (!(message instanceof JSONObject) || !isAdded()) {
            return;
        }
        JSONObject m = (JSONObject) message;
        String tipo = m.optString("tipo", "");
        String json = m.optString("json", "");
        if (json.isEmpty()) {
            return;
        }
        if ("menu".equals(tipo)) {
            if (menuListener != null) {
                menuListener.onMenuRecibido(json);
            }
        } else if ("mascotas".equals(tipo)) {
            if ("null".equals(json)) {
                guardarMascotasDeLaWeb(null);
                return;
            }
            List<Pet> lista = SincronizacionWeb.leerMascotas(json);
            if (lista != null) { // respuesta mal formada: se conserva lo que habia
                guardarMascotasDeLaWeb(lista);
            }
        }
    }

    /** Igual que en WebFragment: guarda las mascotas de la cuenta y sus recordatorios. */
    private void guardarMascotasDeLaWeb(@Nullable List<Pet> mascotas) {
        if (!isAdded()) {
            return;
        }
        Context ctx = requireContext().getApplicationContext();
        List<Pet> nuevas = mascotas != null ? mascotas : new ArrayList<>();
        List<Pet> quitadas = new PetStore(ctx).sincronizarWeb(nuevas);
        for (Pet p : quitadas) {
            p.proximaVacuna = 0; // cancela su recordatorio
            ReminderReceiver.programar(ctx, p);
        }
        for (Pet p : nuevas) {
            ReminderReceiver.programar(ctx, p);
        }
        if (menuListener != null) {
            menuListener.onMascotasActualizadas();
        }
    }

    // =====================================================================
    // Navegador (lo que usa MainActivity)
    // =====================================================================

    @Override
    public void setMenuListener(WebFragment.MenuListener listener) {
        this.menuListener = listener;
    }

    @Override
    public boolean puedeRetroceder() {
        return session != null && puedeAtras;
    }

    @Override
    public void retroceder() {
        if (session != null) {
            session.goBack();
        }
    }

    @Override
    public void cargar(String url) {
        if (url == null) {
            return;
        }
        Uri uri = Uri.parse(url);
        if (WebFragment.esInicioSocial(uri)) {
            if (isAdded()) {
                Enlaces.abrirInicioSocial(requireContext(), uri);
            }
            return;
        }
        if (!WebFragment.esDelSitio(uri)) {
            if (isAdded()) {
                Enlaces.abrirFuera(requireContext(), uri);
            }
            return;
        }
        if (session == null) {
            urlPendiente = url;
            return;
        }
        loadError = false;
        if (offlineView != null) {
            offlineView.setVisibility(View.GONE);
            contenedor.setVisibility(View.VISIBLE);
        }
        session.loadUri(url);
    }

    @Override
    public void canjearTicket(String ticket) {
        // GeckoView guarda la sesion (cookies) en disco por si mismo
        canjeEnCurso = true;
        cargar(WebFragment.START_URL + RUTA_SOCIAL_CANJE + ticket);
    }

    @Override
    public void sincronizarAhora() {
        if (puerto == null) {
            return;
        }
        try {
            JSONObject o = new JSONObject();
            o.put("accion", "sincronizar");
            puerto.postMessage(o);
        } catch (Exception ignorado) {
            // la proxima pagina vuelve a sincronizar sola
        }
    }

    // =====================================================================
    // Dialogos de la web: alert, confirm, prompt, <select>, fechas, compartir
    // =====================================================================

    /** Completa el resultado una sola vez (GeckoResult falla si se completa dos). */
    private static final class Respuesta {
        final GeckoResult<PromptResponse> resultado = new GeckoResult<>();
        private boolean hecha = false;

        /** La respuesta se crea solo si aun no se dio otra (confirm/dismiss marcan el prompt). */
        void dar(java.util.function.Supplier<PromptResponse> r) {
            if (!hecha) {
                hecha = true;
                resultado.complete(r.get());
            }
        }
    }

    private final GeckoSession.PromptDelegate dialogos = new GeckoSession.PromptDelegate() {

        @Nullable
        @Override
        public GeckoResult<PromptResponse> onAlertPrompt(@NonNull GeckoSession s,
                                                         @NonNull AlertPrompt prompt) {
            if (!isAdded()) {
                return GeckoResult.fromValue(prompt.dismiss());
            }
            Respuesta r = new Respuesta();
            new MaterialAlertDialogBuilder(requireContext())
                    .setTitle(prompt.title)
                    .setMessage(prompt.message)
                    .setPositiveButton(android.R.string.ok, (d, w) -> r.dar(() -> prompt.dismiss()))
                    .setOnDismissListener(d -> r.dar(() -> prompt.dismiss()))
                    .show();
            return r.resultado;
        }

        @Nullable
        @Override
        public GeckoResult<PromptResponse> onButtonPrompt(@NonNull GeckoSession s,
                                                          @NonNull ButtonPrompt prompt) {
            if (!isAdded()) {
                return GeckoResult.fromValue(prompt.dismiss());
            }
            Respuesta r = new Respuesta();
            new MaterialAlertDialogBuilder(requireContext())
                    .setTitle(prompt.title)
                    .setMessage(prompt.message)
                    .setPositiveButton(android.R.string.ok,
                            (d, w) -> r.dar(() -> prompt.confirm(ButtonPrompt.Type.POSITIVE)))
                    .setNegativeButton(R.string.cancelar,
                            (d, w) -> r.dar(() -> prompt.confirm(ButtonPrompt.Type.NEGATIVE)))
                    .setOnDismissListener(d -> r.dar(() -> prompt.confirm(ButtonPrompt.Type.NEGATIVE)))
                    .show();
            return r.resultado;
        }

        @Nullable
        @Override
        public GeckoResult<PromptResponse> onTextPrompt(@NonNull GeckoSession s,
                                                        @NonNull TextPrompt prompt) {
            if (!isAdded()) {
                return GeckoResult.fromValue(prompt.dismiss());
            }
            Respuesta r = new Respuesta();
            EditText campo = new EditText(requireContext());
            campo.setText(prompt.defaultValue);
            campo.setInputType(InputType.TYPE_CLASS_TEXT);
            FrameLayout marco = new FrameLayout(requireContext());
            int m = (int) (20 * getResources().getDisplayMetrics().density);
            marco.setPadding(m, m / 2, m, 0);
            marco.addView(campo);
            new MaterialAlertDialogBuilder(requireContext())
                    .setTitle(prompt.title)
                    .setMessage(prompt.message)
                    .setView(marco)
                    .setPositiveButton(android.R.string.ok,
                            (d, w) -> r.dar(() -> prompt.confirm(campo.getText().toString())))
                    .setNegativeButton(R.string.cancelar, (d, w) -> r.dar(() -> prompt.dismiss()))
                    .setOnDismissListener(d -> r.dar(() -> prompt.dismiss()))
                    .show();
            return r.resultado;
        }

        /** Los <select> de los formularios: sin esto no se abren. */
        @Nullable
        @Override
        public GeckoResult<PromptResponse> onChoicePrompt(@NonNull GeckoSession s,
                                                          @NonNull ChoicePrompt prompt) {
            if (!isAdded()) {
                return GeckoResult.fromValue(prompt.dismiss());
            }
            final List<ChoicePrompt.Choice> opciones = new ArrayList<>();
            aplanar(prompt.choices, opciones);
            if (opciones.isEmpty()) {
                return GeckoResult.fromValue(prompt.dismiss());
            }
            CharSequence[] textos = new CharSequence[opciones.size()];
            boolean[] marcadas = new boolean[opciones.size()];
            int elegida = -1;
            for (int i = 0; i < opciones.size(); i++) {
                textos[i] = opciones.get(i).label;
                marcadas[i] = opciones.get(i).selected;
                if (marcadas[i] && elegida < 0) {
                    elegida = i;
                }
            }
            Respuesta r = new Respuesta();
            MaterialAlertDialogBuilder b = new MaterialAlertDialogBuilder(requireContext())
                    .setTitle(prompt.title)
                    .setOnDismissListener(d -> r.dar(() -> prompt.dismiss()));
            if (prompt.type == ChoicePrompt.Type.MULTIPLE) {
                b.setMultiChoiceItems(textos, marcadas, (d, i, on) -> marcadas[i] = on)
                        .setPositiveButton(android.R.string.ok, (d, w) -> {
                            List<ChoicePrompt.Choice> sel = new ArrayList<>();
                            for (int i = 0; i < marcadas.length; i++) {
                                if (marcadas[i]) {
                                    sel.add(opciones.get(i));
                                }
                            }
                            r.dar(() -> prompt.confirm(sel.toArray(new ChoicePrompt.Choice[0])));
                        })
                        .setNegativeButton(R.string.cancelar, (d, w) -> r.dar(() -> prompt.dismiss()));
            } else {
                b.setSingleChoiceItems(textos, elegida, (d, i) -> {
                    r.dar(() -> prompt.confirm(opciones.get(i)));
                    d.dismiss();
                });
            }
            b.show();
            return r.resultado;
        }

        /** <input type="date">, "time", "month", "datetime-local". */
        @Nullable
        @Override
        public GeckoResult<PromptResponse> onDateTimePrompt(@NonNull GeckoSession s,
                                                            @NonNull DateTimePrompt prompt) {
            if (!isAdded()) {
                return GeckoResult.fromValue(prompt.dismiss());
            }
            Respuesta r = new Respuesta();
            Calendar c = Calendar.getInstance();
            int[] fecha = leerFecha(prompt.defaultValue);
            int[] hora = leerHora(prompt.defaultValue);
            if (fecha != null) {
                c.set(fecha[0], fecha[1] - 1, fecha[2]);
            }
            if (hora != null) {
                c.set(Calendar.HOUR_OF_DAY, hora[0]);
                c.set(Calendar.MINUTE, hora[1]);
            }
            final int tipo = prompt.type;

            if (tipo == DateTimePrompt.Type.TIME) {
                TimePickerDialog t = new TimePickerDialog(requireContext(),
                        (v, h, min) -> r.dar(() -> prompt.confirm(
                                String.format(Locale.ROOT, "%02d:%02d", h, min))),
                        c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), true);
                t.setOnDismissListener(d -> r.dar(() -> prompt.dismiss()));
                t.show();
                return r.resultado;
            }
            if (tipo == DateTimePrompt.Type.WEEK) {
                return GeckoResult.fromValue(prompt.dismiss());
            }

            DatePickerDialog dp = new DatePickerDialog(requireContext(), (v, y, mes, dia) -> {
                if (tipo == DateTimePrompt.Type.MONTH) {
                    r.dar(() -> prompt.confirm(String.format(Locale.ROOT, "%04d-%02d", y, mes + 1)));
                } else if (tipo == DateTimePrompt.Type.DATETIME_LOCAL) {
                    TimePickerDialog t = new TimePickerDialog(requireContext(),
                            (tv, h, min) -> r.dar(() -> prompt.confirm(String.format(Locale.ROOT,
                                    "%04d-%02d-%02dT%02d:%02d", y, mes + 1, dia, h, min))),
                            c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), true);
                    t.setOnDismissListener(d -> r.dar(() -> prompt.dismiss()));
                    t.show();
                } else {
                    r.dar(() -> prompt.confirm(String.format(Locale.ROOT, "%04d-%02d-%02d", y, mes + 1, dia)));
                }
            }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH));
            long min = milis(leerFecha(prompt.minValue));
            long max = milis(leerFecha(prompt.maxValue));
            if (min > 0) {
                dp.getDatePicker().setMinDate(min);
            }
            if (max > 0 && max >= min) {
                dp.getDatePicker().setMaxDate(max);
            }
            dp.setButton(DatePickerDialog.BUTTON_NEUTRAL, getString(R.string.quitar_fecha),
                    (d, w) -> r.dar(() -> prompt.confirm("")));
            // En DATETIME_LOCAL el dialogo de hora responde despues; el de fecha
            // solo responde si se cierra sin elegir nada.
            dp.setOnDismissListener(d -> {
                if (tipo != DateTimePrompt.Type.DATETIME_LOCAL) {
                    r.dar(() -> prompt.dismiss());
                }
            });
            dp.setOnCancelListener(d -> r.dar(() -> prompt.dismiss()));
            dp.show();
            return r.resultado;
        }

        @Nullable
        @Override
        public GeckoResult<PromptResponse> onFilePrompt(@NonNull GeckoSession s,
                                                        @NonNull FilePrompt prompt) {
            if (!isAdded()) {
                return GeckoResult.fromValue(prompt.dismiss());
            }
            // Si quedo un selector anterior sin responder, se cierra
            responderArchivo(null);
            promptArchivo = prompt;
            resultadoArchivo = new GeckoResult<>();
            GeckoResult<PromptResponse> devuelto = resultadoArchivo;

            boolean quiereFoto = aceptaImagenes(prompt.mimeTypes) && hayCamara();
            if (quiereFoto && !tienePermisoCamara()) {
                subidaConCamaraPendiente = true;
                permisoCamaraSubida.launch(Manifest.permission.CAMERA);
            } else {
                abrirSelector(quiereFoto);
            }
            return devuelto;
        }

        /** Ventanas emergentes: se dejan pasar y onLoadRequest decide donde se abren. */
        @Nullable
        @Override
        public GeckoResult<PromptResponse> onPopupPrompt(@NonNull GeckoSession s,
                                                         @NonNull PopupPrompt prompt) {
            return GeckoResult.fromValue(prompt.confirm(AllowOrDeny.ALLOW));
        }

        @Nullable
        @Override
        public GeckoResult<PromptResponse> onBeforeUnloadPrompt(@NonNull GeckoSession s,
                                                                @NonNull BeforeUnloadPrompt prompt) {
            return GeckoResult.fromValue(prompt.confirm(AllowOrDeny.ALLOW));
        }

        @Nullable
        @Override
        public GeckoResult<PromptResponse> onRepostConfirmPrompt(@NonNull GeckoSession s,
                                                                 @NonNull RepostConfirmPrompt prompt) {
            return GeckoResult.fromValue(prompt.confirm(AllowOrDeny.ALLOW));
        }

        /** navigator.share() de la web: menu de compartir de Android. */
        @Nullable
        @Override
        public GeckoResult<PromptResponse> onSharePrompt(@NonNull GeckoSession s,
                                                         @NonNull SharePrompt prompt) {
            if (!isAdded()) {
                return GeckoResult.fromValue(prompt.dismiss());
            }
            StringBuilder texto = new StringBuilder();
            if (prompt.text != null && !prompt.text.isEmpty()) {
                texto.append(prompt.text);
            }
            if (prompt.uri != null && !prompt.uri.isEmpty()) {
                if (texto.length() > 0) {
                    texto.append('\n');
                }
                texto.append(prompt.uri);
            }
            Intent i = new Intent(Intent.ACTION_SEND)
                    .setType("text/plain")
                    .putExtra(Intent.EXTRA_TEXT, texto.toString());
            if (prompt.title != null) {
                i.putExtra(Intent.EXTRA_SUBJECT, prompt.title);
            }
            try {
                startActivity(Intent.createChooser(i, prompt.title));
                return GeckoResult.fromValue(prompt.confirm(SharePrompt.Result.SUCCESS));
            } catch (ActivityNotFoundException e) {
                return GeckoResult.fromValue(prompt.confirm(SharePrompt.Result.FAILURE));
            }
        }
    };

    private static void aplanar(@Nullable GeckoSession.PromptDelegate.ChoicePrompt.Choice[] origen,
                                List<GeckoSession.PromptDelegate.ChoicePrompt.Choice> destino) {
        if (origen == null) {
            return;
        }
        for (GeckoSession.PromptDelegate.ChoicePrompt.Choice c : origen) {
            if (c.items != null) {
                aplanar(c.items, destino); // <optgroup>
            } else if (!c.disabled && !c.separator) {
                destino.add(c);
            }
        }
    }

    /** "2026-11-26" o "2026-11-26T10:30" -> {2026, 11, 26}. */
    @Nullable
    private static int[] leerFecha(@Nullable String v) {
        if (v == null || v.length() < 7) {
            return null;
        }
        try {
            String[] p = v.split("T")[0].split("-");
            int y = Integer.parseInt(p[0]);
            int m = Integer.parseInt(p[1]);
            int d = p.length > 2 ? Integer.parseInt(p[2]) : 1;
            return new int[]{y, m, d};
        } catch (Exception e) {
            return null;
        }
    }

    /** "10:30" o "2026-11-26T10:30" -> {10, 30}. */
    @Nullable
    private static int[] leerHora(@Nullable String v) {
        if (v == null) {
            return null;
        }
        String h = v.contains("T") ? v.substring(v.indexOf('T') + 1) : v;
        if (!h.contains(":")) {
            return null;
        }
        try {
            String[] p = h.split(":");
            return new int[]{Integer.parseInt(p[0]), Integer.parseInt(p[1].substring(0, 2))};
        } catch (Exception e) {
            return null;
        }
    }

    private static long milis(@Nullable int[] f) {
        if (f == null) {
            return 0;
        }
        Calendar c = Calendar.getInstance();
        c.clear();
        c.set(f[0], f[1] - 1, f[2]);
        return c.getTimeInMillis();
    }

    // =====================================================================
    // Permisos: camara en vivo de la pagina, reproduccion, almacenamiento
    // =====================================================================

    private final GeckoSession.PermissionDelegate permisos = new GeckoSession.PermissionDelegate() {

        /** El motor necesita un permiso de Android (la camara) para la pagina. */
        @Override
        public void onAndroidPermissionsRequest(@NonNull GeckoSession s,
                                                @Nullable String[] pedidos,
                                                @NonNull Callback callback) {
            if (!isAdded() || pedidos == null) {
                callback.reject();
                return;
            }
            List<String> faltan = new ArrayList<>();
            for (String p : pedidos) {
                if (ContextCompat.checkSelfPermission(requireContext(), p)
                        == PackageManager.PERMISSION_GRANTED) {
                    continue;
                }
                // La app solo declara la camara: el resto (microfono, ubicacion) no se concede
                if (!Manifest.permission.CAMERA.equals(p)) {
                    callback.reject();
                    return;
                }
                faltan.add(p);
            }
            if (faltan.isEmpty()) {
                callback.grant();
                return;
            }
            if (callbackPermisos != null) {
                callbackPermisos.reject();
            }
            callbackPermisos = callback;
            permisosMotor.launch(faltan.toArray(new String[0]));
        }

        /** Camara en vivo (getUserMedia): solo para nuestro sitio y solo video. */
        @Override
        public void onMediaPermissionRequest(@NonNull GeckoSession s, @NonNull String uri,
                                             @Nullable MediaSource[] video,
                                             @Nullable MediaSource[] audio,
                                             @NonNull MediaCallback callback) {
            if (video == null || video.length == 0 || !WebFragment.esDelSitio(Uri.parse(uri))) {
                callback.reject();
                return;
            }
            MediaSource camara = video[0];
            for (MediaSource m : video) {
                if (m.source == MediaSource.SOURCE_CAMERA) {
                    camara = m;
                    break;
                }
            }
            callback.grant(camara, null);
        }

        @Nullable
        @Override
        public GeckoResult<Integer> onContentPermissionRequest(@NonNull GeckoSession s,
                                                               @NonNull ContentPermission perm) {
            switch (perm.permission) {
                case PERMISSION_AUTOPLAY_AUDIBLE:
                case PERMISSION_AUTOPLAY_INAUDIBLE:
                case PERMISSION_PERSISTENT_STORAGE:
                case PERMISSION_STORAGE_ACCESS:
                case PERMISSION_MEDIA_KEY_SYSTEM_ACCESS:
                    return GeckoResult.fromValue(ContentPermission.VALUE_ALLOW);
                default:
                    // Ubicacion, notificaciones web, etc.: la app no los usa
                    return GeckoResult.fromValue(ContentPermission.VALUE_DENY);
            }
        }
    };

    // =====================================================================
    // Subida de fotos: menu "Tomar foto / Galeria", igual que WebFragment
    // =====================================================================

    private void abrirSelector(boolean conCamara) {
        GeckoSession.PromptDelegate.FilePrompt prompt = promptArchivo;
        if (!isAdded() || prompt == null) {
            return;
        }
        Intent galeria = new Intent(Intent.ACTION_GET_CONTENT);
        galeria.addCategory(Intent.CATEGORY_OPENABLE);
        galeria.setType(tipoGaleria(prompt.mimeTypes));
        if (prompt.type == GeckoSession.PromptDelegate.FilePrompt.Type.MULTIPLE) {
            galeria.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        }

        Intent camara = conCamara ? crearIntentCamara() : null;
        if (camara == null) {
            lanzar(galeria);
            return;
        }
        // <input capture>: la web quiere la camara directamente
        if (prompt.capture != GeckoSession.PromptDelegate.FilePrompt.Capture.NONE) {
            lanzar(camara);
            return;
        }
        final boolean[] elegido = {false};
        new MaterialAlertDialogBuilder(requireContext())
                .setTitle(R.string.subir_titulo)
                .setItems(new CharSequence[]{
                        getString(R.string.subir_camara),
                        getString(R.string.subir_galeria)
                }, (d, cual) -> {
                    elegido[0] = true;
                    if (cual == 0) {
                        lanzar(camara);
                    } else {
                        fotoCamaraUri = null;
                        lanzar(galeria);
                    }
                })
                .setOnDismissListener(d -> {
                    if (!elegido[0]) {
                        responderArchivo(null);
                    }
                })
                .show();
    }

    private void lanzar(Intent intent) {
        try {
            selectorArchivos.launch(intent);
        } catch (ActivityNotFoundException e) {
            aviso(getString(R.string.no_file_app));
            responderArchivo(null);
        }
    }

    /** Entrega a la web lo elegido (o nada) y libera el selector. */
    private void responderArchivo(@Nullable Uri[] elegidos) {
        GeckoSession.PromptDelegate.FilePrompt prompt = promptArchivo;
        GeckoResult<PromptResponse> resultado = resultadoArchivo;
        promptArchivo = null;
        resultadoArchivo = null;
        fotoCamaraUri = null;
        if (prompt == null || resultado == null) {
            return;
        }
        if (elegidos == null || elegidos.length == 0 || !isAdded()) {
            resultado.complete(prompt.dismiss());
        } else {
            resultado.complete(prompt.confirm(requireContext(), elegidos));
        }
    }

    @Nullable
    private Intent crearIntentCamara() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (intent.resolveActivity(requireContext().getPackageManager()) == null) {
            return null;
        }
        try {
            File carpeta = new File(requireContext().getCacheDir(), "camara");
            if (!carpeta.exists() && !carpeta.mkdirs()) {
                return null;
            }
            String nombre = "IMG_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US)
                    .format(new Date()) + ".jpg";
            fotoCamaraUri = FileProvider.getUriForFile(requireContext(),
                    requireContext().getPackageName() + ".fotos", new File(carpeta, nombre));
            intent.putExtra(MediaStore.EXTRA_OUTPUT, fotoCamaraUri);
            intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            return intent;
        } catch (Exception e) {
            fotoCamaraUri = null;
            return null;
        }
    }

    @Nullable
    private Uri[] leerResultado(@Nullable Intent data) {
        if (data != null && data.getClipData() != null && data.getClipData().getItemCount() > 0) {
            List<Uri> lista = new ArrayList<>();
            for (int i = 0; i < data.getClipData().getItemCount(); i++) {
                Uri u = data.getClipData().getItemAt(i).getUri();
                if (u != null) {
                    lista.add(u);
                }
            }
            if (!lista.isEmpty()) {
                return lista.toArray(new Uri[0]);
            }
        }
        if (data != null && data.getData() != null) {
            return new Uri[]{data.getData()};
        }
        if (fotoCamaraUri != null) {
            return new Uri[]{fotoCamaraUri};
        }
        return null;
    }

    /** "image/*" si el campo solo pide imagenes; si no, cualquier archivo. */
    private static String tipoGaleria(@Nullable String[] tipos) {
        if (tipos == null || tipos.length == 0) {
            return "*/*";
        }
        for (String t : tipos) {
            if (t == null || !t.trim().toLowerCase(Locale.ROOT).startsWith("image")) {
                return "*/*";
            }
        }
        return "image/*";
    }

    private static boolean aceptaImagenes(@Nullable String[] tipos) {
        if (tipos == null) {
            return true;
        }
        boolean algunTipo = false;
        for (String grupo : tipos) {
            if (grupo == null) {
                continue;
            }
            for (String t : grupo.split(",")) {
                String tipo = t.trim().toLowerCase(Locale.ROOT);
                if (tipo.isEmpty()) {
                    continue;
                }
                algunTipo = true;
                if (tipo.startsWith("image") || tipo.equals("*/*")
                        || tipo.equals(".jpg") || tipo.equals(".jpeg") || tipo.equals(".png")
                        || tipo.equals(".webp") || tipo.equals(".heic")) {
                    return true;
                }
            }
        }
        return !algunTipo;
    }

    private boolean hayCamara() {
        return requireContext().getPackageManager()
                .hasSystemFeature(PackageManager.FEATURE_CAMERA_ANY);
    }

    private boolean tienePermisoCamara() {
        return ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void avisoCamaraNegada() {
        if (!isAdded()) {
            return;
        }
        if (shouldShowRequestPermissionRationale(Manifest.permission.CAMERA)) {
            aviso(getString(R.string.camara_sin_permiso));
            return;
        }
        Toast.makeText(requireContext(), R.string.camara_bloqueada, Toast.LENGTH_LONG).show();
        try {
            startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.fromParts("package", requireContext().getPackageName(), null)));
        } catch (Exception ignorado) {
            // Sin pantalla de ajustes: el aviso ya basta
        }
    }

    // =====================================================================
    // Descargas (PDF, comprobantes...): se guardan y se abren con su app
    // =====================================================================

    private void descargar(WebResponse r) {
        if (!isAdded()) {
            return;
        }
        final Context app = requireContext().getApplicationContext();
        final InputStream cuerpo = r.body;
        if (cuerpo == null) {
            if (r.uri != null && r.uri.startsWith("https://")) {
                Enlaces.abrirFuera(requireContext(), Uri.parse(r.uri));
            }
            return;
        }
        String disposicion = cabecera(r.headers, "content-disposition");
        String tipo = cabecera(r.headers, "content-type");
        final String mime = tipo != null ? tipo.split(";")[0].trim() : "application/octet-stream";
        final String nombre = URLUtil.guessFileName(r.uri, disposicion, mime)
                .replaceAll("[\\\\/:*?\"<>|]", "_");
        aviso(getString(R.string.downloading));

        new Thread(() -> {
            Uri listo = null;
            try {
                File carpeta = new File(app.getCacheDir(), "descargas");
                if (!carpeta.exists() && !carpeta.mkdirs()) {
                    throw new IllegalStateException("sin carpeta");
                }
                File destino = new File(carpeta, nombre);
                try (InputStream in = cuerpo; OutputStream out = new FileOutputStream(destino)) {
                    byte[] buf = new byte[16 * 1024];
                    int n;
                    while ((n = in.read(buf)) != -1) {
                        out.write(buf, 0, n);
                    }
                }
                listo = FileProvider.getUriForFile(app, app.getPackageName() + ".fotos", destino);
            } catch (Exception e) {
                listo = null;
            }
            final Uri uri = listo;
            principal.post(() -> abrirDescarga(uri, mime));
        }).start();
    }

    private void abrirDescarga(@Nullable Uri uri, String mime) {
        if (!isAdded()) {
            return;
        }
        if (uri == null) {
            aviso(getString(R.string.cannot_open_link));
            return;
        }
        Intent ver = new Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, mime)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            startActivity(Intent.createChooser(ver, null));
        } catch (ActivityNotFoundException e) {
            aviso(getString(R.string.cannot_open_link));
        }
    }

    @Nullable
    private static String cabecera(@Nullable Map<String, String> cabeceras, String nombre) {
        if (cabeceras == null) {
            return null;
        }
        for (Map.Entry<String, String> e : cabeceras.entrySet()) {
            if (e.getKey() != null && e.getKey().equalsIgnoreCase(nombre)) {
                return e.getValue();
            }
        }
        return null;
    }

    // =====================================================================
    // Progreso y pantalla de fallo
    // =====================================================================

    private void mostrarProgreso(int valor) {
        if (progreso == null) {
            return;
        }
        if (progreso.getVisibility() != View.VISIBLE) {
            progreso.setProgressCompat(0, false);
            progreso.setVisibility(View.VISIBLE);
        }
        progreso.setProgressCompat(Math.max(valor, 5), true);
    }

    private void ocultarProgreso() {
        if (progreso != null) {
            progreso.setVisibility(View.GONE);
        }
    }

    private void marcarFallo(int titulo, int mensaje) {
        falloTitulo = titulo;
        falloMensaje = mensaje;
        loadError = true;
    }

    private void mostrarOffline() {
        if (offlineView == null || contenedor == null || !isAdded()) {
            return;
        }
        principal.removeCallbacks(cargaVencida);
        ocultarProgreso();
        contenedor.setVisibility(View.GONE);
        TextView titulo = offlineView.findViewById(R.id.offline_titulo);
        TextView mensaje = offlineView.findViewById(R.id.offline_mensaje);
        if (titulo != null) {
            titulo.setText(falloTitulo);
        }
        if (mensaje != null) {
            mensaje.setText(falloMensaje);
        }
        offlineView.setVisibility(View.VISIBLE);
    }

    private void aviso(String msg) {
        if (isAdded()) {
            Toast.makeText(requireContext(), msg, Toast.LENGTH_SHORT).show();
        }
    }
}
