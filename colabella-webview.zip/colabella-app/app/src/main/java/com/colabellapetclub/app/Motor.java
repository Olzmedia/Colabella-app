package com.colabellapetclub.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.os.Build;

import androidx.fragment.app.Fragment;

/**
 * Elige el motor de la pestaña web.
 *
 * - Android 8 o superior: GeckoView, el motor de Firefox que va DENTRO de la app.
 *   La web se ve igual en todos los telefonos, tengan la WebView del sistema
 *   actualizada o no (la causa de la pantalla en blanco en el Redmi Note 11).
 * - Android 7: GeckoView ya no funciona ahi (Mozilla exige Android 8 desde la
 *   version 144), asi que se usa la WebView del sistema.
 *
 * Si GeckoView se cae varias veces seguidas en un telefono, la app pasa sola a
 * la WebView del sistema hasta la proxima version de la app.
 *
 * Esta clase no toca ninguna clase de GeckoView a proposito: se carga tambien
 * en Android 7, donde esas clases no deben usarse.
 */
public final class Motor {

    private static final String PREFS = "motor";
    private static final String CLAVE_DESACTIVADO = "gecko_desactivado_en_version";
    private static final String[] ABIS_GECKO = {"arm64-v8a", "armeabi-v7a", "x86_64"};

    private Motor() {
    }

    /** true si esta app usara GeckoView en este telefono. */
    public static boolean usaGecko(Context ctx) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O || !abiCompatible()) {
            return false;
        }
        SharedPreferences p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        return p.getLong(CLAVE_DESACTIVADO, -1) != versionApp(ctx);
    }

    /** GeckoView fallo en este telefono: se usa la WebView hasta la proxima version. */
    public static void desactivarGecko(Context ctx) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putLong(CLAVE_DESACTIVADO, versionApp(ctx))
                .apply();
    }

    /** El fragmento web que corresponde a este telefono. */
    public static Fragment crearFragmentoWeb(Context ctx) {
        return usaGecko(ctx) ? new GeckoFragment() : new WebFragment();
    }

    /** true si el fragmento restaurado ya es del motor que toca. */
    public static boolean esDelMotorActual(Context ctx, Fragment f) {
        return usaGecko(ctx) ? f instanceof GeckoFragment : f instanceof WebFragment;
    }

    private static boolean abiCompatible() {
        for (String abi : Build.SUPPORTED_ABIS) {
            for (String g : ABIS_GECKO) {
                if (g.equals(abi)) {
                    return true;
                }
            }
        }
        return false;
    }

    @SuppressWarnings("deprecation")
    private static long versionApp(Context ctx) {
        try {
            PackageInfo pi = ctx.getPackageManager().getPackageInfo(ctx.getPackageName(), 0);
            return Build.VERSION.SDK_INT >= Build.VERSION_CODES.P
                    ? pi.getLongVersionCode() : pi.versionCode;
        } catch (Exception e) {
            return 0;
        }
    }
}
