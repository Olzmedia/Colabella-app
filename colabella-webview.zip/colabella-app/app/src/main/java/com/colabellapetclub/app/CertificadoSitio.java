package com.colabellapetclub.app;

import android.content.Context;
import android.net.Uri;
import android.net.http.SslCertificate;
import android.net.http.SslError;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.Nullable;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.security.KeyStore;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.Collection;
import java.util.List;
import java.util.Locale;

import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;

/**
 * Verificacion propia del certificado de colabellapetclub.com para el WebView.
 *
 * El certificado del sitio lo emite SSL.com y llega a la raiz "SSL.com TLS RSA
 * Root CA 2022", que Android 13 y anteriores no traen: el WebView rechaza la
 * conexion (SSL_UNTRUSTED) y la pagina sale en blanco.
 *
 * Cuando eso pasa, se valida la cadena aqui con la raiz y el intermedio que lleva
 * la app (res/raw, comprobados por su huella SHA-256). Solo se acepta si:
 *  - la direccion es https de colabellapetclub.com (o un subdominio),
 *  - el unico problema que ve Android es "emisor no reconocido" (SSL_UNTRUSTED):
 *    nunca un certificado vencido, de otro dominio o con fecha invalida,
 *  - el certificado es del dominio, esta vigente y lo firma SSL.com TLS Issuing
 *    RSA CA R1 -> SSL.com TLS RSA Root CA 2022 (validacion PKIX completa).
 * Cualquier otro caso se sigue bloqueando.
 */
final class CertificadoSitio {

    /** Huellas SHA-256 esperadas de los certificados que lleva la app. */
    private static final String HUELLA_RAIZ =
            "8faf7d2e2cb4709bb8e0b33666bf75a5dd45b5de480f8ea8d4bfe6bebc17f2ed";
    private static final String HUELLA_INTERMEDIO =
            "bfbc39e9fa2b84c9a92337e2344ee2381d8d3d3ae8ea75ef4e48e5807ed80c69";

    private static X509TrustManager confianza;
    private static X509Certificate intermedio;

    private CertificadoSitio() {
    }

    /** true si el WebView puede seguir: es nuestro sitio con su cadena SSL.com valida. */
    static boolean confiable(Context ctx, @Nullable SslError error) {
        try {
            if (error == null || error.getPrimaryError() != SslError.SSL_UNTRUSTED) {
                return false;
            }
            String url = error.getUrl();
            if (url == null || !WebFragment.esDelSitio(Uri.parse(url))) {
                return false;
            }
            String host = Uri.parse(url).getHost();
            X509Certificate hoja = certificadoDe(error.getCertificate());
            if (hoja == null || host == null || !coincideHost(hoja, host)) {
                return false;
            }
            cargar(ctx);
            // Validacion PKIX: firmas, vigencia, restricciones y uso del certificado
            confianza.checkServerTrusted(new X509Certificate[]{hoja, intermedio}, "RSA");
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private static synchronized void cargar(Context ctx) throws Exception {
        if (confianza != null) {
            return;
        }
        X509Certificate raiz = leer(ctx, R.raw.sslcom_root_2022, HUELLA_RAIZ);
        X509Certificate inter = leer(ctx, R.raw.sslcom_issuing_r1, HUELLA_INTERMEDIO);

        KeyStore ks = KeyStore.getInstance(KeyStore.getDefaultType());
        ks.load(null, null);
        ks.setCertificateEntry("sslcom-root-2022", raiz);
        TrustManagerFactory tmf = TrustManagerFactory.getInstance(
                TrustManagerFactory.getDefaultAlgorithm());
        tmf.init(ks);
        for (TrustManager tm : tmf.getTrustManagers()) {
            if (tm instanceof X509TrustManager) {
                confianza = (X509TrustManager) tm;
                break;
            }
        }
        if (confianza == null) {
            throw new IllegalStateException("sin TrustManager");
        }
        intermedio = inter;
    }

    private static X509Certificate leer(Context ctx, int recurso, String huella) throws Exception {
        try (InputStream in = ctx.getResources().openRawResource(recurso)) {
            X509Certificate c = (X509Certificate) CertificateFactory.getInstance("X.509")
                    .generateCertificate(in);
            if (!huella.equals(sha256(c.getEncoded()))) {
                throw new SecurityException("huella inesperada");
            }
            return c;
        }
    }

    /** El X509 del certificado que mostro el servidor. */
    @Nullable
    @SuppressWarnings("deprecation")
    private static X509Certificate certificadoDe(@Nullable SslCertificate c) {
        if (c == null) {
            return null;
        }
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                return c.getX509Certificate();
            }
            // Android 7-9: el certificado viaja en el Bundle que genera saveState
            Bundle b = SslCertificate.saveState(c);
            byte[] der = b != null ? b.getByteArray("x509-certificate") : null;
            if (der == null) {
                return null;
            }
            Certificate cert = CertificateFactory.getInstance("X.509")
                    .generateCertificate(new ByteArrayInputStream(der));
            return cert instanceof X509Certificate ? (X509Certificate) cert : null;
        } catch (Exception e) {
            return null;
        }
    }

    /** El host aparece en los nombres del certificado (admite un comodin *.dominio). */
    private static boolean coincideHost(X509Certificate c, String host) throws Exception {
        Collection<List<?>> nombres = c.getSubjectAlternativeNames();
        if (nombres == null) {
            return false;
        }
        String h = host.toLowerCase(Locale.ROOT);
        for (List<?> n : nombres) {
            if (n.size() < 2 || !(n.get(0) instanceof Integer) || (Integer) n.get(0) != 2) {
                continue; // 2 = dNSName
            }
            String dns = String.valueOf(n.get(1)).toLowerCase(Locale.ROOT);
            if (dns.equals(h)) {
                return true;
            }
            if (dns.startsWith("*.")) {
                String base = dns.substring(1); // ".colabellapetclub.com"
                if (h.endsWith(base) && h.indexOf('.') == h.length() - base.length()) {
                    return true;
                }
            }
        }
        return false;
    }

    private static String sha256(byte[] datos) throws Exception {
        byte[] d = java.security.MessageDigest.getInstance("SHA-256").digest(datos);
        StringBuilder sb = new StringBuilder();
        for (byte x : d) {
            sb.append(String.format(Locale.ROOT, "%02x", x));
        }
        return sb.toString();
    }
}
