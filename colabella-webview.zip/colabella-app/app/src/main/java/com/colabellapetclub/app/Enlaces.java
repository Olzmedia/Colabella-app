package com.colabellapetclub.app;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;

import androidx.browser.customtabs.CustomTabColorSchemeParams;
import androidx.browser.customtabs.CustomTabsClient;
import androidx.browser.customtabs.CustomTabsIntent;
import androidx.core.content.ContextCompat;

/**
 * Enlaces que salen de la app (telefono, WhatsApp, mapas, pagos, Google/Apple).
 * Lo usan los dos motores, WebFragment y GeckoFragment, para que se comporten igual.
 */
final class Enlaces {

    private Enlaces() {
    }

    /**
     * Abre el inicio de sesion con Google o Apple en una pestaña de Chrome (o del
     * navegador que admita pestañas personalizadas). Si no hay ninguno, en el
     * navegador normal.
     */
    static void abrirInicioSocial(Context ctx, Uri uri) {
        String navegador = CustomTabsClient.getPackageName(ctx, null);
        if (navegador != null) {
            try {
                int marca = ContextCompat.getColor(ctx, R.color.brand_primary);
                CustomTabsIntent pestana = new CustomTabsIntent.Builder()
                        .setShowTitle(true)
                        .setDefaultColorSchemeParams(new CustomTabColorSchemeParams.Builder()
                                .setToolbarColor(marca)
                                .setNavigationBarColor(marca)
                                .build())
                        .build();
                pestana.intent.setPackage(navegador);
                pestana.launchUrl(ctx, uri);
                return;
            } catch (ActivityNotFoundException ignorado) {
                // sigue con el navegador normal
            }
        }
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, uri);
            i.addCategory(Intent.CATEGORY_BROWSABLE);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            ctx.startActivity(i);
        } catch (ActivityNotFoundException e) {
            aviso(ctx, R.string.cannot_open_link);
        }
    }

    static void abrirFuera(Context ctx, Uri uri) {
        if ("intent".equalsIgnoreCase(uri.getScheme())) {
            abrirIntent(ctx, uri.toString());
            return;
        }
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, uri);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            ctx.startActivity(i);
        } catch (ActivityNotFoundException e) {
            aviso(ctx, R.string.cannot_open_link);
        }
    }

    /**
     * Enlaces intent:// (WhatsApp, apps de pago...). Se limpian para que una pagina
     * no pueda lanzar componentes internos de la app ni de otras apps.
     */
    static void abrirIntent(Context ctx, String url) {
        Intent intent;
        try {
            intent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME);
        } catch (Exception e) {
            aviso(ctx, R.string.cannot_open_link);
            return;
        }
        intent.addCategory(Intent.CATEGORY_BROWSABLE);
        intent.setComponent(null);
        intent.setSelector(null);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            ctx.startActivity(intent);
        } catch (ActivityNotFoundException e) {
            String alternativa = intent.getStringExtra("browser_fallback_url");
            if (alternativa != null && alternativa.startsWith("https://")) {
                abrirFuera(ctx, Uri.parse(alternativa));
            } else {
                aviso(ctx, R.string.cannot_open_link);
            }
        }
    }

    private static void aviso(Context ctx, int texto) {
        Toast.makeText(ctx, texto, Toast.LENGTH_SHORT).show();
    }
}
