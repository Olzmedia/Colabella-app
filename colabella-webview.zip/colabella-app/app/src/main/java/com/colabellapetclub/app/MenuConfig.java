package com.colabellapetclub.app;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * El menu de la barra inferior lo define el sitio segun el usuario que ha entrado
 * (visitante, socio o negocio). La app solo lo pinta.
 *
 * El ultimo menu recibido se guarda para que al abrir sin conexion la barra
 * no aparezca vacia.
 */
public class MenuConfig {

    public static class Item {
        public String id;
        public String titulo;
        public String url;
        public String icono;
        public boolean nativo;
    }

    private static final String PREFS = "colabella_menu";
    private static final String KEY_JSON = "menu_json";
    private static final String KEY_ROL = "rol";

    public String rol = "visitante";
    public final List<Item> items = new ArrayList<>();

    /** Menu de reserva: lo que se muestra antes de que el sitio conteste. */
    public static MenuConfig porDefecto() {
        MenuConfig m = new MenuConfig();
        m.rol = "visitante";
        m.items.add(crear("inicio", "Inicio", WebFragment.START_URL, "home", false));
        m.items.add(crear("planes", "Planes", WebFragment.START_URL + "planes/", "plans", false));
        m.items.add(crear("mapa", "Mapa", WebFragment.START_URL + "mapa/", "map", false));
        m.items.add(crear("negocios", "Negocios", WebFragment.START_URL + "negocios/", "store", false));
        m.items.add(crear("acceso", "Entrar", WebFragment.START_URL + "acceso/", "user", false));
        m.asegurarMascotas();
        return m;
    }

    /**
     * La ficha de mascotas es la parte nativa de la app (funciona sin internet y
     * programa los recordatorios). Google revisa que la app aporte algo mas que
     * la web, asi que esta pestaña tiene que estar siempre en la barra, sea cual
     * sea el menu que mande el sitio.
     *
     * Si el sitio no la incluye, se coloca justo antes del ultimo boton (que suele
     * ser "Entrar" o "Perfil"). Si ya habia 5 botones, sustituye al cuarto.
     */
    void asegurarMascotas() {
        for (Item i : items) {
            if (i.nativo) {
                return;
            }
        }
        Item mascotas = crear("mascotas", "Mascotas", null, "pets", true);
        if (items.isEmpty()) {
            items.add(mascotas);
        } else if (items.size() >= 5) {
            items.set(3, mascotas);
        } else {
            items.add(items.size() - 1, mascotas);
        }
    }

    private static Item crear(String id, String titulo, String url, String icono, boolean nativo) {
        Item i = new Item();
        i.id = id;
        i.titulo = titulo;
        i.url = url;
        i.icono = icono;
        i.nativo = nativo;
        return i;
    }

    /**
     * Lee el JSON que publica el sitio. Devuelve null si viene vacio o mal formado,
     * para que la app conserve el menu que ya tenia.
     */
    public static MenuConfig desdeJson(String json) {
        if (json == null || json.trim().isEmpty() || "null".equals(json.trim())) {
            return null;
        }
        try {
            JSONObject raiz = new JSONObject(json);
            JSONArray arr = raiz.optJSONArray("items");
            if (arr == null || arr.length() == 0) {
                return null;
            }
            MenuConfig m = new MenuConfig();
            m.rol = raiz.optString("rol", "visitante");
            // La barra inferior solo se ve bien hasta cinco destinos
            int max = Math.min(arr.length(), 5);
            for (int i = 0; i < max; i++) {
                JSONObject o = arr.getJSONObject(i);
                Item it = new Item();
                it.id = o.optString("id", "item" + i);
                it.titulo = o.optString("titulo", "");
                it.url = o.isNull("url") ? null : o.optString("url", null);
                it.icono = o.optString("icono", "home");
                it.nativo = o.optBoolean("nativo", false);
                if (!it.titulo.isEmpty() && (it.nativo || it.url != null)) {
                    m.items.add(it);
                }
            }
            if (m.items.isEmpty()) {
                return null;
            }
            m.asegurarMascotas();
            return m;
        } catch (Exception e) {
            return null;
        }
    }

    public void guardar(Context context, String json) {
        prefs(context).edit()
                .putString(KEY_JSON, json)
                .putString(KEY_ROL, rol)
                .apply();
    }

    /** Recupera el ultimo menu conocido, o el de reserva si no hay ninguno. */
    public static MenuConfig cargar(Context context) {
        String json = prefs(context).getString(KEY_JSON, null);
        MenuConfig m = desdeJson(json);
        return m != null ? m : porDefecto();
    }

    /** Dos menus son iguales si tienen los mismos destinos en el mismo orden. */
    public boolean equivaleA(MenuConfig otro) {
        if (otro == null || otro.items.size() != items.size()) {
            return false;
        }
        if (!rol.equals(otro.rol)) {
            return false;
        }
        for (int i = 0; i < items.size(); i++) {
            Item a = items.get(i);
            Item b = otro.items.get(i);
            if (!a.id.equals(b.id) || !a.titulo.equals(b.titulo)) {
                return false;
            }
        }
        return true;
    }

    /**
     * Icono de la barra inferior a partir del nombre que manda el sitio.
     * Cada uno cambia de trazo a relleno al estar activo (res/drawable/nav_*.xml).
     * Se aceptan tambien los nombres en español.
     */
    public static int iconoDe(String nombre) {
        if (nombre == null) {
            return R.drawable.nav_home;
        }
        switch (nombre.trim().toLowerCase(java.util.Locale.ROOT)) {
            case "map": case "mapa":                       return R.drawable.nav_map;
            case "store": case "negocios": case "tienda":   return R.drawable.nav_store;
            case "card": case "membresia": case "tarjeta":  return R.drawable.nav_card;
            case "pets": case "mascotas":                   return R.drawable.nav_pets;
            case "user": case "perfil": case "cuenta":      return R.drawable.nav_user;
            case "plans": case "planes":                    return R.drawable.nav_plans;
            case "qr":                                      return R.drawable.nav_qr;
            case "event": case "eventos": case "calendar":  return R.drawable.nav_event;
            case "forum": case "foro": case "chat":         return R.drawable.nav_forum;
            case "heart": case "favoritos":                 return R.drawable.nav_heart;
            default:                                        return R.drawable.nav_home;
        }
    }

    private static SharedPreferences prefs(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }
}
