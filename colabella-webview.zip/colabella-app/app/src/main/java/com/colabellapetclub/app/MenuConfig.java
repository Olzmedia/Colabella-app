package com.colabellapetclub.app;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * El menu de la barra inferior lo define el sitio segun el usuario que ha entrado
 * (visitante, socio o negocio). La app solo lo pinta.
 *
 * El ultimo menu recibido se guarda para que al abrir sin conexion la barra
 * no aparezca vacia.
 */
public class MenuConfig {

    public static class Item {
        public String id;
        public String titulo;
        public String url;
        public String icono;
        public boolean nativo;
    }

    private static final String PREFS = "colabella_menu";
    private static final String KEY_JSON = "menu_json";
    private static final String KEY_ROL = "rol";

    public String rol = "visitante";
    public final List<Item> items = new ArrayList<>();

    /** Menu de reserva: lo que se muestra antes de que el sitio conteste. */
    public static MenuConfig porDefecto() {
        MenuConfig m = new MenuConfig();
        m.rol = "visitante";
        m.items.add(crear("inicio", "Inicio", WebFragment.START_URL, "home", false));
        m.items.add(crear("planes", "Planes", WebFragment.START_URL + "planes/", "plans", false));
        m.items.add(crear("mapa", "Mapa", WebFragment.START_URL + "mapa/", "map", false));
        m.items.add(crear("negocios", "Negocios", WebFragment.START_URL + "negocios/", "store", false));
        m.items.add(crear("acceso", "Entrar", WebFragment.START_URL + "acceso/", "user", false));
        return m;
    }

    private static Item crear(String id, String titulo, String url, String icono, boolean nativo) {
        Item i = new Item();
        i.id = id;
        i.titulo = titulo;
        i.url = url;
        i.icono = icono;
        i.nativo = nativo;
        return i;
    }

    /**
     * Lee el JSON que publica el sitio. Devuelve null si viene vacio o mal formado,
     * para que la app conserve el menu que ya tenia.
     */
    public static MenuConfig desdeJson(String json) {
        if (json == null || json.trim().isEmpty() || "null".equals(json.trim())) {
            return null;
        }
        try {
            JSONObject raiz = new JSONObject(json);
            JSONArray arr = raiz.optJSONArray("items");
            if (arr == null || arr.length() == 0) {
                return null;
            }
            MenuConfig m = new MenuConfig();
            m.rol = raiz.optString("rol", "visitante");
            // La barra inferior solo se ve bien hasta cinco destinos
            int max = Math.min(arr.length(), 5);
            for (int i = 0; i < max; i++) {
                JSONObject o = arr.getJSONObject(i);
                Item it = new Item();
                it.id = o.optString("id", "item" + i);
                it.titulo = o.optString("titulo", "");
                it.url = o.isNull("url") ? null : o.optString("url", null);
                it.icono = o.optString("icono", "home");
                it.nativo = o.optBoolean("nativo", false);
                if (!it.titulo.isEmpty() && (it.nativo || it.url != null)) {
                    m.items.add(it);
                }
            }
            return m.items.isEmpty() ? null : m;
        } catch (Exception e) {
            return null;
        }
    }

    public void guardar(Context context, String json) {
        prefs(context).edit()
                .putString(KEY_JSON, json)
                .putString(KEY_ROL, rol)
                .apply();
    }

    /** Recupera el ultimo menu conocido, o el de reserva si no hay ninguno. */
    public static MenuConfig cargar(Context context) {
        String json = prefs(context).getString(KEY_JSON, null);
        MenuConfig m = desdeJson(json);
        return m != null ? m : porDefecto();
    }

    /** Dos menus son iguales si tienen los mismos destinos en el mismo orden. */
    public boolean equivaleA(MenuConfig otro) {
        if (otro == null || otro.items.size() != items.size()) {
            return false;
        }
        if (!rol.equals(otro.rol)) {
            return false;
        }
        for (int i = 0; i < items.size(); i++) {
            Item a = items.get(i);
            Item b = otro.items.get(i);
            if (!a.id.equals(b.id) || !a.titulo.equals(b.titulo)) {
                return false;
            }
        }
        return true;
    }

    public static int iconoDe(String nombre) {
        if (nombre == null) {
            return R.drawable.ic_home;
        }
        switch (nombre) {
            case "map":      return R.drawable.ic_map;
            case "store":    return R.drawable.ic_store;
            case "card":     return R.drawable.ic_card;
            case "pets":     return R.drawable.ic_pets;
            case "user":     return R.drawable.ic_user;
            case "plans":    return R.drawable.ic_plans;
            case "qr":       return R.drawable.ic_qr;
            default:         return R.drawable.ic_home;
        }
    }

    private static SharedPreferences prefs(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }
}
