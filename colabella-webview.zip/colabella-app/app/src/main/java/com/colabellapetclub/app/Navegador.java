package com.colabellapetclub.app;

/**
 * Lo que la actividad necesita de la pestaña web (hoy, WebFragment).
 */
public interface Navegador {

    void setMenuListener(WebFragment.MenuListener listener);

    boolean puedeRetroceder();

    void retroceder();

    /** Carga una URL del sitio; lo que no sea del sitio se abre fuera. */
    void cargar(String url);

    /** Vuelta de "Continuar con Google / Apple". */
    void canjearTicket(String ticket);

    /** Vuelve a pedir a la web el menu y las mascotas de la cuenta. */
    void sincronizarAhora();
}
