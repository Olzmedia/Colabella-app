package com.colabellapetclub.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.http.SslError;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.PermissionRequest;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.SslErrorHandler;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.fragment.app.Fragment;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.progressindicator.LinearProgressIndicator;

import org.json.JSONTokener;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Pestana de inicio: el sitio web dentro de la app. */
public class WebFragment extends Fragment implements Navegador {

    public static final String HOST = "colabellapetclub.com";
    public static final String START_URL = "https://" + HOST + "/";

    /**
     * Inicio de sesion con Google o Apple. Google no deja iniciar sesion dentro de
     * un WebView ("Error 403: disallowed_useragent"), asi que estas direcciones se
     * abren en una pestaña de Chrome (Custom Tabs). Al terminar, la web devuelve a
     * la app con colabella://entrar?ticket=... y la app canjea el ticket aqui.
     */
    private static final String RUTA_SOCIAL = "/wp-json/club/v1/social/";
    private static final String CANJEAR_URL = START_URL + "wp-json/club/v1/social/canjear?ticket=";

    private WebView webView;
    private SwipeRefreshLayout swipeRefresh;
    private View offlineView;
    private LinearProgressIndicator progreso;

    /** El sitio publica el menu segun quien haya entrado; la actividad lo escucha. */
    public interface MenuListener {
        void onMenuRecibido(String json);

        /** Las mascotas de la cuenta se acaban de sincronizar con el telefono. */
        default void onMascotasActualizadas() { }
    }

    private MenuListener menuListener;
    private SincronizacionWeb sincronizacion;

    private ValueCallback<Uri[]> filePathCallback;
    private ActivityResultLauncher<Intent> fileChooserLauncher;

    // ---- Camara ----
    /** Donde la app de camara deja la foto antes de entregarla a la web. */
    private Uri fotoCamaraUri;
    /** Selector que espera a que el usuario conceda (o no) el permiso de camara. */
    private WebChromeClient.FileChooserParams paramsPendientes;
    /** Camara en vivo pedida por la pagina mientras se pregunta el permiso. */
    private PermissionRequest permisoWebPendiente;
    private ActivityResultLauncher<String> permisoCamaraSubida;
    private ActivityResultLauncher<String> permisoCamaraWeb;
    private boolean loadError = false;
    /** true desde que se carga la URL de canje del ticket hasta que termina de cargar. */
    private boolean canjeEnCurso = false;
    private String urlPendiente = null;

    // ---- Diagnostico de pantalla en blanco ----
    /**
     * Version minima de Android System WebView (Chromium) con la que el sitio se ve
     * bien. Por debajo se avisa al usuario para que la actualice desde Google Play.
     */
    private static final int WEBVIEW_MINIMA = 100;
    /** Si la pagina principal no termina de cargar en este tiempo, se ofrece reintentar. */
    private static final long LIMITE_CARGA_MS = 30_000;
    /** El aviso de WebView vieja sale una vez por apertura de la app. */
    private static boolean avisoWebViewMostrado = false;
    /** Veces seguidas que se cayo el proceso del WebView; evita recrear en bucle. */
    private static int caidasRender = 0;

    /** Texto que mostrara la pantalla de fallo (por defecto, "Sin conexion"). */
    private int falloTitulo = R.string.offline_title;
    private int falloMensaje = R.string.offline_message;

    private final Handler espera = new Handler(Looper.getMainLooper());
    private final Runnable cargaVencida = () -> {
        if (webView == null || !isAdded() || webView.getProgress() >= 100) {
            return;
        }
        marcarFallo(R.string.fallo_lento_titulo, R.string.fallo_lento_mensaje);
        webView.stopLoading();
        mostrarOffline();
    };

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        fileChooserLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (filePathCallback == null) {
                        return;
                    }
                    Uri[] elegidos = null;
                    if (result.getResultCode() == android.app.Activity.RESULT_OK) {
                        elegidos = leerResultado(result.getData());
                    }
                    filePathCallback.onReceiveValue(elegidos);
                    filePathCallback = null;
                    fotoCamaraUri = null;
                });

        // Permiso pedido al tocar "subir foto": con o sin permiso se abre el
        // selector; sin permiso solo queda la galeria.
        permisoCamaraSubida = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(),
                concedido -> {
                    if (!concedido) {
                        avisoCamaraNegada();
                    }
                    WebChromeClient.FileChooserParams p = paramsPendientes;
                    paramsPendientes = null;
                    abrirSelector(p, concedido);
                });

        // Permiso pedido por la camara en vivo de la pagina (getUserMedia)
        permisoCamaraWeb = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(),
                concedido -> {
                    PermissionRequest r = permisoWebPendiente;
                    permisoWebPendiente = null;
                    if (r == null) {
                        return;
                    }
                    if (concedido) {
                        r.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
                    } else {
                        r.deny();
                        avisoCamaraNegada();
                    }
                });
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_web, container, false);
    }

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        webView = view.findViewById(R.id.webview);
        swipeRefresh = view.findViewById(R.id.swipe_refresh);
        offlineView = view.findViewById(R.id.offline_view);
        progreso = view.findViewById(R.id.progreso);

        // chrome://inspect solo en el APK de prueba, nunca en el de Google Play
        if ((requireContext().getApplicationInfo().flags
                & android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE) != 0) {
            WebView.setWebContentsDebuggingEnabled(true);
        }

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        // El WebView solo necesita la web: sin acceso a archivos locales ni a content://
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        // Reutiliza lo que ya se descargo (imagenes, CSS, JS) segun las cabeceras del servidor
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        // ColabellaApp: la web sabe que esta dentro de la app.
        // ColabellaSocial/1: la web muestra "Continuar con Google / Apple", porque
        // la app sabe abrirlos en una pestaña de Chrome (ver abrirInicioSocial).
        s.setUserAgentString(s.getUserAgentString() + " ColabellaApp/1.0 ColabellaSocial/1");

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        // Puente con la web para traer el menu y las mascotas de la cuenta
        sincronizacion = new SincronizacionWeb(new SincronizacionWeb.Receptor() {
            @Override
            public void onMenu(String json) {
                if (menuListener != null) {
                    menuListener.onMenuRecibido(json);
                }
            }

            @Override
            public void onMascotas(@Nullable List<Pet> mascotas) {
                guardarMascotasDeLaWeb(mascotas);
            }
        });
        webView.addJavascriptInterface(sincronizacion.puente(), SincronizacionWeb.NOMBRE_PUENTE);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest request) {
                // Google y Apple nunca se cargan en el WebView
                if (esInicioSocial(request.getUrl())) {
                    abrirInicioSocial(request.getUrl());
                    return true;
                }
                // Los iframes (pasarelas de pago incrustadas, verificacion 3D Secure del
                // banco...) navegan dentro de la pagina; sacarlos al navegador rompe el pago.
                String esquema = request.getUrl().getScheme();
                if (!request.isForMainFrame()
                        && ("https".equalsIgnoreCase(esquema) || "http".equalsIgnoreCase(esquema))) {
                    return false;
                }
                return manejarUrl(request.getUrl());
            }

            @Override
            @SuppressWarnings("deprecation")
            public boolean shouldOverrideUrlLoading(WebView v, String url) {
                return manejarUrl(Uri.parse(url));
            }

            @Override
            public void onPageStarted(WebView v, String url, android.graphics.Bitmap favicon) {
                mostrarProgreso(5);
                if (!loadError) {
                    // Carga nueva: el proximo fallo vuelve a decir "Sin conexion"
                    falloTitulo = R.string.offline_title;
                    falloMensaje = R.string.offline_message;
                }
                espera.removeCallbacks(cargaVencida);
                espera.postDelayed(cargaVencida, LIMITE_CARGA_MS);
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                espera.removeCallbacks(cargaVencida);
                ocultarProgreso();
                if (canjeEnCurso) {
                    // La sesion recien creada se guarda ya en disco: si la app se
                    // cierra enseguida, al volver a abrirla sigue iniciada.
                    canjeEnCurso = false;
                    CookieManager.getInstance().flush();
                }
                swipeRefresh.setRefreshing(false);
                if (loadError) {
                    mostrarOffline();
                    return;
                }
                caidasRender = 0;
                leerMenuDelSitio();
                if (url != null && esDelSitio(Uri.parse(url)) && sincronizacion != null) {
                    v.evaluateJavascript(sincronizacion.script(), null);
                }
            }

            @Override
            public void onReceivedError(WebView v, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    marcarFallo(R.string.offline_title, R.string.offline_message);
                }
            }

            /**
             * Certificado no valido (fecha del telefono mal puesta, cadena de
             * certificados que ese WebView no reconoce...). Sin esto el WebView
             * cancela en silencio y la pagina se queda EN BLANCO, sin error.
             * Nunca se llama a proceed(): Play rechaza las apps que lo hacen.
             */
            @Override
            public void onReceivedSslError(WebView v, SslErrorHandler handler, SslError error) {
                handler.cancel();
                String fallida = error != null ? error.getUrl() : null;
                if (fallida != null && esDelSitio(Uri.parse(fallida))) {
                    marcarFallo(R.string.fallo_ssl_titulo, R.string.fallo_ssl_mensaje);
                }
            }

            /**
             * El proceso que dibuja la web se cerro (falta de memoria, WebView
             * defectuosa en algunos Xiaomi). Si no se atiende, la app se cierra o
             * se queda en blanco. Se recrea la pantalla; si vuelve a pasar, se avisa.
             */
            @Override
            @RequiresApi(Build.VERSION_CODES.O)
            public boolean onRenderProcessGone(WebView v, RenderProcessGoneDetail detail) {
                espera.removeCallbacks(cargaVencida);
                if (v.getParent() instanceof ViewGroup) {
                    ((ViewGroup) v.getParent()).removeView(v);
                }
                v.destroy();
                if (v == webView) {
                    webView = null;
                }
                if (!isAdded()) {
                    return true;
                }
                caidasRender++;
                if (caidasRender <= 1) {
                    requireActivity().recreate();
                } else {
                    marcarFallo(R.string.fallo_render_titulo, R.string.fallo_render_mensaje);
                    mostrarOffline();
                }
                return true;
            }

            @Override
            @SuppressWarnings("deprecation")
            public void onReceivedError(WebView v, int code, String desc, String failingUrl) {
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
                    marcarFallo(R.string.offline_title, R.string.offline_message);
                }
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView v, int nuevo) {
                if (nuevo >= 100) {
                    ocultarProgreso();
                } else {
                    mostrarProgreso(nuevo);
                }
            }

            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                // Si quedo un selector anterior sin responder, se cierra; si no, el
                // campo de archivo de la web deja de responder.
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = callback;

                boolean quiereFoto = aceptaImagenes(params) && hayCamara();
                if (quiereFoto && !tienePermisoCamara()) {
                    paramsPendientes = params;
                    permisoCamaraSubida.launch(Manifest.permission.CAMERA);
                } else {
                    abrirSelector(params, quiereFoto);
                }
                return true;
            }

            /** Camara en vivo pedida por la pagina: escaner, foto dentro de la web... */
            @Override
            public void onPermissionRequest(PermissionRequest request) {
                if (!isAdded()) {
                    request.deny();
                    return;
                }
                requireActivity().runOnUiThread(() -> {
                    boolean pideCamara = false;
                    for (String r : request.getResources()) {
                        if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)) {
                            pideCamara = true;
                        }
                    }
                    // Solo nuestro sitio puede usar la camara, nunca un iframe de terceros
                    if (!pideCamara || !esDelSitio(request.getOrigin())) {
                        request.deny();
                        return;
                    }
                    if (tienePermisoCamara()) {
                        request.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
                    } else {
                        if (permisoWebPendiente != null) {
                            permisoWebPendiente.deny();
                        }
                        permisoWebPendiente = request;
                        permisoCamaraWeb.launch(Manifest.permission.CAMERA);
                    }
                });
            }

            @Override
            public void onPermissionRequestCanceled(PermissionRequest request) {
                if (permisoWebPendiente == request) {
                    permisoWebPendiente = null;
                }
            }
        });

        webView.setDownloadListener((url, userAgent, disposition, mime, size) -> {
            try {
                DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url));
                req.setMimeType(mime);
                req.addRequestHeader("User-Agent", userAgent);
                req.addRequestHeader("Cookie", CookieManager.getInstance().getCookie(url));
                req.setNotificationVisibility(
                        DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                req.setDestinationInExternalPublicDir(
                        android.os.Environment.DIRECTORY_DOWNLOADS,
                        URLUtil.guessFileName(url, disposition, mime));
                DownloadManager dm = (DownloadManager)
                        requireContext().getSystemService(Context.DOWNLOAD_SERVICE);
                if (dm != null) {
                    dm.enqueue(req);
                    aviso(getString(R.string.downloading));
                }
            } catch (Exception e) {
                abrirFuera(Uri.parse(url));
            }
        });

        swipeRefresh.setColorSchemeResources(R.color.brand_accent, R.color.brand_primary);
        swipeRefresh.setOnRefreshListener(() -> {
            if (webView == null) {
                swipeRefresh.setRefreshing(false);
                return;
            }
            loadError = false;
            webView.reload();
        });

        view.findViewById(R.id.btn_retry).setOnClickListener(v -> {
            if (!hayRed()) {
                aviso(getString(R.string.offline_title));
                return;
            }
            if (webView == null) {
                // El WebView se destruyo (proceso caido): se rehace la pantalla entera
                caidasRender = 0;
                requireActivity().recreate();
                return;
            }
            offlineView.setVisibility(View.GONE);
            swipeRefresh.setVisibility(View.VISIBLE);
            loadError = false;
            webView.loadUrl(START_URL);
        });

        String inicial = urlPendiente != null ? urlPendiente : START_URL;
        urlPendiente = null;
        webView.loadUrl(inicial);
        avisarSiWebViewVieja();
    }

    // =====================================================================
    // Subida de fotos: menu "Tomar foto / Galeria", igual que en el navegador
    // =====================================================================

    private void abrirSelector(@Nullable WebChromeClient.FileChooserParams params, boolean conCamara) {
        if (!isAdded() || filePathCallback == null) {
            return;
        }
        Intent galeria = params != null ? params.createIntent()
                : new Intent(Intent.ACTION_GET_CONTENT).setType("*/*");
        galeria.addCategory(Intent.CATEGORY_OPENABLE);
        if (params != null && params.getMode() == WebChromeClient.FileChooserParams.MODE_OPEN_MULTIPLE) {
            galeria.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        }

        Intent camara = conCamara ? crearIntentCamara() : null;

        if (camara == null) {
            lanzar(galeria);
            return;
        }
        // <input capture>: la web quiere la camara directamente
        if (params != null && params.isCaptureEnabled()) {
            lanzar(camara);
            return;
        }

        // Menu propio: el selector del sistema esconde la camara en muchos
        // telefonos (Xiaomi, Samsung con Android 13+).
        final boolean[] elegido = {false};
        new MaterialAlertDialogBuilder(requireContext())
                .setTitle(R.string.subir_titulo)
                .setItems(new CharSequence[]{
                        getString(R.string.subir_camara),
                        getString(R.string.subir_galeria)
                }, (d, cual) -> {
                    elegido[0] = true;
                    if (cual == 0) {
                        lanzar(camara);
                    } else {
                        fotoCamaraUri = null;
                        lanzar(galeria);
                    }
                })
                .setOnDismissListener(d -> {
                    if (!elegido[0]) {
                        cancelarSubida();
                    }
                })
                .show();
    }

    private void lanzar(Intent intent) {
        try {
            fileChooserLauncher.launch(intent);
        } catch (ActivityNotFoundException e) {
            aviso(getString(R.string.no_file_app));
            cancelarSubida();
        }
    }

    private void cancelarSubida() {
        if (filePathCallback != null) {
            filePathCallback.onReceiveValue(null);
            filePathCallback = null;
        }
        fotoCamaraUri = null;
    }

    @Nullable
    private Intent crearIntentCamara() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (intent.resolveActivity(requireContext().getPackageManager()) == null) {
            return null;
        }
        try {
            File carpeta = new File(requireContext().getCacheDir(), "camara");
            if (!carpeta.exists() && !carpeta.mkdirs()) {
                return null;
            }
            String nombre = "IMG_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US)
                    .format(new Date()) + ".jpg";
            fotoCamaraUri = FileProvider.getUriForFile(requireContext(),
                    requireContext().getPackageName() + ".fotos", new File(carpeta, nombre));
            intent.putExtra(MediaStore.EXTRA_OUTPUT, fotoCamaraUri);
            intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            return intent;
        } catch (Exception e) {
            fotoCamaraUri = null;
            return null;
        }
    }

    /** Lo que devolvio la galeria (uno o varios archivos) o la foto de la camara. */
    @Nullable
    private Uri[] leerResultado(@Nullable Intent data) {
        if (data != null && data.getClipData() != null && data.getClipData().getItemCount() > 0) {
            List<Uri> lista = new ArrayList<>();
            for (int i = 0; i < data.getClipData().getItemCount(); i++) {
                Uri u = data.getClipData().getItemAt(i).getUri();
                if (u != null) {
                    lista.add(u);
                }
            }
            if (!lista.isEmpty()) {
                return lista.toArray(new Uri[0]);
            }
        }
        if (data != null && data.getData() != null) {
            return new Uri[]{data.getData()};
        }
        // La camara escribe en fotoCamaraUri y devuelve data vacio
        if (fotoCamaraUri != null) {
            return new Uri[]{fotoCamaraUri};
        }
        return null;
    }

    /** true si el campo de la web acepta imagenes, o no limita el tipo. */
    private boolean aceptaImagenes(@Nullable WebChromeClient.FileChooserParams params) {
        if (params == null || params.getAcceptTypes() == null) {
            return true;
        }
        boolean algunTipo = false;
        for (String grupo : params.getAcceptTypes()) {
            if (grupo == null) {
                continue;
            }
            for (String t : grupo.split(",")) {
                String tipo = t.trim().toLowerCase(Locale.ROOT);
                if (tipo.isEmpty()) {
                    continue;
                }
                algunTipo = true;
                if (tipo.startsWith("image") || tipo.equals("*/*")
                        || tipo.equals(".jpg") || tipo.equals(".jpeg") || tipo.equals(".png")
                        || tipo.equals(".webp") || tipo.equals(".heic")) {
                    return true;
                }
            }
        }
        return !algunTipo;
    }

    private boolean hayCamara() {
        return requireContext().getPackageManager()
                .hasSystemFeature(PackageManager.FEATURE_CAMERA_ANY);
    }

    private boolean tienePermisoCamara() {
        return ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED;
    }

    /** Si el permiso quedo bloqueado ("no volver a preguntar"), se abre Ajustes. */
    private void avisoCamaraNegada() {
        if (!isAdded()) {
            return;
        }
        if (shouldShowRequestPermissionRationale(Manifest.permission.CAMERA)) {
            aviso(getString(R.string.camara_sin_permiso));
            return;
        }
        Toast.makeText(requireContext(), R.string.camara_bloqueada, Toast.LENGTH_LONG).show();
        try {
            Intent ajustes = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.fromParts("package", requireContext().getPackageName(), null));
            startActivity(ajustes);
        } catch (Exception ignorado) {
            // Sin pantalla de ajustes: el aviso ya basta
        }
    }

    /**
     * Guarda en el telefono las mascotas de la cuenta y ajusta sus recordatorios.
     * null = no hay sesion: se quitan del telefono las fichas que venian de la web.
     */
    private void guardarMascotasDeLaWeb(@Nullable List<Pet> mascotas) {
        if (!isAdded()) {
            return;
        }
        Context ctx = requireContext().getApplicationContext();
        List<Pet> nuevas = mascotas != null ? mascotas : new ArrayList<>();
        List<Pet> quitadas = new PetStore(ctx).sincronizarWeb(nuevas);
        for (Pet p : quitadas) {
            p.proximaVacuna = 0; // cancela su recordatorio
            ReminderReceiver.programar(ctx, p);
        }
        for (Pet p : nuevas) {
            ReminderReceiver.programar(ctx, p);
        }
        if (menuListener != null) {
            menuListener.onMascotasActualizadas();
        }
    }

    /** true si la URL es https y pertenece a colabellapetclub.com o a un subdominio. */
    public static boolean esDelSitio(@Nullable Uri uri) {
        if (uri == null || !"https".equalsIgnoreCase(uri.getScheme())) {
            return false;
        }
        String host = uri.getHost();
        return host != null && (host.equalsIgnoreCase(HOST) || host.toLowerCase(java.util.Locale.ROOT).endsWith("." + HOST));
    }

    /**
     * Carga una URL concreta, por ejemplo la que llega en una notificacion push o
     * en el menu del sitio. Lo que no sea del sitio se abre fuera de la app.
     */
    @Override
    public void cargar(String url) {
        if (url == null) {
            return;
        }
        Uri uri = Uri.parse(url);
        if (esInicioSocial(uri)) {
            if (isAdded()) {
                abrirInicioSocial(uri);
            }
            return;
        }
        if (!esDelSitio(uri)) {
            if (isAdded()) {
                abrirFuera(uri);
            }
            return;
        }
        if (webView == null) {
            urlPendiente = url;
        } else {
            loadError = false;
            offlineView.setVisibility(View.GONE);
            swipeRefresh.setVisibility(View.VISIBLE);
            webView.loadUrl(url);
        }
    }

    /**
     * Vuelve a preguntar a la web por las mascotas y el menu, por ejemplo al
     * abrir la pestaña Mascotas. Usa la pagina que ya esta cargada.
     */
    @Override
    public void sincronizarAhora() {
        if (webView == null || sincronizacion == null) {
            return;
        }
        String actual = webView.getUrl();
        if (actual != null && esDelSitio(Uri.parse(actual))) {
            webView.evaluateJavascript("window.__cbSync=0;" + sincronizacion.script(), null);
        }
    }

    @Override
    public boolean puedeRetroceder() {
        return webView != null && webView.canGoBack();
    }

    @Override
    public void retroceder() {
        if (webView != null) {
            webView.goBack();
        }
    }

    @Override
    public void setMenuListener(MenuListener listener) {
        this.menuListener = listener;
    }

    /**
     * WordPress imprime window.COLABELLA_APP_MENU con el menu que corresponde
     * al usuario de la sesion. Se lee tras cada carga, asi que al iniciar o
     * cerrar sesion la barra se actualiza sola.
     */
    private void leerMenuDelSitio() {
        if (webView == null || menuListener == null) {
            return;
        }
        webView.evaluateJavascript(
                "(function(){try{return JSON.stringify(window.COLABELLA_APP_MENU||null);}"
                        + "catch(e){return null;}})()",
                valor -> {
                    String json = desenvolver(valor);
                    if (json != null && menuListener != null) {
                        menuListener.onMenuRecibido(json);
                    }
                });
    }

    /** evaluateJavascript devuelve el texto ya escapado como literal JSON. */
    @Nullable
    private String desenvolver(String valor) {
        if (valor == null || "null".equals(valor)) {
            return null;
        }
        try {
            Object o = new JSONTokener(valor).nextValue();
            return o instanceof String ? (String) o : null;
        } catch (Exception e) {
            return null;
        }
    }

    // =====================================================================
    // Continuar con Google / Apple
    // =====================================================================

    /** true para https://colabellapetclub.com/wp-json/club/v1/social/google|apple/inicio */
    static boolean esInicioSocial(@Nullable Uri uri) {
        if (uri == null || !"https".equalsIgnoreCase(uri.getScheme())
                || uri.getHost() == null || !HOST.equalsIgnoreCase(uri.getHost())) {
            return false;
        }
        String ruta = uri.getPath();
        if (ruta == null) {
            return false;
        }
        if (ruta.endsWith("/")) {
            ruta = ruta.substring(0, ruta.length() - 1);
        }
        return ruta.equals(RUTA_SOCIAL + "google/inicio") || ruta.equals(RUTA_SOCIAL + "apple/inicio");
    }

    /**
     * Abre el inicio de sesion en una pestaña de Chrome (o del navegador que
     * admita pestañas personalizadas). Si no hay ninguno, en el navegador normal.
     */
    private void abrirInicioSocial(Uri uri) {
        Context ctx = getContext();
        if (ctx != null) {
            Enlaces.abrirInicioSocial(ctx, uri);
        }
    }

    /**
     * Canjea el ticket que devuelve la web tras iniciar sesion con Google o Apple:
     * la web crea la sesion y redirige a /mi-membresia/, /panel-negocio/ o a
     * /registro/?completar=1. El ticket ya viene validado (solo letras y numeros).
     */
    @Override
    public void canjearTicket(String ticket) {
        canjeEnCurso = true;
        cargar(CANJEAR_URL + ticket);
    }

    private boolean manejarUrl(Uri uri) {
        if (esInicioSocial(uri)) {
            abrirInicioSocial(uri);
            return true;
        }
        if (uri.getScheme() == null || esDelSitio(uri)) {
            return false;
        }
        abrirFuera(uri);
        return true;
    }

    private void abrirFuera(Uri uri) {
        Context ctx = getContext();
        if (ctx != null) {
            Enlaces.abrirFuera(ctx, uri);
        }
    }

    private void mostrarProgreso(int valor) {
        if (progreso == null) {
            return;
        }
        if (progreso.getVisibility() != View.VISIBLE) {
            progreso.setProgressCompat(0, false);
            progreso.setVisibility(View.VISIBLE);
        }
        progreso.setProgressCompat(Math.max(valor, 5), true);
    }

    private void ocultarProgreso() {
        if (progreso != null) {
            progreso.setVisibility(View.GONE);
        }
    }

    private void marcarFallo(int titulo, int mensaje) {
        falloTitulo = titulo;
        falloMensaje = mensaje;
        loadError = true;
    }

    private void mostrarOffline() {
        if (swipeRefresh == null || offlineView == null || !isAdded()) {
            return;
        }
        espera.removeCallbacks(cargaVencida);
        ocultarProgreso();
        swipeRefresh.setRefreshing(false);
        swipeRefresh.setVisibility(View.GONE);
        TextView titulo = offlineView.findViewById(R.id.offline_titulo);
        TextView mensaje = offlineView.findViewById(R.id.offline_mensaje);
        if (titulo != null) {
            titulo.setText(falloTitulo);
        }
        if (mensaje != null) {
            // La version del WebView al pie: con una captura de pantalla ya se sabe
            // si el telefono tiene el navegador interno desactualizado.
            String texto = getString(falloMensaje);
            PackageInfo wv = paqueteWebView(requireContext());
            if (wv != null && wv.versionName != null) {
                texto += "\n\n" + getString(R.string.webview_version, wv.versionName);
            }
            mensaje.setText(texto);
        }
        offlineView.setVisibility(View.VISIBLE);
    }

    // =====================================================================
    // Android System WebView desactualizada (causa tipica de pantalla en blanco)
    // =====================================================================

    /** El paquete de WebView que usa el telefono, o null si no se puede saber. */
    @Nullable
    private static PackageInfo paqueteWebView(Context ctx) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                return WebView.getCurrentWebViewPackage();
            } catch (Exception ignorado) {
                return null;
            }
        }
        // Android 7: la WebView suele ser la de Google o la de Chrome
        for (String paquete : new String[]{"com.google.android.webview", "com.android.chrome"}) {
            try {
                return ctx.getPackageManager().getPackageInfo(paquete, 0);
            } catch (Exception ignorado) {
                // prueba el siguiente
            }
        }
        return null;
    }

    /** "120.0.6099.230" -> 120. -1 si no se puede leer. */
    private static int versionMayor(@Nullable PackageInfo p) {
        if (p == null || p.versionName == null) {
            return -1;
        }
        try {
            return Integer.parseInt(p.versionName.split("\\.")[0].trim());
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    private void avisarSiWebViewVieja() {
        if (avisoWebViewMostrado || !isAdded()) {
            return;
        }
        PackageInfo wv = paqueteWebView(requireContext());
        int mayor = versionMayor(wv);
        if (mayor < 0 || mayor >= WEBVIEW_MINIMA) {
            return;
        }
        avisoWebViewMostrado = true;
        final String paquete = wv.packageName;
        new MaterialAlertDialogBuilder(requireContext())
                .setTitle(R.string.webview_vieja_titulo)
                .setMessage(getString(R.string.webview_vieja_mensaje, wv.versionName))
                .setPositiveButton(R.string.actualizar, (d, w) -> abrirEnPlay(paquete))
                .setNegativeButton(R.string.ahora_no, null)
                .show();
    }

    private void abrirEnPlay(String paquete) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + paquete));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (ActivityNotFoundException e) {
            abrirFuera(Uri.parse("https://play.google.com/store/apps/details?id=" + paquete));
        }
    }

    private boolean hayRed() {
        ConnectivityManager cm = (ConnectivityManager)
                requireContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) {
            return false;
        }
        NetworkInfo info = cm.getActiveNetworkInfo();
        return info != null && info.isConnected();
    }

    private void aviso(String msg) {
        if (isAdded()) {
            Toast.makeText(requireContext(), msg, Toast.LENGTH_SHORT).show();
        }
    }

    /** Al destruirse la vista se libera el WebView y se olvida la referencia. */
    @Override
    public void onDestroyView() {
        espera.removeCallbacks(cargaVencida);
        if (webView != null) {
            webView.stopLoading();
            webView.removeJavascriptInterface(SincronizacionWeb.NOMBRE_PUENTE);
            webView.setWebChromeClient(null);
            webView.destroy();
            webView = null;
        }
        progreso = null;
        super.onDestroyView();
    }

    @Override
    public void onPause() {
        if (webView != null) {
            webView.onPause();
        }
        // Guarda la sesion en disco al salir de la app (por ejemplo, al abrir Google)
        CookieManager.getInstance().flush();
        super.onPause();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (webView != null) {
            webView.onResume();
        }
    }
}
