package com.colabellapetclub.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.PermissionRequest;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.fragment.app.Fragment;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.progressindicator.LinearProgressIndicator;

import org.json.JSONTokener;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Pestana de inicio: el sitio web dentro de la app. */
public class WebFragment extends Fragment {

    public static final String HOST = "colabellapetclub.com";
    public static final String START_URL = "https://" + HOST + "/";

    private WebView webView;
    private SwipeRefreshLayout swipeRefresh;
    private View offlineView;
    private LinearProgressIndicator progreso;

    /** El sitio publica el menu segun quien haya entrado; la actividad lo escucha. */
    public interface MenuListener {
        void onMenuRecibido(String json);
    }

    private MenuListener menuListener;

    private ValueCallback<Uri[]> filePathCallback;
    private ActivityResultLauncher<Intent> fileChooserLauncher;

    // ---- Camara ----
    /** Donde la app de camara deja la foto antes de entregarla a la web. */
    private Uri fotoCamaraUri;
    /** Selector que espera a que el usuario conceda (o no) el permiso de camara. */
    private WebChromeClient.FileChooserParams paramsPendientes;
    /** Camara en vivo pedida por la pagina mientras se pregunta el permiso. */
    private PermissionRequest permisoWebPendiente;
    private ActivityResultLauncher<String> permisoCamaraSubida;
    private ActivityResultLauncher<String> permisoCamaraWeb;
    private boolean loadError = false;
    private String urlPendiente = null;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        fileChooserLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (filePathCallback == null) {
                        return;
                    }
                    Uri[] elegidos = null;
                    if (result.getResultCode() == android.app.Activity.RESULT_OK) {
                        elegidos = leerResultado(result.getData());
                    }
                    filePathCallback.onReceiveValue(elegidos);
                    filePathCallback = null;
                    fotoCamaraUri = null;
                });

        // Permiso pedido al tocar "subir foto": con o sin permiso se abre el
        // selector; sin permiso solo queda la galeria.
        permisoCamaraSubida = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(),
                concedido -> {
                    if (!concedido) {
                        avisoCamaraNegada();
                    }
                    WebChromeClient.FileChooserParams p = paramsPendientes;
                    paramsPendientes = null;
                    abrirSelector(p, concedido);
                });

        // Permiso pedido por la camara en vivo de la pagina (getUserMedia)
        permisoCamaraWeb = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(),
                concedido -> {
                    PermissionRequest r = permisoWebPendiente;
                    permisoWebPendiente = null;
                    if (r == null) {
                        return;
                    }
                    if (concedido) {
                        r.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
                    } else {
                        r.deny();
                        avisoCamaraNegada();
                    }
                });
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_web, container, false);
    }

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        webView = view.findViewById(R.id.webview);
        swipeRefresh = view.findViewById(R.id.swipe_refresh);
        offlineView = view.findViewById(R.id.offline_view);
        progreso = view.findViewById(R.id.progreso);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        // El WebView solo necesita la web: sin acceso a archivos locales ni a content://
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        // Reutiliza lo que ya se descargo (imagenes, CSS, JS) segun las cabeceras del servidor
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setUserAgentString(s.getUserAgentString() + " ColabellaApp/1.0");

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest request) {
                // Los iframes (pasarelas de pago incrustadas, verificacion 3D Secure del
                // banco...) navegan dentro de la pagina; sacarlos al navegador rompe el pago.
                String esquema = request.getUrl().getScheme();
                if (!request.isForMainFrame()
                        && ("https".equalsIgnoreCase(esquema) || "http".equalsIgnoreCase(esquema))) {
                    return false;
                }
                return manejarUrl(request.getUrl());
            }

            @Override
            @SuppressWarnings("deprecation")
            public boolean shouldOverrideUrlLoading(WebView v, String url) {
                return manejarUrl(Uri.parse(url));
            }

            @Override
            public void onPageStarted(WebView v, String url, android.graphics.Bitmap favicon) {
                mostrarProgreso(5);
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                ocultarProgreso();
                swipeRefresh.setRefreshing(false);
                if (loadError) {
                    mostrarOffline();
                    return;
                }
                leerMenuDelSitio();
            }

            @Override
            public void onReceivedError(WebView v, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    loadError = true;
                }
            }

            @Override
            @SuppressWarnings("deprecation")
            public void onReceivedError(WebView v, int code, String desc, String failingUrl) {
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
                    loadError = true;
                }
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView v, int nuevo) {
                if (nuevo >= 100) {
                    ocultarProgreso();
                } else {
                    mostrarProgreso(nuevo);
                }
            }

            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                // Si quedo un selector anterior sin responder, se cierra; si no, el
                // campo de archivo de la web deja de responder.
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = callback;

                boolean quiereFoto = aceptaImagenes(params) && hayCamara();
                if (quiereFoto && !tienePermisoCamara()) {
                    paramsPendientes = params;
                    permisoCamaraSubida.launch(Manifest.permission.CAMERA);
                } else {
                    abrirSelector(params, quiereFoto);
                }
                return true;
            }

            /** Camara en vivo pedida por la pagina: escaner, foto dentro de la web... */
            @Override
            public void onPermissionRequest(PermissionRequest request) {
                if (!isAdded()) {
                    request.deny();
                    return;
                }
                requireActivity().runOnUiThread(() -> {
                    boolean pideCamara = false;
                    for (String r : request.getResources()) {
                        if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)) {
                            pideCamara = true;
                        }
                    }
                    // Solo nuestro sitio puede usar la camara, nunca un iframe de terceros
                    if (!pideCamara || !esDelSitio(request.getOrigin())) {
                        request.deny();
                        return;
                    }
                    if (tienePermisoCamara()) {
                        request.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
                    } else {
                        if (permisoWebPendiente != null) {
                            permisoWebPendiente.deny();
                        }
                        permisoWebPendiente = request;
                        permisoCamaraWeb.launch(Manifest.permission.CAMERA);
                    }
                });
            }

            @Override
            public void onPermissionRequestCanceled(PermissionRequest request) {
                if (permisoWebPendiente == request) {
                    permisoWebPendiente = null;
                }
            }
        });

        webView.setDownloadListener((url, userAgent, disposition, mime, size) -> {
            try {
                DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url));
                req.setMimeType(mime);
                req.addRequestHeader("User-Agent", userAgent);
                req.addRequestHeader("Cookie", CookieManager.getInstance().getCookie(url));
                req.setNotificationVisibility(
                        DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                req.setDestinationInExternalPublicDir(
                        android.os.Environment.DIRECTORY_DOWNLOADS,
                        URLUtil.guessFileName(url, disposition, mime));
                DownloadManager dm = (DownloadManager)
                        requireContext().getSystemService(Context.DOWNLOAD_SERVICE);
                if (dm != null) {
                    dm.enqueue(req);
                    aviso(getString(R.string.downloading));
                }
            } catch (Exception e) {
                abrirFuera(Uri.parse(url));
            }
        });

        swipeRefresh.setColorSchemeResources(R.color.brand_accent, R.color.brand_primary);
        swipeRefresh.setOnRefreshListener(() -> {
            loadError = false;
            webView.reload();
        });

        view.findViewById(R.id.btn_retry).setOnClickListener(v -> {
            if (!hayRed()) {
                aviso(getString(R.string.offline_title));
                return;
            }
            offlineView.setVisibility(View.GONE);
            swipeRefresh.setVisibility(View.VISIBLE);
            loadError = false;
            webView.loadUrl(START_URL);
        });

        String inicial = urlPendiente != null ? urlPendiente : START_URL;
        urlPendiente = null;
        webView.loadUrl(inicial);
    }

    // =====================================================================
    // Subida de fotos: menu "Tomar foto / Galeria", igual que en el navegador
    // =====================================================================

    private void abrirSelector(@Nullable WebChromeClient.FileChooserParams params, boolean conCamara) {
        if (!isAdded() || filePathCallback == null) {
            return;
        }
        Intent galeria = params != null ? params.createIntent()
                : new Intent(Intent.ACTION_GET_CONTENT).setType("*/*");
        galeria.addCategory(Intent.CATEGORY_OPENABLE);
        if (params != null && params.getMode() == WebChromeClient.FileChooserParams.MODE_OPEN_MULTIPLE) {
            galeria.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        }

        Intent camara = conCamara ? crearIntentCamara() : null;

        if (camara == null) {
            lanzar(galeria);
            return;
        }
        // <input capture>: la web quiere la camara directamente
        if (params != null && params.isCaptureEnabled()) {
            lanzar(camara);
            return;
        }

        // Menu propio: el selector del sistema esconde la camara en muchos
        // telefonos (Xiaomi, Samsung con Android 13+).
        final boolean[] elegido = {false};
        new MaterialAlertDialogBuilder(requireContext())
                .setTitle(R.string.subir_titulo)
                .setItems(new CharSequence[]{
                        getString(R.string.subir_camara),
                        getString(R.string.subir_galeria)
                }, (d, cual) -> {
                    elegido[0] = true;
                    if (cual == 0) {
                        lanzar(camara);
                    } else {
                        fotoCamaraUri = null;
                        lanzar(galeria);
                    }
                })
                .setOnDismissListener(d -> {
                    if (!elegido[0]) {
                        cancelarSubida();
                    }
                })
                .show();
    }

    private void lanzar(Intent intent) {
        try {
            fileChooserLauncher.launch(intent);
        } catch (ActivityNotFoundException e) {
            aviso(getString(R.string.no_file_app));
            cancelarSubida();
        }
    }

    private void cancelarSubida() {
        if (filePathCallback != null) {
            filePathCallback.onReceiveValue(null);
            filePathCallback = null;
        }
        fotoCamaraUri = null;
    }

    @Nullable
    private Intent crearIntentCamara() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (intent.resolveActivity(requireContext().getPackageManager()) == null) {
            return null;
        }
        try {
            File carpeta = new File(requireContext().getCacheDir(), "camara");
            if (!carpeta.exists() && !carpeta.mkdirs()) {
                return null;
            }
            String nombre = "IMG_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US)
                    .format(new Date()) + ".jpg";
            fotoCamaraUri = FileProvider.getUriForFile(requireContext(),
                    requireContext().getPackageName() + ".fotos", new File(carpeta, nombre));
            intent.putExtra(MediaStore.EXTRA_OUTPUT, fotoCamaraUri);
            intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            return intent;
        } catch (Exception e) {
            fotoCamaraUri = null;
            return null;
        }
    }

    /** Lo que devolvio la galeria (uno o varios archivos) o la foto de la camara. */
    @Nullable
    private Uri[] leerResultado(@Nullable Intent data) {
        if (data != null && data.getClipData() != null && data.getClipData().getItemCount() > 0) {
            List<Uri> lista = new ArrayList<>();
            for (int i = 0; i < data.getClipData().getItemCount(); i++) {
                Uri u = data.getClipData().getItemAt(i).getUri();
                if (u != null) {
                    lista.add(u);
                }
            }
            if (!lista.isEmpty()) {
                return lista.toArray(new Uri[0]);
            }
        }
        if (data != null && data.getData() != null) {
            return new Uri[]{data.getData()};
        }
        // La camara escribe en fotoCamaraUri y devuelve data vacio
        if (fotoCamaraUri != null) {
            return new Uri[]{fotoCamaraUri};
        }
        return null;
    }

    /** true si el campo de la web acepta imagenes, o no limita el tipo. */
    private boolean aceptaImagenes(@Nullable WebChromeClient.FileChooserParams params) {
        if (params == null || params.getAcceptTypes() == null) {
            return true;
        }
        boolean algunTipo = false;
        for (String grupo : params.getAcceptTypes()) {
            if (grupo == null) {
                continue;
            }
            for (String t : grupo.split(",")) {
                String tipo = t.trim().toLowerCase(Locale.ROOT);
                if (tipo.isEmpty()) {
                    continue;
                }
                algunTipo = true;
                if (tipo.startsWith("image") || tipo.equals("*/*")
                        || tipo.equals(".jpg") || tipo.equals(".jpeg") || tipo.equals(".png")
                        || tipo.equals(".webp") || tipo.equals(".heic")) {
                    return true;
                }
            }
        }
        return !algunTipo;
    }

    private boolean hayCamara() {
        return requireContext().getPackageManager()
                .hasSystemFeature(PackageManager.FEATURE_CAMERA_ANY);
    }

    private boolean tienePermisoCamara() {
        return ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED;
    }

    /** Si el permiso quedo bloqueado ("no volver a preguntar"), se abre Ajustes. */
    private void avisoCamaraNegada() {
        if (!isAdded()) {
            return;
        }
        if (shouldShowRequestPermissionRationale(Manifest.permission.CAMERA)) {
            aviso(getString(R.string.camara_sin_permiso));
            return;
        }
        Toast.makeText(requireContext(), R.string.camara_bloqueada, Toast.LENGTH_LONG).show();
        try {
            Intent ajustes = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.fromParts("package", requireContext().getPackageName(), null));
            startActivity(ajustes);
        } catch (Exception ignorado) {
            // Sin pantalla de ajustes: el aviso ya basta
        }
    }

    /** true si la URL es https y pertenece a colabellapetclub.com o a un subdominio. */
    public static boolean esDelSitio(@Nullable Uri uri) {
        if (uri == null || !"https".equalsIgnoreCase(uri.getScheme())) {
            return false;
        }
        String host = uri.getHost();
        return host != null && (host.equalsIgnoreCase(HOST) || host.toLowerCase(java.util.Locale.ROOT).endsWith("." + HOST));
    }

    /**
     * Carga una URL concreta, por ejemplo la que llega en una notificacion push o
     * en el menu del sitio. Lo que no sea del sitio se abre fuera de la app.
     */
    public void cargar(String url) {
        if (url == null) {
            return;
        }
        Uri uri = Uri.parse(url);
        if (!esDelSitio(uri)) {
            if (isAdded()) {
                abrirFuera(uri);
            }
            return;
        }
        if (webView == null) {
            urlPendiente = url;
        } else {
            loadError = false;
            offlineView.setVisibility(View.GONE);
            swipeRefresh.setVisibility(View.VISIBLE);
            webView.loadUrl(url);
        }
    }

    public boolean puedeRetroceder() {
        return webView != null && webView.canGoBack();
    }

    public void retroceder() {
        webView.goBack();
    }

    public void setMenuListener(MenuListener listener) {
        this.menuListener = listener;
    }

    /**
     * WordPress imprime window.COLABELLA_APP_MENU con el menu que corresponde
     * al usuario de la sesion. Se lee tras cada carga, asi que al iniciar o
     * cerrar sesion la barra se actualiza sola.
     */
    private void leerMenuDelSitio() {
        if (webView == null || menuListener == null) {
            return;
        }
        webView.evaluateJavascript(
                "(function(){try{return JSON.stringify(window.COLABELLA_APP_MENU||null);}"
                        + "catch(e){return null;}})()",
                valor -> {
                    String json = desenvolver(valor);
                    if (json != null && menuListener != null) {
                        menuListener.onMenuRecibido(json);
                    }
                });
    }

    /** evaluateJavascript devuelve el texto ya escapado como literal JSON. */
    @Nullable
    private String desenvolver(String valor) {
        if (valor == null || "null".equals(valor)) {
            return null;
        }
        try {
            Object o = new JSONTokener(valor).nextValue();
            return o instanceof String ? (String) o : null;
        } catch (Exception e) {
            return null;
        }
    }

    private boolean manejarUrl(Uri uri) {
        if (uri.getScheme() == null || esDelSitio(uri)) {
            return false;
        }
        abrirFuera(uri);
        return true;
    }

    private void abrirFuera(Uri uri) {
        if ("intent".equalsIgnoreCase(uri.getScheme())) {
            abrirIntent(uri.toString());
            return;
        }
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, uri);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (ActivityNotFoundException e) {
            aviso(getString(R.string.cannot_open_link));
        }
    }

    /**
     * Enlaces intent:// (WhatsApp, apps de pago...). Se limpian para que una pagina
     * no pueda lanzar componentes internos de la app ni de otras apps.
     */
    private void abrirIntent(String url) {
        Intent intent;
        try {
            intent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME);
        } catch (Exception e) {
            aviso(getString(R.string.cannot_open_link));
            return;
        }
        intent.addCategory(Intent.CATEGORY_BROWSABLE);
        intent.setComponent(null);
        intent.setSelector(null);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            startActivity(intent);
        } catch (ActivityNotFoundException e) {
            String alternativa = intent.getStringExtra("browser_fallback_url");
            if (alternativa != null && alternativa.startsWith("https://")) {
                abrirFuera(Uri.parse(alternativa));
            } else {
                aviso(getString(R.string.cannot_open_link));
            }
        }
    }

    private void mostrarProgreso(int valor) {
        if (progreso == null) {
            return;
        }
        if (progreso.getVisibility() != View.VISIBLE) {
            progreso.setProgressCompat(0, false);
            progreso.setVisibility(View.VISIBLE);
        }
        progreso.setProgressCompat(Math.max(valor, 5), true);
    }

    private void ocultarProgreso() {
        if (progreso != null) {
            progreso.setVisibility(View.GONE);
        }
    }

    private void mostrarOffline() {
        swipeRefresh.setRefreshing(false);
        swipeRefresh.setVisibility(View.GONE);
        offlineView.setVisibility(View.VISIBLE);
    }

    private boolean hayRed() {
        ConnectivityManager cm = (ConnectivityManager)
                requireContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) {
            return false;
        }
        NetworkInfo info = cm.getActiveNetworkInfo();
        return info != null && info.isConnected();
    }

    private void aviso(String msg) {
        if (isAdded()) {
            Toast.makeText(requireContext(), msg, Toast.LENGTH_SHORT).show();
        }
    }

    /** Al destruirse la vista se libera el WebView y se olvida la referencia. */
    @Override
    public void onDestroyView() {
        if (webView != null) {
            webView.stopLoading();
            webView.setWebChromeClient(null);
            webView.destroy();
            webView = null;
        }
        progreso = null;
        super.onDestroyView();
    }

    @Override
    public void onPause() {
        if (webView != null) {
            webView.onPause();
        }
        super.onPause();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (webView != null) {
            webView.onResume();
        }
    }
}
