package com.colabellapetclub.app;

import android.annotation.SuppressLint;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import org.json.JSONTokener;

/** Pestana de inicio: el sitio web dentro de la app. */
public class WebFragment extends Fragment {

    public static final String HOST = "colabellapetclub.com";
    public static final String START_URL = "https://" + HOST + "/";

    private WebView webView;
    private SwipeRefreshLayout swipeRefresh;
    private View offlineView;

    /** El sitio publica el menu segun quien haya entrado; la actividad lo escucha. */
    public interface MenuListener {
        void onMenuRecibido(String json);
    }

    private MenuListener menuListener;

    private ValueCallback<Uri[]> filePathCallback;
    private ActivityResultLauncher<Intent> fileChooserLauncher;
    private boolean loadError = false;
    private String urlPendiente = null;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        fileChooserLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (filePathCallback == null) {
                        return;
                    }
                    filePathCallback.onReceiveValue(WebChromeClient.FileChooserParams
                            .parseResult(result.getResultCode(), result.getData()));
                    filePathCallback = null;
                });
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_web, container, false);
    }

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        webView = view.findViewById(R.id.webview);
        swipeRefresh = view.findViewById(R.id.swipe_refresh);
        offlineView = view.findViewById(R.id.offline_view);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        // El WebView solo necesita la web: sin acceso a archivos locales ni a content://
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setUserAgentString(s.getUserAgentString() + " ColabellaApp/1.0");

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest request) {
                // Los iframes (pasarelas de pago incrustadas, verificacion 3D Secure del
                // banco...) navegan dentro de la pagina; sacarlos al navegador rompe el pago.
                String esquema = request.getUrl().getScheme();
                if (!request.isForMainFrame()
                        && ("https".equalsIgnoreCase(esquema) || "http".equalsIgnoreCase(esquema))) {
                    return false;
                }
                return manejarUrl(request.getUrl());
            }

            @Override
            @SuppressWarnings("deprecation")
            public boolean shouldOverrideUrlLoading(WebView v, String url) {
                return manejarUrl(Uri.parse(url));
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                swipeRefresh.setRefreshing(false);
                if (loadError) {
                    mostrarOffline();
                    return;
                }
                leerMenuDelSitio();
            }

            @Override
            public void onReceivedError(WebView v, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    loadError = true;
                }
            }

            @Override
            @SuppressWarnings("deprecation")
            public void onReceivedError(WebView v, int code, String desc, String failingUrl) {
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
                    loadError = true;
                }
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = callback;
                try {
                    fileChooserLauncher.launch(params.createIntent());
                    return true;
                } catch (ActivityNotFoundException e) {
                    filePathCallback = null;
                    aviso(getString(R.string.no_file_app));
                    return false;
                }
            }
        });

        webView.setDownloadListener((url, userAgent, disposition, mime, size) -> {
            try {
                DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url));
                req.setMimeType(mime);
                req.addRequestHeader("User-Agent", userAgent);
                req.addRequestHeader("Cookie", CookieManager.getInstance().getCookie(url));
                req.setNotificationVisibility(
                        DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                req.setDestinationInExternalPublicDir(
                        android.os.Environment.DIRECTORY_DOWNLOADS,
                        URLUtil.guessFileName(url, disposition, mime));
                DownloadManager dm = (DownloadManager)
                        requireContext().getSystemService(Context.DOWNLOAD_SERVICE);
                if (dm != null) {
                    dm.enqueue(req);
                    aviso(getString(R.string.downloading));
                }
            } catch (Exception e) {
                abrirFuera(Uri.parse(url));
            }
        });

        swipeRefresh.setColorSchemeResources(R.color.brand_accent, R.color.brand_primary);
        swipeRefresh.setOnRefreshListener(() -> {
            loadError = false;
            webView.reload();
        });

        view.findViewById(R.id.btn_retry).setOnClickListener(v -> {
            if (!hayRed()) {
                aviso(getString(R.string.offline_title));
                return;
            }
            offlineView.setVisibility(View.GONE);
            swipeRefresh.setVisibility(View.VISIBLE);
            loadError = false;
            webView.loadUrl(START_URL);
        });

        String inicial = urlPendiente != null ? urlPendiente : START_URL;
        urlPendiente = null;
        webView.loadUrl(inicial);
    }

    /** true si la URL es https y pertenece a colabellapetclub.com o a un subdominio. */
    public static boolean esDelSitio(@Nullable Uri uri) {
        if (uri == null || !"https".equalsIgnoreCase(uri.getScheme())) {
            return false;
        }
        String host = uri.getHost();
        return host != null && (host.equalsIgnoreCase(HOST) || host.toLowerCase(java.util.Locale.ROOT).endsWith("." + HOST));
    }

    /**
     * Carga una URL concreta, por ejemplo la que llega en una notificacion push o
     * en el menu del sitio. Lo que no sea del sitio se abre fuera de la app.
     */
    public void cargar(String url) {
        if (url == null) {
            return;
        }
        Uri uri = Uri.parse(url);
        if (!esDelSitio(uri)) {
            if (isAdded()) {
                abrirFuera(uri);
            }
            return;
        }
        if (webView == null) {
            urlPendiente = url;
        } else {
            loadError = false;
            offlineView.setVisibility(View.GONE);
            swipeRefresh.setVisibility(View.VISIBLE);
            webView.loadUrl(url);
        }
    }

    public boolean puedeRetroceder() {
        return webView != null && webView.canGoBack();
    }

    public void retroceder() {
        webView.goBack();
    }

    public void setMenuListener(MenuListener listener) {
        this.menuListener = listener;
    }

    /**
     * WordPress imprime window.COLABELLA_APP_MENU con el menu que corresponde
     * al usuario de la sesion. Se lee tras cada carga, asi que al iniciar o
     * cerrar sesion la barra se actualiza sola.
     */
    private void leerMenuDelSitio() {
        if (webView == null || menuListener == null) {
            return;
        }
        webView.evaluateJavascript(
                "(function(){try{return JSON.stringify(window.COLABELLA_APP_MENU||null);}"
                        + "catch(e){return null;}})()",
                valor -> {
                    String json = desenvolver(valor);
                    if (json != null && menuListener != null) {
                        menuListener.onMenuRecibido(json);
                    }
                });
    }

    /** evaluateJavascript devuelve el texto ya escapado como literal JSON. */
    @Nullable
    private String desenvolver(String valor) {
        if (valor == null || "null".equals(valor)) {
            return null;
        }
        try {
            Object o = new JSONTokener(valor).nextValue();
            return o instanceof String ? (String) o : null;
        } catch (Exception e) {
            return null;
        }
    }

    private boolean manejarUrl(Uri uri) {
        if (uri.getScheme() == null || esDelSitio(uri)) {
            return false;
        }
        abrirFuera(uri);
        return true;
    }

    private void abrirFuera(Uri uri) {
        if ("intent".equalsIgnoreCase(uri.getScheme())) {
            abrirIntent(uri.toString());
            return;
        }
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, uri);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (ActivityNotFoundException e) {
            aviso(getString(R.string.cannot_open_link));
        }
    }

    /**
     * Enlaces intent:// (WhatsApp, apps de pago...). Se limpian para que una pagina
     * no pueda lanzar componentes internos de la app ni de otras apps.
     */
    private void abrirIntent(String url) {
        Intent intent;
        try {
            intent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME);
        } catch (Exception e) {
            aviso(getString(R.string.cannot_open_link));
            return;
        }
        intent.addCategory(Intent.CATEGORY_BROWSABLE);
        intent.setComponent(null);
        intent.setSelector(null);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            startActivity(intent);
        } catch (ActivityNotFoundException e) {
            String alternativa = intent.getStringExtra("browser_fallback_url");
            if (alternativa != null && alternativa.startsWith("https://")) {
                abrirFuera(Uri.parse(alternativa));
            } else {
                aviso(getString(R.string.cannot_open_link));
            }
        }
    }

    private void mostrarOffline() {
        swipeRefresh.setRefreshing(false);
        swipeRefresh.setVisibility(View.GONE);
        offlineView.setVisibility(View.VISIBLE);
    }

    private boolean hayRed() {
        ConnectivityManager cm = (ConnectivityManager)
                requireContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) {
            return false;
        }
        NetworkInfo info = cm.getActiveNetworkInfo();
        return info != null && info.isConnected();
    }

    private void aviso(String msg) {
        if (isAdded()) {
            Toast.makeText(requireContext(), msg, Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onPause() {
        if (webView != null) {
            webView.onPause();
        }
        super.onPause();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (webView != null) {
            webView.onResume();
        }
    }
}
