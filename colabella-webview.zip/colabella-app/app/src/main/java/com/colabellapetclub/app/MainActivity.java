package com.colabellapetclub.app;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity implements WebFragment.MenuListener {

    public static final String EXTRA_ABRIR_MASCOTAS = "abrir_mascotas";

    private static final String TAG_WEB = "web";
    private static final String TAG_PETS = "pets";
    private static final String STATE_SECCION = "seccion";

    private WebFragment webFragment;
    private PetsFragment petsFragment;
    private Fragment actual;

    private BottomNavigationView nav;
    private View raiz;
    private ActivityResultLauncher<String> permisoNotificaciones;

    private MenuConfig menu;
    /** Posicion de la pestaña activa dentro del menu actual. */
    private int seleccion = 0;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Notifications.crearCanales(this);

        permisoNotificaciones = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(), concedido -> { });

        nav = findViewById(R.id.bottom_nav);
        raiz = findViewById(R.id.raiz);

        if (savedInstanceState != null) {
            webFragment = (WebFragment) getSupportFragmentManager().findFragmentByTag(TAG_WEB);
            petsFragment = (PetsFragment) getSupportFragmentManager().findFragmentByTag(TAG_PETS);
            seleccion = savedInstanceState.getInt(STATE_SECCION, 0);
        }
        if (webFragment == null) {
            webFragment = new WebFragment();
        }
        if (petsFragment == null) {
            petsFragment = new PetsFragment();
        }
        webFragment.setMenuListener(this);

        // Se empieza con el ultimo menu conocido para que la barra nunca salga vacia
        menu = MenuConfig.cargar(this);
        pintarMenu();

        nav.setOnItemSelectedListener(this::alSeleccionar);

        if (savedInstanceState == null) {
            mostrar(webFragment, TAG_WEB);
        } else {
            actual = getSupportFragmentManager().findFragmentById(R.id.contenedor);
        }

        ocultarBarraConTeclado();
        manejarIntent(getIntent());
        pedirPermisoNotificaciones();

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (actual == webFragment && webFragment.puedeRetroceder()) {
                    webFragment.retroceder();
                    return;
                }
                if (seleccion != 0) {
                    seleccionar(0);
                    return;
                }
                setEnabled(false);
                getOnBackPressedDispatcher().onBackPressed();
            }
        });
    }

    // --- Menu dinamico -----------------------------------------------------

    /** El sitio manda un menu distinto segun sea visitante, socio o negocio. */
    @Override
    public void onMenuRecibido(String json) {
        MenuConfig nuevo = MenuConfig.desdeJson(json);
        if (nuevo == null || nuevo.equivaleA(menu)) {
            return;
        }
        // Se recuerda en que seccion estaba el usuario para no sacarlo de ella
        String idActual = seleccion < menu.items.size() ? menu.items.get(seleccion).id : null;
        menu = nuevo;
        menu.guardar(this, json);
        pintarMenu();

        int destino = 0;
        for (int i = 0; i < menu.items.size(); i++) {
            if (menu.items.get(i).id.equals(idActual)) {
                destino = i;
                break;
            }
        }
        seleccion = destino;
        nav.getMenu().getItem(destino).setChecked(true);
    }

    private void pintarMenu() {
        Menu m = nav.getMenu();
        m.clear();
        for (int i = 0; i < menu.items.size(); i++) {
            MenuConfig.Item item = menu.items.get(i);
            MenuItem mi = m.add(Menu.NONE, i, i, item.titulo);
            mi.setIcon(MenuConfig.iconoDe(item.icono));
        }
        if (seleccion >= menu.items.size()) {
            seleccion = 0;
        }
        if (!menu.items.isEmpty()) {
            m.getItem(seleccion).setChecked(true);
        }
    }

    private boolean alSeleccionar(MenuItem item) {
        return seleccionar(item.getItemId());
    }

    private boolean seleccionar(int posicion) {
        if (posicion < 0 || posicion >= menu.items.size()) {
            return false;
        }
        MenuConfig.Item destino = menu.items.get(posicion);
        boolean cambia = posicion != seleccion;
        seleccion = posicion;

        if (destino.nativo) {
            mostrar(petsFragment, TAG_PETS);
        } else {
            boolean veniaDeOtroSitio = actual != webFragment;
            mostrar(webFragment, TAG_WEB);
            if (cambia || veniaDeOtroSitio) {
                webFragment.cargar(destino.url);
            }
        }
        if (nav.getMenu().size() > posicion) {
            nav.getMenu().getItem(posicion).setChecked(true);
        }
        return true;
    }

    // --- Resto -------------------------------------------------------------

    /**
     * La barra estorba al escribir, sobre todo en el formulario de acceso.
     * Se esconde mientras el teclado esta abierto.
     */
    private void ocultarBarraConTeclado() {
        raiz.getViewTreeObserver().addOnGlobalLayoutListener(() -> {
            Rect r = new Rect();
            raiz.getWindowVisibleDisplayFrame(r);
            int alturaTotal = raiz.getRootView().getHeight();
            boolean tecladoAbierto = (alturaTotal - r.height()) > alturaTotal * 0.15;
            int deseado = tecladoAbierto ? View.GONE : View.VISIBLE;
            if (nav.getVisibility() != deseado) {
                nav.setVisibility(deseado);
            }
        });
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        manejarIntent(intent);
    }

    /** Atiende los accesos directos del icono y los enlaces de las notificaciones. */
    private void manejarIntent(@Nullable Intent intent) {
        if (intent == null) {
            return;
        }
        if (intent.getBooleanExtra(EXTRA_ABRIR_MASCOTAS, false)) {
            for (int i = 0; i < menu.items.size(); i++) {
                if (menu.items.get(i).nativo) {
                    seleccionar(i);
                    return;
                }
            }
            return;
        }
        Uri data = intent.getData();
        if (data != null && data.getScheme() != null && data.getScheme().startsWith("http")) {
            seleccionar(0);
            webFragment.cargar(data.toString());
        }
    }

    private void mostrar(Fragment fragment, String tag) {
        if (fragment == actual) {
            return;
        }
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.contenedor, fragment, tag)
                .commit();
        actual = fragment;
    }

    private void pedirPermisoNotificaciones() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
            return;
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            permisoNotificaciones.launch(Manifest.permission.POST_NOTIFICATIONS);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(STATE_SECCION, seleccion);
    }
}
