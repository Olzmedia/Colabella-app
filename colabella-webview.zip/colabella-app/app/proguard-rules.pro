-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# Conserva numeros de linea en los informes de fallos de Play Console
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile

# Puente con la web (window.ColabellaApp): el WebView llama a sus metodos por reflexion
-keep class com.colabellapetclub.app.SincronizacionWeb$Puente { *; }
