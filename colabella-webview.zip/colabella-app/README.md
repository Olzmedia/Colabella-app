# Colabella Pet Club — App Android

App del club con dos secciones: el sitio web y una ficha de mascotas nativa que funciona sin conexión.

Paquete: `com.colabellapetclub.app` — coincide con el proyecto de Firebase `colabella-pet-club`.

## Qué hace

**Pestaña Inicio** — `colabellapetclub.com` dentro de la app. Navegación interna en el WebView; teléfono, WhatsApp, mapas y pasarelas de pago salen a su app. Deslizar para recargar, botón atrás con historial, subida de archivos desde formularios, descargas con la sesión intacta, y pantalla de reintento si no hay red.

**Pestaña Mis mascotas** — nativa y offline. Ficha con nombre, especie, raza, notas y fecha de próxima vacuna. Los datos viven en el dispositivo, así que se consultan sin internet y sobreviven al cambio de móvil vía copia de seguridad de Android.

**Recordatorios de vacunas** — al guardar una fecha, el teléfono programa un aviso para las 9:00 de ese día. No depende del servidor y se reprograma solo tras reiniciar el móvil.

**Notificaciones push** — vía Firebase Cloud Messaging, para promociones y comunicados. Se envían desde la consola de Firebase.

**Acceso directo** — al mantener pulsado el icono aparece "Mascotas", que entra directo a esa sección.

## Enviar una notificación push

1. Consola de Firebase → proyecto `colabella-pet-club` → Messaging → Nueva campaña.
2. Escribe título y texto, y elige la app como destino.
3. Para que al tocarla se abra una página concreta del sitio, añade en *Datos personalizados* la clave `url` con el valor de la dirección.

Las promociones llegan por el canal "Avisos del club" y los recordatorios de vacuna por otro distinto, así que el usuario puede silenciar uno sin perder el otro.

## Compilar

GitHub Actions con el workflow incluido, o `gradle assembleDebug` en local con JDK 17, Gradle 8.13 y el SDK de Android 36.

El proyecto apunta a **Android 16 (targetSdk 36)**, el mínimo que exige Google Play para apps nuevas y actualizaciones desde el 31 de agosto de 2026.

## Publicar en Google Play

Play exige un **AAB firmado**, no el APK de debug. El workflow lo genera solo si el repositorio tiene el keystore en sus secretos.

1. Genera el keystore de subida y **guárdalo a buen recaudo** (con Play App Signing, si se pierde se puede pedir un cambio de clave de subida, pero es un trámite):
   ```
   keytool -genkey -v -keystore colabella.jks -alias colabella -keyalg RSA -keysize 2048 -validity 10000
   ```
2. En GitHub → Settings → Secrets and variables → Actions, crea:
   | Secreto | Valor |
   |---|---|
   | `COLABELLA_KEYSTORE_BASE64` | salida de `base64 -w0 colabella.jks` |
   | `COLABELLA_KEYSTORE_PASSWORD` | contraseña del keystore |
   | `COLABELLA_KEY_ALIAS` | `colabella` |
   | `COLABELLA_KEY_PASSWORD` | contraseña de la clave |
3. Ejecuta el workflow. El artefacto `colabella-petclub-release-aab` trae `app-release.aab` (para subir) y `mapping.txt` (súbelo en Play Console → Explorador de App Bundle → Descargas, para leer los fallos).
4. El `versionCode` es el número de ejecución del workflow, así que cada AAB nuevo sirve para una actualización sin tocar el código.

En local: `COLABELLA_KEYSTORE=/ruta/colabella.jks COLABELLA_KEYSTORE_PASSWORD=… COLABELLA_KEY_ALIAS=colabella COLABELLA_KEY_PASSWORD=… VERSION_CODE=2 gradle bundleRelease`.

### Lista para Play Console

**Permisos que pide la app y por qué** (todos se piden en el momento de usarse, nunca al instalar):

| Permiso | Para qué | ¿Requiere declaración en Play? |
|---|---|---|
| `INTERNET`, `ACCESS_NETWORK_STATE` | Cargar el sitio y detectar si hay red | No |
| `POST_NOTIFICATIONS` | Promociones y recordatorios de vacuna | No |
| `CAMERA` | Tomar una foto al subir imágenes en la web, y cámara en vivo de la página | No (es permiso de ejecución, se pide al tocar "subir foto") |
| `RECEIVE_BOOT_COMPLETED` | Reprogramar los recordatorios tras reiniciar el teléfono | No |

Lo que la app **no** usa, a propósito, porque Play lo restringe: acceso a la galería
completa (`READ_MEDIA_IMAGES`, se usa el selector del sistema), alarmas exactas
(`SCHEDULE_EXACT_ALARM`, los recordatorios usan alarmas inexactas), ubicación,
contactos e ID de publicidad (`AD_ID` se elimina del manifiesto).

**Seguridad de los datos** — respuestas que corresponden a esta app:

| Tipo de dato | ¿Se recopila? | Para qué |
|---|---|---|
| Fotos | Sí, si el usuario sube una imagen en un formulario del sitio | Funcionalidad de la app |
| Información personal (nombre, email, teléfono) | Sí, la que pidan los formularios y el registro del sitio | Funcionalidad, gestión de la cuenta |
| Identificadores del dispositivo (token de Firebase) | Sí | Notificaciones push |
| Ficha de mascotas | **No**: se queda en el teléfono, no se envía a ningún servidor | — |

Todo cifrado en tránsito (HTTPS). Si el sitio usa analítica (Google Analytics, píxel de
Meta...) dentro de la app, también se declara: lo que recopila la web cuenta como
recopilado por la app.

**Otros requisitos:**

- **Política de privacidad**: URL pública en la ficha de Play **y** visible dentro de la app
  (basta con un enlace en el pie del sitio). Debe mencionar la cámara, las fotos y las
  notificaciones.
- **Eliminación de cuenta**: el sitio permite crear cuentas de socio y negocio, así que Play
  exige dos cosas: un camino *dentro de la app* para borrar la cuenta (p. ej. botón
  "Eliminar mi cuenta" en el perfil del sitio) y una *URL web* donde pedirlo sin instalar la
  app. Esa URL se declara en Seguridad de los datos.
- **ID de publicidad**: responder "No".
- **Pagos de membresía**: si la membresía da descuentos o servicios en negocios físicos,
  queda fuera de la facturación de Google Play. Si desbloquea contenido digital dentro de
  la app, Play exigiría su sistema de pagos.
- **Clasificación de contenido**: obligatoria; una app sin clasificar se retira.
- **Público objetivo**: no marcar menores de 13 años salvo que aplique.
- **Cuenta personal** creada después de noviembre de 2023: prueba cerrada con 12 testers
  durante 14 días antes de pasar a producción.
- **16 KB**: el workflow comprueba en cada compilación que las librerías nativas sean
  compatibles. Si falla ese paso, no subas el AAB.

Sobre la política de *mínima funcionalidad*: la ficha offline, los recordatorios locales, el
push y el acceso directo son funciones que un navegador no ofrece, que es justo lo que
Google mira. Por eso la pestaña **Mascotas está siempre en la barra inferior**, aunque el
sitio no la incluya en su menú. Aun así la revisión es humana y nadie puede garantizar el
resultado; si la rechazan, el motivo llega por escrito y suele ser concreto. Conviene que
las capturas de la ficha de Play muestren la pestaña de mascotas y los recordatorios, no
solo la web.

## Sincronización con la web (menú y mascotas)

Al terminar de cargar cada página del sitio, la app ejecuta dentro de la sesión del
WebView los mismos pasos que usa /mi-perfil/:

1. `admin-ajax.php?action=clubd_whoami` → si hay sesión y la llave (nonce) de la API.
   No pasa por la caché de LiteSpeed.
2. `/wp-json/cdmenu/v1/menu` → el menú según el rol (plugin *Colabella — Menú de la app*).
3. `/wp-json/club/v1/mascotas` → las mascotas del socio (plugin *club-descuentos*).

No hace falta tocar WordPress. Los datos vuelven a la app por el puente
`window.ColabellaApp`, protegido con un token aleatorio que solo conoce el script
inyectado por la app (un iframe de otro sitio no puede usarlo).

**Mascotas:** las fichas de la cuenta se guardan en el teléfono (funcionan sin
conexión), se marcan "De tu cuenta Colabella" y programan el recordatorio con la
vacuna `proxima` más cercana. Se editan en la web: al tocarlas, la app ofrece abrir
/mi-perfil/. Al cerrar sesión se quitan del teléfono. Las fichas creadas en la app
siguen siendo locales.

Cada ficha de la cuenta muestra su **foto** (miniatura `medium` de WordPress, con
caché en disco gracias a Glide: se ve sin conexión después de la primera vez) o, si no
tiene, el emoji de su tipo (🐶, 🐱) o la huella, igual que el medallón de la web.

Al tocarla se abre `FichaMascota` (hoja que sube desde abajo, con el estilo del panel
de la mascota de la web: degradado, foto en cuadro con borde blanco, tarjetas con
sombra, iconos Tabler y tipografías Poppins y Jost, incluidas en `res/font`), copia de la ficha de /mi-perfil/
(`window.cdVerMascota` en `colabella-mi-perfil.php`): cabecera con foto y pastillas de
raza, sexo y edad; cifras (peso, próxima dosis, ficha completa x/12); el aviso
(Atención, Empecemos, Próxima dosis, Casi está, Todo al día); y los bloques Salud,
Vacunas y desparasitación (ordenadas, con estado Vencida / Hoy / En N días / Al día /
Sin próxima), Identificación y Su veterinario con botón para llamar. Mismos textos,
colores y reglas (`edadDe`, `diasHasta`, `proximaVacuna`, `fichaHechos`,
`avisoFicha`): **si la web cambia esas reglas, hay que cambiarlas también en
`FichaMascota.java`.** Documentos y Comida se abren en la web.

Para el emoji del tipo, `clubd_mascota_a_array()` de `club-descuentos/mascotas.php`
debe incluir `'tipo' => get_post_meta( $id, 'tipo', true ),`: la web lo guarda pero la
API no lo devolvía. Sin esa línea, las mascotas sin foto muestran la huella.

## Continuar con Google / Apple

Google bloquea el inicio de sesión dentro de un WebView ("Error 403:
disallowed_useragent"), así que la app lo hace en una pestaña de Chrome:

1. El WebView añade ` ColabellaSocial/1` al User-Agent (después de
   `ColabellaApp/1.0`). Con eso la web muestra los botones en /acceso/ y /registro/.
2. Las direcciones `https://colabellapetclub.com/wp-json/club/v1/social/google/inicio`
   y `.../social/apple/inicio` nunca se cargan en el WebView: se abren en una
   pestaña de Chrome (Custom Tabs, `androidx.browser`). Si el teléfono no tiene
   navegador compatible, se abren en el navegador normal.
   (`WebFragment.esInicioSocial` / `abrirInicioSocial`, en las dos firmas de
   `shouldOverrideUrlLoading` y en `cargar`.)
3. Al terminar, la web abre `colabella://entrar?ticket=XXXX`. `MainActivity`
   (ahora `singleTask`, con el intent-filter `colabella://entrar`) lo recibe en
   `onCreate` o en `onNewIntent`, valida el ticket (`^[A-Za-z0-9]{10,80}$`) y
   carga `.../wp-json/club/v1/social/canjear?ticket=XXXX` en el WebView. La web
   crea la sesión y redirige a /mi-membresia/, /panel-negocio/ o
   /registro/?completar=1.
4. Tras el canje se llama a `CookieManager.flush()` para que la sesión quede
   guardada aunque se cierre la app. También se guarda al pasar a segundo plano.

El ticket dura 60 segundos y sirve una sola vez: la app no lo vuelve a usar si
se reabre desde Recientes ni al recrear la pantalla.

## Versión instalada

El código de versión es 1000 + el número de ejecución de GitHub Actions, y el
nombre de versión termina en ese código (`1.1.1044` = ejecución 44). Al compilar
en Android Studio se usa `VERSION_CODE` de `gradle.properties` (47 → 1047):
súbelo en 1 antes de cada AAB que generes ahí. Se ve en
Ajustes → Aplicaciones → Colabella, para saber exactamente qué compilación hay.
El salto a 1000 deja la app por encima de todas las versiones subidas antes a
Play (1 a 43), que ya no pueden bloquear a las nuevas.

## Personalizar

| Qué | Dónde |
|---|---|
| Dominio del sitio | `WebFragment.java` → constante `HOST` |
| Textos | `res/values/strings.xml` |
| Colores | `res/values/colors.xml` (los de la barra inferior empiezan por `nav_`) |
| Estilo de la barra inferior | `res/values/themes.xml` → `Widget.Colabella.BottomNav` |
| Iconos de la barra | `res/drawable/nav_*` (`_off` trazo, `_on` relleno) |
| Icono | `res/mipmap-*/` |
| Hora del recordatorio | `ReminderReceiver.java` → `HOUR_OF_DAY` |
