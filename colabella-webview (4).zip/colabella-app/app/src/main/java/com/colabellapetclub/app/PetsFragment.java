package com.colabellapetclub.app;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.DateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * Pestana nativa: la ficha de las mascotas del socio.
 * Se consulta sin conexion y programa avisos de vacunacion.
 */
public class PetsFragment extends Fragment implements PetAdapter.Listener {

    private PetStore store;
    private PetAdapter adapter;
    private View vacio;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_pets, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        store = new PetStore(requireContext());
        vacio = view.findViewById(R.id.estado_vacio);

        RecyclerView lista = view.findViewById(R.id.lista_pets);
        lista.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new PetAdapter(this);
        lista.setAdapter(adapter);

        FloatingActionButton fab = view.findViewById(R.id.fab_add);
        fab.setOnClickListener(v -> mostrarDialogo(null));

        refrescar();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (adapter != null) {
            refrescar();
        }
    }

    private void refrescar() {
        List<Pet> lista = store.listar();
        adapter.actualizar(lista);
        vacio.setVisibility(lista.isEmpty() ? View.VISIBLE : View.GONE);
    }

    @Override
    public void onEditar(Pet pet) {
        mostrarDialogo(pet);
    }

    @Override
    public void onEliminar(Pet pet) {
        new AlertDialog.Builder(requireContext())
                .setTitle(getString(R.string.eliminar_titulo, pet.nombre))
                .setMessage(R.string.eliminar_mensaje)
                .setNegativeButton(R.string.cancelar, null)
                .setPositiveButton(R.string.eliminar, (d, w) -> {
                    pet.proximaVacuna = 0;
                    ReminderReceiver.programar(requireContext(), pet);
                    store.eliminar(pet.id);
                    refrescar();
                })
                .show();
    }

    private void mostrarDialogo(@Nullable Pet existente) {
        View form = LayoutInflater.from(requireContext())
                .inflate(R.layout.dialog_pet, null, false);

        EditText nombre = form.findViewById(R.id.campo_nombre);
        EditText especie = form.findViewById(R.id.campo_especie);
        EditText raza = form.findViewById(R.id.campo_raza);
        EditText notas = form.findViewById(R.id.campo_notas);
        Button fecha = form.findViewById(R.id.campo_fecha);
        TextView limpiar = form.findViewById(R.id.limpiar_fecha);

        final Pet pet = existente != null ? existente : new Pet();
        final long[] seleccion = { pet.proximaVacuna };

        if (existente != null) {
            nombre.setText(pet.nombre);
            especie.setText(pet.especie);
            raza.setText(pet.raza);
            notas.setText(pet.notas);
        }
        pintarFecha(fecha, limpiar, seleccion[0]);

        fecha.setOnClickListener(v -> {
            Calendar c = Calendar.getInstance();
            if (seleccion[0] > 0) {
                c.setTimeInMillis(seleccion[0]);
            }
            DatePickerDialog dp = new DatePickerDialog(requireContext(), (picker, y, m, d) -> {
                Calendar elegido = Calendar.getInstance();
                elegido.set(y, m, d, 9, 0, 0);
                elegido.set(Calendar.MILLISECOND, 0);
                seleccion[0] = elegido.getTimeInMillis();
                pintarFecha(fecha, limpiar, seleccion[0]);
            }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH));
            dp.getDatePicker().setMinDate(System.currentTimeMillis() - 1000);
            dp.show();
        });

        limpiar.setOnClickListener(v -> {
            seleccion[0] = 0;
            pintarFecha(fecha, limpiar, 0);
        });

        AlertDialog dialog = new AlertDialog.Builder(requireContext())
                .setTitle(existente == null ? R.string.nueva_mascota : R.string.editar_mascota)
                .setView(form)
                .setNegativeButton(R.string.cancelar, null)
                .setPositiveButton(R.string.guardar, null)
                .create();

        dialog.show();
        // Se valida antes de cerrar: si falta el nombre, el dialogo sigue abierto
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String n = nombre.getText().toString().trim();
            if (n.isEmpty()) {
                nombre.setError(getString(R.string.nombre_obligatorio));
                return;
            }
            pet.nombre = n;
            pet.especie = especie.getText().toString().trim();
            pet.raza = raza.getText().toString().trim();
            pet.notas = notas.getText().toString().trim();
            pet.proximaVacuna = seleccion[0];

            store.guardar(pet);
            ReminderReceiver.programar(requireContext(), pet);
            refrescar();
            dialog.dismiss();
        });
    }

    private void pintarFecha(Button boton, TextView limpiar, long valor) {
        if (valor > 0) {
            boton.setText(DateFormat.getDateInstance(DateFormat.MEDIUM).format(new Date(valor)));
            limpiar.setVisibility(View.VISIBLE);
        } else {
            boton.setText(R.string.sin_fecha);
            limpiar.setVisibility(View.GONE);
        }
    }
}
