package com.colabellapetclub.app;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Guarda las mascotas en el dispositivo. Todo funciona sin conexion:
 * los datos viven en SharedPreferences como un array JSON.
 */
public class PetStore {

    private static final String PREFS = "colabella_pets";
    private static final String KEY = "pets";

    private final SharedPreferences prefs;

    public PetStore(Context context) {
        this.prefs = context.getApplicationContext()
                .getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public List<Pet> listar() {
        List<Pet> lista = new ArrayList<>();
        String raw = prefs.getString(KEY, "[]");
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                lista.add(Pet.fromJson(arr.getJSONObject(i)));
            }
        } catch (Exception e) {
            // Si los datos estuvieran corruptos, empezamos de cero en vez de crashear
            return new ArrayList<>();
        }
        return lista;
    }

    public void guardar(Pet pet) {
        List<Pet> lista = listar();
        boolean actualizado = false;
        for (int i = 0; i < lista.size(); i++) {
            if (lista.get(i).id.equals(pet.id)) {
                lista.set(i, pet);
                actualizado = true;
                break;
            }
        }
        if (!actualizado) {
            lista.add(pet);
        }
        persistir(lista);
    }

    public void eliminar(String id) {
        List<Pet> lista = listar();
        for (int i = 0; i < lista.size(); i++) {
            if (lista.get(i).id.equals(id)) {
                lista.remove(i);
                break;
            }
        }
        persistir(lista);
    }

    public Pet porId(String id) {
        for (Pet p : listar()) {
            if (p.id.equals(id)) {
                return p;
            }
        }
        return null;
    }

    private void persistir(List<Pet> lista) {
        JSONArray arr = new JSONArray();
        for (Pet p : lista) {
            try {
                arr.put(p.toJson());
            } catch (Exception ignored) {
            }
        }
        prefs.edit().putString(KEY, arr.toString()).apply();
    }
}
