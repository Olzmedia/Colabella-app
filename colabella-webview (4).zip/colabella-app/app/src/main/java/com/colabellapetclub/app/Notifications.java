package com.colabellapetclub.app;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;

/** Centraliza la creacion de los canales de notificacion. */
public class Notifications {

    public static final String CANAL_RECORDATORIOS = "recordatorios";
    public static final String CANAL_AVISOS = "avisos";

    public static void crearCanales(Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            return;
        }
        NotificationManager nm = context.getSystemService(NotificationManager.class);
        if (nm == null) {
            return;
        }

        NotificationChannel recordatorios = new NotificationChannel(
                CANAL_RECORDATORIOS,
                context.getString(R.string.canal_recordatorios),
                NotificationManager.IMPORTANCE_HIGH);
        recordatorios.setDescription(context.getString(R.string.canal_recordatorios_desc));
        nm.createNotificationChannel(recordatorios);

        NotificationChannel avisos = new NotificationChannel(
                CANAL_AVISOS,
                context.getString(R.string.canal_avisos),
                NotificationManager.IMPORTANCE_DEFAULT);
        avisos.setDescription(context.getString(R.string.canal_avisos_desc));
        nm.createNotificationChannel(avisos);
    }
}
