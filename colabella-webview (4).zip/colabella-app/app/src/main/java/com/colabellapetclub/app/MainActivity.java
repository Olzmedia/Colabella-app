package com.colabellapetclub.app;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    public static final String EXTRA_ABRIR_MASCOTAS = "abrir_mascotas";

    private static final String TAG_WEB = "web";
    private static final String TAG_PETS = "pets";

    private WebFragment webFragment;
    private PetsFragment petsFragment;
    private Fragment actual;

    private BottomNavigationView nav;
    private View raiz;
    private ActivityResultLauncher<String> permisoNotificaciones;

    /** Ultima seccion web mostrada, para no recargar si se vuelve a pulsar la misma. */
    private int seccionWeb = 0;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Notifications.crearCanales(this);

        permisoNotificaciones = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(), concedido -> { });

        nav = findViewById(R.id.bottom_nav);
        raiz = findViewById(R.id.raiz);

        if (savedInstanceState != null) {
            webFragment = (WebFragment) getSupportFragmentManager().findFragmentByTag(TAG_WEB);
            petsFragment = (PetsFragment) getSupportFragmentManager().findFragmentByTag(TAG_PETS);
        }
        if (webFragment == null) {
            webFragment = new WebFragment();
        }
        if (petsFragment == null) {
            petsFragment = new PetsFragment();
        }

        nav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_mascotas) {
                mostrar(petsFragment, TAG_PETS);
                return true;
            }
            String url = urlDeSeccion(id);
            if (url == null) {
                return false;
            }
            boolean cambioDeSeccion = (id != seccionWeb) || actual != webFragment;
            seccionWeb = id;
            mostrar(webFragment, TAG_WEB);
            if (cambioDeSeccion) {
                webFragment.cargar(url);
            }
            return true;
        });

        if (savedInstanceState == null) {
            seccionWeb = R.id.nav_inicio;
            mostrar(webFragment, TAG_WEB);
        } else {
            actual = getSupportFragmentManager().findFragmentById(R.id.contenedor);
        }

        ocultarBarraConTeclado();
        manejarIntent(getIntent());
        pedirPermisoNotificaciones();

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (actual == webFragment && webFragment.puedeRetroceder()) {
                    webFragment.retroceder();
                    return;
                }
                if (actual != webFragment || seccionWeb != R.id.nav_inicio) {
                    nav.setSelectedItemId(R.id.nav_inicio);
                    return;
                }
                setEnabled(false);
                getOnBackPressedDispatcher().onBackPressed();
            }
        });
    }

    @Nullable
    private String urlDeSeccion(int id) {
        if (id == R.id.nav_inicio) {
            return WebFragment.START_URL;
        }
        if (id == R.id.nav_mapa) {
            return WebFragment.START_URL + "mapa/";
        }
        if (id == R.id.nav_negocios) {
            return WebFragment.START_URL + "negocios/";
        }
        if (id == R.id.nav_membresia) {
            return WebFragment.START_URL + "mi-membresia/";
        }
        return null;
    }

    /**
     * La barra inferior estorba al escribir, sobre todo en el formulario de acceso.
     * Se esconde mientras el teclado esta abierto.
     */
    private void ocultarBarraConTeclado() {
        raiz.getViewTreeObserver().addOnGlobalLayoutListener(() -> {
            Rect r = new Rect();
            raiz.getWindowVisibleDisplayFrame(r);
            int alturaVisible = r.height();
            int alturaTotal = raiz.getRootView().getHeight();
            boolean tecladoAbierto = (alturaTotal - alturaVisible) > alturaTotal * 0.15;
            int deseado = tecladoAbierto ? View.GONE : View.VISIBLE;
            if (nav.getVisibility() != deseado) {
                nav.setVisibility(deseado);
            }
        });
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        manejarIntent(intent);
    }

    /** Atiende los accesos directos del icono y los enlaces de las notificaciones. */
    private void manejarIntent(@Nullable Intent intent) {
        if (intent == null) {
            return;
        }
        if (intent.getBooleanExtra(EXTRA_ABRIR_MASCOTAS, false)) {
            nav.setSelectedItemId(R.id.nav_mascotas);
            return;
        }
        Uri data = intent.getData();
        if (data != null && data.getScheme() != null && data.getScheme().startsWith("http")) {
            seccionWeb = 0;
            nav.setSelectedItemId(R.id.nav_inicio);
            seccionWeb = R.id.nav_inicio;
            webFragment.cargar(data.toString());
        }
    }

    private void mostrar(Fragment fragment, String tag) {
        if (fragment == actual) {
            return;
        }
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.contenedor, fragment, tag)
                .commit();
        actual = fragment;
    }

    private void pedirPermisoNotificaciones() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
            return;
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            permisoNotificaciones.launch(Manifest.permission.POST_NOTIFICATIONS);
        }
    }
}
