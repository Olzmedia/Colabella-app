package com.colabellapetclub.app;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class PetAdapter extends RecyclerView.Adapter<PetAdapter.Holder> {

    public interface Listener {
        void onEditar(Pet pet);
        void onEliminar(Pet pet);
    }

    private final List<Pet> datos = new ArrayList<>();
    private final Listener listener;

    public PetAdapter(Listener listener) {
        this.listener = listener;
    }

    public void actualizar(List<Pet> nuevos) {
        datos.clear();
        datos.addAll(nuevos);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_pet, parent, false);
        return new Holder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull Holder h, int position) {
        Pet p = datos.get(position);
        h.nombre.setText(p.nombre);

        StringBuilder sub = new StringBuilder();
        if (!p.especie.isEmpty()) {
            sub.append(p.especie);
        }
        if (!p.raza.isEmpty()) {
            if (sub.length() > 0) {
                sub.append(" · ");
            }
            sub.append(p.raza);
        }
        h.detalle.setText(sub.toString());
        h.detalle.setVisibility(sub.length() > 0 ? View.VISIBLE : View.GONE);

        if (p.proximaVacuna > 0) {
            String fecha = DateFormat.getDateInstance(DateFormat.MEDIUM)
                    .format(new Date(p.proximaVacuna));
            long dias = TimeUnit.MILLISECONDS.toDays(
                    p.proximaVacuna - System.currentTimeMillis());
            String texto;
            if (dias < 0) {
                texto = h.itemView.getContext().getString(R.string.vacuna_vencida, fecha);
            } else if (dias == 0) {
                texto = h.itemView.getContext().getString(R.string.vacuna_hoy);
            } else {
                texto = h.itemView.getContext()
                        .getString(R.string.vacuna_proxima, fecha, String.valueOf(dias));
            }
            h.vacuna.setText(texto);
            h.vacuna.setVisibility(View.VISIBLE);
        } else {
            h.vacuna.setVisibility(View.GONE);
        }

        h.notas.setText(p.notas);
        h.notas.setVisibility(p.notas.isEmpty() ? View.GONE : View.VISIBLE);

        h.itemView.setOnClickListener(v -> listener.onEditar(p));
        h.borrar.setOnClickListener(v -> listener.onEliminar(p));
    }

    @Override
    public int getItemCount() {
        return datos.size();
    }

    static class Holder extends RecyclerView.ViewHolder {
        final TextView nombre;
        final TextView detalle;
        final TextView vacuna;
        final TextView notas;
        final ImageButton borrar;

        Holder(@NonNull View v) {
            super(v);
            nombre = v.findViewById(R.id.pet_nombre);
            detalle = v.findViewById(R.id.pet_detalle);
            vacuna = v.findViewById(R.id.pet_vacuna);
            notas = v.findViewById(R.id.pet_notas);
            borrar = v.findViewById(R.id.pet_borrar);
        }
    }
}
