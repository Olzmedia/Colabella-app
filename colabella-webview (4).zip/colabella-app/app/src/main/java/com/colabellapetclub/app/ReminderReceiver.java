package com.colabellapetclub.app;

import android.app.AlarmManager;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import androidx.core.app.NotificationCompat;

import java.util.Calendar;
import java.util.List;

/**
 * Dispara el recordatorio de vacuna. Funciona sin conexion: la alarma la
 * programa el propio dispositivo, no depende del servidor.
 */
public class ReminderReceiver extends BroadcastReceiver {

    public static final String EXTRA_PET_ID = "pet_id";
    private static final String ACTION_REMINDER = "com.colabellapetclub.app.RECORDATORIO";

    @Override
    public void onReceive(Context context, Intent intent) {
        // Tras un reinicio del telefono hay que reprogramar todas las alarmas
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            reprogramarTodas(context);
            return;
        }

        String petId = intent.getStringExtra(EXTRA_PET_ID);
        if (petId == null) {
            return;
        }
        Pet pet = new PetStore(context).porId(petId);
        if (pet == null) {
            return;
        }

        Notifications.crearCanales(context);

        Intent abrir = new Intent(context, MainActivity.class);
        abrir.putExtra(MainActivity.EXTRA_ABRIR_MASCOTAS, true);
        abrir.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);

        PendingIntent pi = PendingIntent.getActivity(
                context, petId.hashCode(), abrir, banderas());

        NotificationCompat.Builder b = new NotificationCompat.Builder(
                context, Notifications.CANAL_RECORDATORIOS)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle(context.getString(R.string.recordatorio_titulo))
                .setContentText(context.getString(R.string.recordatorio_texto, pet.nombre))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(pi);

        NotificationManager nm =
                (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) {
            nm.notify(petId.hashCode(), b.build());
        }
    }

    /** Programa (o cancela, si la fecha es 0 o ya paso) el aviso de una mascota. */
    public static void programar(Context context, Pet pet) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am == null) {
            return;
        }

        Intent i = new Intent(context, ReminderReceiver.class);
        i.setAction(ACTION_REMINDER);
        i.putExtra(EXTRA_PET_ID, pet.id);
        PendingIntent pi = PendingIntent.getBroadcast(
                context, pet.id.hashCode(), i, banderas());

        am.cancel(pi);

        if (pet.proximaVacuna <= 0) {
            return;
        }

        // Avisar a las 9:00 del dia elegido
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(pet.proximaVacuna);
        c.set(Calendar.HOUR_OF_DAY, 9);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);

        if (c.getTimeInMillis() <= System.currentTimeMillis()) {
            return;
        }

        // Alarma inexacta: no necesita el permiso SCHEDULE_EXACT_ALARM
        am.set(AlarmManager.RTC_WAKEUP, c.getTimeInMillis(), pi);
    }

    private static void reprogramarTodas(Context context) {
        List<Pet> lista = new PetStore(context).listar();
        for (Pet p : lista) {
            programar(context, p);
        }
    }

    private static int banderas() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            return PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE;
        }
        return PendingIntent.FLAG_UPDATE_CURRENT;
    }
}
