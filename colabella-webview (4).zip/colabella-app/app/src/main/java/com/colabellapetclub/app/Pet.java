package com.colabellapetclub.app;

import org.json.JSONException;
import org.json.JSONObject;

/** Una mascota guardada localmente en el dispositivo. */
public class Pet {

    public String id;
    public String nombre;
    public String especie;
    public String raza;
    /** Fecha de la proxima vacuna en milisegundos, o 0 si no hay ninguna programada. */
    public long proximaVacuna;
    public String notas;

    public Pet() {
        this.id = String.valueOf(System.currentTimeMillis());
        this.especie = "";
        this.raza = "";
        this.notas = "";
    }

    public JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("id", id);
        o.put("nombre", nombre);
        o.put("especie", especie);
        o.put("raza", raza);
        o.put("proximaVacuna", proximaVacuna);
        o.put("notas", notas);
        return o;
    }

    public static Pet fromJson(JSONObject o) {
        Pet p = new Pet();
        p.id = o.optString("id", String.valueOf(System.currentTimeMillis()));
        p.nombre = o.optString("nombre", "");
        p.especie = o.optString("especie", "");
        p.raza = o.optString("raza", "");
        p.proximaVacuna = o.optLong("proximaVacuna", 0);
        p.notas = o.optString("notas", "");
        return p;
    }
}
