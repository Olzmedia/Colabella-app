package com.colabellapetclub.app;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

/** Recibe las notificaciones push enviadas desde Firebase. */
public class ColabellaMessagingService extends FirebaseMessagingService {

    @Override
    public void onMessageReceived(@NonNull RemoteMessage message) {
        String titulo = getString(R.string.app_name);
        String cuerpo = "";
        String enlace = null;

        if (message.getNotification() != null) {
            if (message.getNotification().getTitle() != null) {
                titulo = message.getNotification().getTitle();
            }
            if (message.getNotification().getBody() != null) {
                cuerpo = message.getNotification().getBody();
            }
        }
        // Permite enviar desde Firebase un dato "url" para abrir una pagina concreta
        if (message.getData().containsKey("url")) {
            enlace = message.getData().get("url");
        }
        if (message.getData().containsKey("title")) {
            titulo = message.getData().get("title");
        }
        if (message.getData().containsKey("body")) {
            cuerpo = message.getData().get("body");
        }

        mostrar(titulo, cuerpo, enlace);
    }

    @Override
    public void onNewToken(@NonNull String token) {
        // El token identifica este dispositivo. Si mas adelante quieres enviar
        // avisos a un cliente concreto, aqui es donde se manda a tu servidor.
    }

    private void mostrar(String titulo, String cuerpo, String enlace) {
        Notifications.crearCanales(this);

        Intent i = new Intent(this, MainActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        if (!TextUtils.isEmpty(enlace)) {
            i.setData(Uri.parse(enlace));
        }

        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }
        PendingIntent pi = PendingIntent.getActivity(this, 0, i, flags);

        NotificationCompat.Builder b = new NotificationCompat.Builder(
                this, Notifications.CANAL_AVISOS)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle(titulo)
                .setContentText(cuerpo)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(cuerpo))
                .setAutoCancel(true)
                .setContentIntent(pi);

        NotificationManager nm =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) {
            nm.notify((int) System.currentTimeMillis(), b.build());
        }
    }
}
