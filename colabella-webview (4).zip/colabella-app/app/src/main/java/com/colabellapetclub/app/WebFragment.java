package com.colabellapetclub.app;

import android.annotation.SuppressLint;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

/** Pestana de inicio: el sitio web dentro de la app. */
public class WebFragment extends Fragment {

    public static final String HOST = "colabellapetclub.com";
    public static final String START_URL = "https://" + HOST + "/";

    private WebView webView;
    private SwipeRefreshLayout swipeRefresh;
    private View offlineView;

    private ValueCallback<Uri[]> filePathCallback;
    private ActivityResultLauncher<Intent> fileChooserLauncher;
    private boolean loadError = false;
    private String urlPendiente = null;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        fileChooserLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (filePathCallback == null) {
                        return;
                    }
                    filePathCallback.onReceiveValue(WebChromeClient.FileChooserParams
                            .parseResult(result.getResultCode(), result.getData()));
                    filePathCallback = null;
                });
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_web, container, false);
    }

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        webView = view.findViewById(R.id.webview);
        swipeRefresh = view.findViewById(R.id.swipe_refresh);
        offlineView = view.findViewById(R.id.offline_view);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setUserAgentString(s.getUserAgentString() + " ColabellaApp/1.0");

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest request) {
                return manejarUrl(request.getUrl());
            }

            @Override
            @SuppressWarnings("deprecation")
            public boolean shouldOverrideUrlLoading(WebView v, String url) {
                return manejarUrl(Uri.parse(url));
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                swipeRefresh.setRefreshing(false);
                if (loadError) {
                    mostrarOffline();
                }
            }

            @Override
            public void onReceivedError(WebView v, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    loadError = true;
                }
            }

            @Override
            @SuppressWarnings("deprecation")
            public void onReceivedError(WebView v, int code, String desc, String failingUrl) {
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
                    loadError = true;
                }
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = callback;
                try {
                    fileChooserLauncher.launch(params.createIntent());
                    return true;
                } catch (ActivityNotFoundException e) {
                    filePathCallback = null;
                    aviso(getString(R.string.no_file_app));
                    return false;
                }
            }
        });

        webView.setDownloadListener((url, userAgent, disposition, mime, size) -> {
            try {
                DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url));
                req.setMimeType(mime);
                req.addRequestHeader("User-Agent", userAgent);
                req.addRequestHeader("Cookie", CookieManager.getInstance().getCookie(url));
                req.setNotificationVisibility(
                        DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                req.setDestinationInExternalPublicDir(
                        android.os.Environment.DIRECTORY_DOWNLOADS,
                        URLUtil.guessFileName(url, disposition, mime));
                DownloadManager dm = (DownloadManager)
                        requireContext().getSystemService(Context.DOWNLOAD_SERVICE);
                if (dm != null) {
                    dm.enqueue(req);
                    aviso(getString(R.string.downloading));
                }
            } catch (Exception e) {
                abrirFuera(Uri.parse(url));
            }
        });

        swipeRefresh.setOnRefreshListener(() -> {
            loadError = false;
            webView.reload();
        });

        view.findViewById(R.id.btn_retry).setOnClickListener(v -> {
            if (!hayRed()) {
                aviso(getString(R.string.offline_title));
                return;
            }
            offlineView.setVisibility(View.GONE);
            swipeRefresh.setVisibility(View.VISIBLE);
            loadError = false;
            webView.loadUrl(START_URL);
        });

        String inicial = urlPendiente != null ? urlPendiente : START_URL;
        urlPendiente = null;
        webView.loadUrl(inicial);
    }

    /** Carga una URL concreta, por ejemplo la que llega en una notificacion push. */
    public void cargar(String url) {
        if (webView == null) {
            urlPendiente = url;
        } else {
            loadError = false;
            offlineView.setVisibility(View.GONE);
            swipeRefresh.setVisibility(View.VISIBLE);
            webView.loadUrl(url);
        }
    }

    public boolean puedeRetroceder() {
        return webView != null && webView.canGoBack();
    }

    public void retroceder() {
        webView.goBack();
    }

    private boolean manejarUrl(Uri uri) {
        String host = uri.getHost();
        if (uri.getScheme() == null) {
            return false;
        }
        if (host != null && (host.equals(HOST) || host.endsWith("." + HOST))) {
            return false;
        }
        abrirFuera(uri);
        return true;
    }

    private void abrirFuera(Uri uri) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, uri);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (ActivityNotFoundException e) {
            aviso(getString(R.string.cannot_open_link));
        }
    }

    private void mostrarOffline() {
        swipeRefresh.setRefreshing(false);
        swipeRefresh.setVisibility(View.GONE);
        offlineView.setVisibility(View.VISIBLE);
    }

    private boolean hayRed() {
        ConnectivityManager cm = (ConnectivityManager)
                requireContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) {
            return false;
        }
        NetworkInfo info = cm.getActiveNetworkInfo();
        return info != null && info.isConnected();
    }

    private void aviso(String msg) {
        if (isAdded()) {
            Toast.makeText(requireContext(), msg, Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onPause() {
        if (webView != null) {
            webView.onPause();
        }
        super.onPause();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (webView != null) {
            webView.onResume();
        }
    }
}
