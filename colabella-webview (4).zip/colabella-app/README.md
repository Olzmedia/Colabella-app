# Colabella Pet Club — App Android

App del club con dos secciones: el sitio web y una ficha de mascotas nativa que funciona sin conexión.

Paquete: `com.colabellapetclub.app` — coincide con el proyecto de Firebase `colabella-pet-club`.

## Qué hace

**Pestaña Inicio** — `colabellapetclub.com` dentro de la app. Navegación interna en el WebView; teléfono, WhatsApp, mapas y pasarelas de pago salen a su app. Deslizar para recargar, botón atrás con historial, subida de archivos desde formularios, descargas con la sesión intacta, y pantalla de reintento si no hay red.

**Pestaña Mis mascotas** — nativa y offline. Ficha con nombre, especie, raza, notas y fecha de próxima vacuna. Los datos viven en el dispositivo, así que se consultan sin internet y sobreviven al cambio de móvil vía copia de seguridad de Android.

**Recordatorios de vacunas** — al guardar una fecha, el teléfono programa un aviso para las 9:00 de ese día. No depende del servidor y se reprograma solo tras reiniciar el móvil.

**Notificaciones push** — vía Firebase Cloud Messaging, para promociones y comunicados. Se envían desde la consola de Firebase.

**Acceso directo** — al mantener pulsado el icono aparece "Mascotas", que entra directo a esa sección.

## Enviar una notificación push

1. Consola de Firebase → proyecto `colabella-pet-club` → Messaging → Nueva campaña.
2. Escribe título y texto, y elige la app como destino.
3. Para que al tocarla se abra una página concreta del sitio, añade en *Datos personalizados* la clave `url` con el valor de la dirección.

Las promociones llegan por el canal "Avisos del club" y los recordatorios de vacuna por otro distinto, así que el usuario puede silenciar uno sin perder el otro.

## Compilar

GitHub Actions con el workflow incluido, o `gradle assembleDebug` en local con JDK 17 y el SDK de Android.

## Publicar en Google Play

Play exige un **AAB firmado**, no el APK de debug:

1. Genera el keystore y **guárdalo a buen recaudo**; si se pierde, no se puede actualizar la app nunca más:
   ```
   keytool -genkey -v -keystore colabella.jks -alias colabella -keyalg RSA -keysize 2048 -validity 10000
   ```
2. Añade `signingConfigs` en `app/build.gradle` apuntando al keystore, y compila `bundleRelease`.
3. En Play Console tendrás que rellenar la política de privacidad, el cuestionario de Seguridad de los datos (declarando que guardas datos de mascotas en el dispositivo y usas FCM) y la clasificación de contenido.

Sobre la política de *mínima funcionalidad*: la ficha offline, los recordatorios locales, el push y el acceso directo son funciones que un navegador no ofrece, que es justo lo que Google mira. Aun así la revisión es humana y nadie puede garantizar el resultado; si la rechazan, el motivo llega por escrito y suele ser concreto.

Nota sobre cuentas: las cuentas de desarrollador personales creadas después de noviembre de 2023 necesitan 12 testers durante 14 días antes de publicar. Las cuentas registradas como organización no tienen ese requisito.

## Personalizar

| Qué | Dónde |
|---|---|
| Dominio del sitio | `WebFragment.java` → constante `HOST` |
| Textos | `res/values/strings.xml` |
| Colores | `res/values/colors.xml` |
| Icono | `res/mipmap-*/` |
| Hora del recordatorio | `ReminderReceiver.java` → `HOUR_OF_DAY` |
