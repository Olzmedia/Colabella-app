package com.colabellapetclub.app;

import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;

import org.json.JSONArray;
import org.json.JSONObject;

import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Trae de colabellapetclub.com el menu y las mascotas de quien haya iniciado
 * sesion, usando la propia sesion del WebView.
 *
 * Por que asi y no con una peticion desde Java: una peticion nativa no
 * comparte cookies con el WebView y el servidor contestaria "visitante".
 * Desde dentro de la pagina, la sesion ya esta.
 *
 * Los pasos son los mismos que usa la web en /mi-perfil/:
 *   1. admin-ajax clubd_whoami  -> si hay sesion y la llave (nonce) de la API.
 *      No pasa por la cache de LiteSpeed, asi que nunca devuelve la sesion de otro.
 *   2. /wp-json/cdmenu/v1/menu  -> el menu segun el rol.
 *   3. /wp-json/club/v1/mascotas -> la ficha de cada mascota del socio.
 *
 * Seguridad del puente: cada llamada lleva un token aleatorio que solo conoce
 * el script que inyecta la app en la pagina principal. Un iframe de otro sitio
 * (una pasarela de pago, por ejemplo) no puede leerlo, asi que no puede
 * mandar datos falsos.
 */
public class SincronizacionWeb {

    /** Nombre con el que la pagina ve el puente: window.ColabellaApp */
    public static final String NOMBRE_PUENTE = "ColabellaApp";

    public interface Receptor {
        /** Siempre se llama en el hilo principal. */
        void onMenu(String json);

        /** Siempre se llama en el hilo principal. null si no hay sesion. */
        void onMascotas(List<Pet> mascotas);
    }

    private final String token;
    private final Receptor receptor;
    private final Handler principal = new Handler(Looper.getMainLooper());

    public SincronizacionWeb(Receptor receptor) {
        this.receptor = receptor;
        byte[] b = new byte[16];
        new SecureRandom().nextBytes(b);
        StringBuilder sb = new StringBuilder();
        for (byte x : b) {
            sb.append(String.format(Locale.ROOT, "%02x", x));
        }
        this.token = sb.toString();
    }

    /** El objeto que se registra con addJavascriptInterface. */
    public Object puente() {
        return new Puente();
    }

    /** Script que se ejecuta al terminar de cargar cada pagina del sitio. */
    public String script() {
        return "(function(){try{"
                + "var T='" + token + "',A=window." + NOMBRE_PUENTE + ";"
                + "if(!A)return;"
                // Evita repetir la consulta si la misma pagina avisa dos veces
                + "if(window.__cbSync&&Date.now()-window.__cbSync<4000)return;"
                + "window.__cbSync=Date.now();"
                + "var o={credentials:'include',cache:'no-store'};"
                + "fetch('/wp-admin/admin-ajax.php?action=clubd_whoami&_='+Date.now(),o)"
                + ".then(function(r){return r.json();})"
                + ".then(function(w){"
                + "var h={};if(w&&w.rest_nonce)h['X-WP-Nonce']=w.rest_nonce;"
                + "var q={credentials:'include',cache:'no-store',headers:h};"
                + "fetch('/wp-json/cdmenu/v1/menu?_='+Date.now(),q)"
                + ".then(function(r){return r.ok?r.json():null;})"
                + ".then(function(m){if(m)A.recibirMenu(T,JSON.stringify(m));})"
                + ".catch(function(){});"
                + "if(!w||w.logged_in!=1){A.recibirMascotas(T,'null');return;}"
                + "fetch('/wp-json/club/v1/mascotas?_='+Date.now(),q)"
                + ".then(function(r){return r.ok?r.json():null;})"
                + ".then(function(l){if(Array.isArray(l))A.recibirMascotas(T,JSON.stringify(l));})"
                + ".catch(function(){});"
                + "}).catch(function(){});"
                + "}catch(e){}})();";
    }

    private class Puente {

        @JavascriptInterface
        public void recibirMenu(String t, String json) {
            if (!token.equals(t) || json == null) {
                return;
            }
            principal.post(() -> receptor.onMenu(json));
        }

        @JavascriptInterface
        public void recibirMascotas(String t, String json) {
            if (!token.equals(t)) {
                return;
            }
            final List<Pet> lista = "null".equals(json) ? null : leerMascotas(json);
            if (lista == null && !"null".equals(json)) {
                return; // respuesta mal formada: se conserva lo que habia
            }
            principal.post(() -> receptor.onMascotas(lista));
        }
    }

    // ---------------------------------------------------------------------
    // Ficha de la web -> ficha de la app
    // ---------------------------------------------------------------------

    static List<Pet> leerMascotas(String json) {
        try {
            JSONArray arr = new JSONArray(json);
            List<Pet> lista = new ArrayList<>();
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o == null || o.optString("id", "").isEmpty()) {
                    continue;
                }
                lista.add(convertir(o));
            }
            return lista;
        } catch (Exception e) {
            return null;
        }
    }

    private static Pet convertir(JSONObject o) {
        Pet p = new Pet();
        p.id = "web-" + o.optString("id");
        p.deLaWeb = true;
        p.nombre = texto(o, "nombre");
        if (p.nombre.isEmpty()) {
            p.nombre = "Mascota";
        }
        p.especie = texto(o, "tipo");
        p.raza = unir(" · ", texto(o, "raza"), texto(o, "sexo"), texto(o, "edad"));

        String peso = texto(o, "peso");
        p.notas = unir(" · ",
                peso.isEmpty() ? "" : "Peso: " + peso,
                etiqueta("Alergias", texto(o, "alergias")),
                etiqueta("Medicamentos", texto(o, "medicamentos")),
                etiqueta("Chip", texto(o, "microchip")));

        p.proximaVacuna = proximaVacuna(o.optJSONArray("vacunas"));
        return p;
    }

    /**
     * La proxima dosis pendiente: la fecha "proxima" mas cercana desde hoy. Si
     * todas ya pasaron, la ultima vencida, para que la ficha avise que hay una
     * vacuna pendiente.
     */
    static long proximaVacuna(JSONArray vacunas) {
        if (vacunas == null) {
            return 0;
        }
        long hoy = inicioDeHoy();
        long futura = Long.MAX_VALUE;
        long vencida = 0;
        for (int i = 0; i < vacunas.length(); i++) {
            JSONObject v = vacunas.optJSONObject(i);
            if (v == null) {
                continue;
            }
            long f = fecha(v.optString("proxima", ""));
            if (f <= 0) {
                continue;
            }
            if (f >= hoy) {
                futura = Math.min(futura, f);
            } else {
                vencida = Math.max(vencida, f);
            }
        }
        return futura != Long.MAX_VALUE ? futura : vencida;
    }

    private static final Pattern ISO = Pattern.compile("^(\\d{4})-(\\d{1,2})-(\\d{1,2})");
    private static final Pattern LATINA = Pattern.compile("^(\\d{1,2})[/.\\-](\\d{1,2})[/.\\-](\\d{4})");

    /** Acepta AAAA-MM-DD y DD/MM/AAAA, igual que la web. Devuelve las 9:00 de ese dia. */
    static long fecha(String txt) {
        if (txt == null) {
            return 0;
        }
        txt = txt.trim();
        int y, m, d;
        Matcher a = ISO.matcher(txt);
        Matcher b = LATINA.matcher(txt);
        if (a.find()) {
            y = Integer.parseInt(a.group(1));
            m = Integer.parseInt(a.group(2));
            d = Integer.parseInt(a.group(3));
        } else if (b.find()) {
            d = Integer.parseInt(b.group(1));
            m = Integer.parseInt(b.group(2));
            y = Integer.parseInt(b.group(3));
        } else {
            return 0;
        }
        if (m < 1 || m > 12 || d < 1 || d > 31 || y < 1990) {
            return 0;
        }
        Calendar c = Calendar.getInstance();
        c.clear();
        c.set(y, m - 1, d, 9, 0, 0);
        return c.getTimeInMillis();
    }

    private static long inicioDeHoy() {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c.getTimeInMillis();
    }

    private static String texto(JSONObject o, String clave) {
        if (o.isNull(clave)) {
            return "";
        }
        return o.optString(clave, "").trim();
    }

    private static String etiqueta(String nombre, String valor) {
        if (valor.isEmpty()) {
            return "";
        }
        String v = valor.toLowerCase(Locale.ROOT);
        // "Ninguna" / "Ninguno" no aportan en la tarjeta
        if (v.startsWith("ningun") || v.equals("no") || v.equals("n/a")) {
            return "";
        }
        return nombre + ": " + valor;
    }

    private static String unir(String sep, String... partes) {
        StringBuilder sb = new StringBuilder();
        for (String p : partes) {
            if (p == null || p.isEmpty()) {
                continue;
            }
            if (sb.length() > 0) {
                sb.append(sep);
            }
            sb.append(p);
        }
        return sb.toString();
    }
}
