package com.colabellapetclub.app;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.HapticFeedbackConstants;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.activity.OnBackPressedCallback;
import androidx.activity.SystemBarStyle;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity implements WebFragment.MenuListener {

    public static final String EXTRA_ABRIR_MASCOTAS = "abrir_mascotas";

    private static final String TAG_WEB = "web";
    private static final String TAG_PETS = "pets";
    private static final String STATE_SECCION = "seccion";
    private static final String STATE_ULTIMA_WEB = "ultima_web";

    private WebFragment webFragment;
    private PetsFragment petsFragment;
    private Fragment actual;

    private BottomNavigationView nav;
    private View raiz;
    private ActivityResultLauncher<String> permisoNotificaciones;

    private MenuConfig menu;
    /** Posicion de la pestaña activa dentro del menu actual. */
    private int seleccion = 0;
    /** Ultima pestaña web visitada: al volver a ella no se recarga la pagina. */
    private int ultimaWeb = 0;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        // Desde Android 15 (targetSdk 35+) la app se dibuja siempre de borde a borde.
        // Barras del sistema en el azul de la marca, con iconos blancos, para que
        // la barra de estado y la de gestos se fundan con el menu inferior.
        int marca = ContextCompat.getColor(this, R.color.nav_background);
        EdgeToEdge.enable(this,
                SystemBarStyle.dark(Color.TRANSPARENT),
                SystemBarStyle.dark(marca));
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Notifications.crearCanales(this);

        permisoNotificaciones = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(), concedido -> { });

        nav = findViewById(R.id.bottom_nav);
        raiz = findViewById(R.id.raiz);

        if (savedInstanceState != null) {
            webFragment = (WebFragment) getSupportFragmentManager().findFragmentByTag(TAG_WEB);
            petsFragment = (PetsFragment) getSupportFragmentManager().findFragmentByTag(TAG_PETS);
            seleccion = savedInstanceState.getInt(STATE_SECCION, 0);
            ultimaWeb = savedInstanceState.getInt(STATE_ULTIMA_WEB, 0);
        }
        if (webFragment == null) {
            webFragment = new WebFragment();
        }
        if (petsFragment == null) {
            petsFragment = new PetsFragment();
        }
        webFragment.setMenuListener(this);

        // Se empieza con el ultimo menu conocido para que la barra nunca salga vacia
        menu = MenuConfig.cargar(this);
        pintarMenu();

        nav.setOnItemSelectedListener(this::alSeleccionar);

        if (savedInstanceState == null) {
            mostrar(webFragment, TAG_WEB);
        } else {
            actual = petsFragment.isAdded() && !petsFragment.isHidden() ? petsFragment : webFragment;
        }

        aplicarMargenesDelSistema();
        manejarIntent(getIntent());
        pedirPermisoNotificaciones();

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (actual == webFragment && webFragment.puedeRetroceder()) {
                    webFragment.retroceder();
                    return;
                }
                if (seleccion != 0) {
                    seleccionar(0);
                    return;
                }
                // Se desactiva solo durante esta pulsacion. En Android 12+ la actividad
                // raiz no se destruye al salir, y si el callback quedara desactivado,
                // al volver el boton atras ya no navegaria por el historial web.
                setEnabled(false);
                getOnBackPressedDispatcher().onBackPressed();
                setEnabled(true);
            }
        });
    }

    // --- Menu dinamico -----------------------------------------------------

    /** El sitio manda un menu distinto segun sea visitante, socio o negocio. */
    @Override
    public void onMenuRecibido(String json) {
        MenuConfig nuevo = MenuConfig.desdeJson(json);
        if (nuevo == null || nuevo.equivaleA(menu)) {
            return;
        }
        // Se recuerda en que seccion estaba el usuario para no sacarlo de ella
        String idActual = seleccion < menu.items.size() ? menu.items.get(seleccion).id : null;
        menu = nuevo;
        menu.guardar(this, json);
        pintarMenu();

        int destino = 0;
        for (int i = 0; i < menu.items.size(); i++) {
            if (menu.items.get(i).id.equals(idActual)) {
                destino = i;
                break;
            }
        }
        seleccion = destino;
        ultimaWeb = actual == webFragment ? destino : -1;
        nav.getMenu().getItem(destino).setChecked(true);
    }

    private void pintarMenu() {
        Menu m = nav.getMenu();
        m.clear();
        for (int i = 0; i < menu.items.size(); i++) {
            MenuConfig.Item item = menu.items.get(i);
            MenuItem mi = m.add(Menu.NONE, i, i, item.titulo);
            mi.setIcon(MenuConfig.iconoDe(item.icono));
        }
        if (seleccion >= menu.items.size()) {
            seleccion = 0;
        }
        if (!menu.items.isEmpty()) {
            m.getItem(seleccion).setChecked(true);
        }
    }

    private boolean alSeleccionar(MenuItem item) {
        nav.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
        return seleccionar(item.getItemId());
    }

    private boolean seleccionar(int posicion) {
        if (posicion < 0 || posicion >= menu.items.size()) {
            return false;
        }
        MenuConfig.Item destino = menu.items.get(posicion);
        boolean cambia = posicion != seleccion;
        seleccion = posicion;

        if (destino.nativo) {
            mostrar(petsFragment, TAG_PETS);
        } else {
            mostrar(webFragment, TAG_WEB);
            // Volver a la misma pestaña web (p. ej. desde Mascotas) no recarga:
            // la pagina sigue donde estaba, con su scroll y su historial.
            if (posicion != ultimaWeb) {
                webFragment.cargar(destino.url);
            }
            ultimaWeb = posicion;
        }
        if (nav.getMenu().size() > posicion) {
            nav.getMenu().getItem(posicion).setChecked(true);
        }
        return true;
    }

    // --- Resto -------------------------------------------------------------

    /**
     * Con la app de borde a borde hay que apartar el contenido de las barras del
     * sistema y del teclado. Ademas la barra inferior estorba al escribir (sobre
     * todo en el formulario de acceso), asi que se esconde con el teclado abierto.
     */
    private void aplicarMargenesDelSistema() {
        ViewCompat.setOnApplyWindowInsetsListener(raiz, (v, insets) -> {
            Insets barras = insets.getInsets(
                    WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
            boolean teclado = insets.isVisible(WindowInsetsCompat.Type.ime());
            int abajo = teclado ? insets.getInsets(WindowInsetsCompat.Type.ime()).bottom : 0;
            v.setPadding(barras.left, barras.top, barras.right, abajo);

            int deseado = teclado ? View.GONE : View.VISIBLE;
            if (nav.getVisibility() != deseado) {
                nav.setVisibility(deseado);
            }
            // La barra inferior solo debe reservar el hueco de la barra de gestos
            return new WindowInsetsCompat.Builder(insets)
                    .setInsets(WindowInsetsCompat.Type.systemBars(),
                            Insets.of(0, 0, 0, barras.bottom))
                    .setInsets(WindowInsetsCompat.Type.displayCutout(), Insets.NONE)
                    .build();
        });
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        manejarIntent(intent);
    }

    /** Atiende los accesos directos del icono y los enlaces de las notificaciones. */
    private void manejarIntent(@Nullable Intent intent) {
        if (intent == null) {
            return;
        }
        if (intent.getBooleanExtra(EXTRA_ABRIR_MASCOTAS, false)) {
            for (int i = 0; i < menu.items.size(); i++) {
                if (menu.items.get(i).nativo) {
                    seleccionar(i);
                    return;
                }
            }
            return;
        }
        Uri data = intent.getData();
        // La actividad es exportada (lanzador): cualquier app podria enviarle una URL.
        // Solo se abren dentro de la app las paginas del propio sitio.
        if (data != null && WebFragment.esDelSitio(data)) {
            // Se va directo a la URL, sin cargar antes la pagina de inicio
            seleccion = 0;
            ultimaWeb = 0;
            mostrar(webFragment, TAG_WEB);
            if (nav.getMenu().size() > 0) {
                nav.getMenu().getItem(0).setChecked(true);
            }
            webFragment.cargar(data.toString());
        }
    }

    /**
     * Cambia de seccion ocultando la otra en vez de destruirla. Antes se usaba
     * replace(), que destruia el WebView: cada vuelta desde Mascotas descargaba
     * la web entera de nuevo y se perdia la pagina en la que estaba el usuario.
     */
    private void mostrar(Fragment fragment, String tag) {
        if (fragment == actual && fragment.isAdded()) {
            return;
        }
        FragmentTransaction t = getSupportFragmentManager().beginTransaction()
                .setReorderingAllowed(true);
        if (actual != null && actual != fragment && actual.isAdded()) {
            t.hide(actual);
        }
        if (fragment.isAdded()) {
            t.show(fragment);
        } else {
            t.add(R.id.contenedor, fragment, tag);
        }
        t.commitNow();
        actual = fragment;
    }

    private void pedirPermisoNotificaciones() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
            return;
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            permisoNotificaciones.launch(Manifest.permission.POST_NOTIFICATIONS);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(STATE_SECCION, seleccion);
        outState.putInt(STATE_ULTIMA_WEB, ultimaWeb);
    }
}
