-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# Conserva numeros de linea en los informes de fallos de Play Console
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
